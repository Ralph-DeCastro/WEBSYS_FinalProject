CREATE DATABASE IF NOT EXISTS community_waste_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE community_waste_db;

CREATE TABLE IF NOT EXISTS users (
	id INT AUTO_INCREMENT PRIMARY KEY,
	full_name VARCHAR(120) NOT NULL,
	username VARCHAR(60) NOT NULL UNIQUE,
	password VARCHAR(255) NOT NULL,
	role VARCHAR(40) NOT NULL,
	barangay VARCHAR(100) NOT NULL DEFAULT '',
	contact_number VARCHAR(30) NOT NULL DEFAULT '',
	address VARCHAR(255) NOT NULL DEFAULT '',
	status VARCHAR(20) NOT NULL DEFAULT 'Active',
	created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS barangays (
	id INT AUTO_INCREMENT PRIMARY KEY,
	barangay_name VARCHAR(100) NOT NULL,
	zone_name VARCHAR(100) NOT NULL,
	notes VARCHAR(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS schedules (
	id INT AUTO_INCREMENT PRIMARY KEY,
	barangay VARCHAR(100) NOT NULL,
	zone_name VARCHAR(100) NOT NULL,
	waste_category VARCHAR(50) NOT NULL,
	personnel_id INT NOT NULL,
	frequency VARCHAR(50) NOT NULL,
	collection_day VARCHAR(160) NOT NULL,
	collection_time TIME NOT NULL,
	notes TEXT,
	status VARCHAR(20) NOT NULL DEFAULT 'Active',
	created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS collection_records (
	id INT AUTO_INCREMENT PRIMARY KEY,
	schedule_id INT NOT NULL,
	barangay VARCHAR(100) NOT NULL,
	zone_name VARCHAR(100) NOT NULL,
	waste_category VARCHAR(50) NOT NULL,
	collection_date DATE NOT NULL,
	status VARCHAR(20) NOT NULL,
	personnel_id INT NOT NULL,
	remarks TEXT,
	recorded_by INT NOT NULL,
	recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS complaints (
	id INT AUTO_INCREMENT PRIMARY KEY,
	resident_id INT NOT NULL,
	resident_name VARCHAR(120) NOT NULL,
	complaint_type VARCHAR(80) NOT NULL,
	barangay VARCHAR(100) NOT NULL,
	location VARCHAR(255) NOT NULL,
	description TEXT NOT NULL,
	photo VARCHAR(255) DEFAULT NULL,
	status VARCHAR(30) NOT NULL DEFAULT 'New',
	response_notes TEXT,
	handled_by INT DEFAULT NULL,
	created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	updated_at TIMESTAMP NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS segregation_guides (
	id INT AUTO_INCREMENT PRIMARY KEY,
	waste_type VARCHAR(80) NOT NULL,
	description TEXT NOT NULL,
	examples TEXT NOT NULL,
	how_to_prepare TEXT NOT NULL,
	color_label VARCHAR(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS materials (
	id INT AUTO_INCREMENT PRIMARY KEY,
	material_name VARCHAR(100) NOT NULL,
	category VARCHAR(50) NOT NULL,
	unit VARCHAR(20) NOT NULL DEFAULT 'kg',
	price_per_kg DECIMAL(10,2) NOT NULL DEFAULT 0,
	status VARCHAR(20) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS recycling_transactions (
	id INT AUTO_INCREMENT PRIMARY KEY,
	material_id INT NOT NULL,
	transaction_type VARCHAR(30) NOT NULL,
	person_name VARCHAR(120) NOT NULL,
	person_user_id INT DEFAULT NULL,
	weight_kg DECIMAL(10,2) NOT NULL,
	amount DECIMAL(10,2) NOT NULL DEFAULT 0,
	record_date DATE NOT NULL,
	notes TEXT,
	recorded_by INT NOT NULL,
	created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS assignments (
	id INT AUTO_INCREMENT PRIMARY KEY,
	personnel_id INT NOT NULL,
	schedule_id INT NOT NULL,
	assignment_date DATE NOT NULL,
	shift_label VARCHAR(50) NOT NULL,
	status VARCHAR(30) NOT NULL DEFAULT 'Assigned',
	notes TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS activities (
	id INT AUTO_INCREMENT PRIMARY KEY,
	personnel_id INT NOT NULL,
	activity_date DATE NOT NULL,
	task_done VARCHAR(255) NOT NULL,
	status VARCHAR(30) NOT NULL,
	notes TEXT,
	recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS announcements (
	id INT AUTO_INCREMENT PRIMARY KEY,
	title VARCHAR(180) NOT NULL,
	category VARCHAR(80) NOT NULL,
	body TEXT NOT NULL,
	audience VARCHAR(50) NOT NULL DEFAULT 'Everyone',
	posted_by INT NOT NULL,
	publish_date DATE NOT NULL,
	status VARCHAR(20) NOT NULL DEFAULT 'Published'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO segregation_guides(waste_type, description, examples, how_to_prepare, color_label)
SELECT 'Biohazard waste',
	'Household medical waste that requires separate, contained handling.',
	'Used needles, syringes, lancets, soiled dressings, and other infectious-care items.',
	'Do not mix biohazard waste with regular trash or recyclables. Place sharps in a tightly closed puncture-resistant container. Keep other items in a leak-resistant red or clearly marked sealed bag. Request a pickup and keep waste away from children and animals.',
	'Red'
WHERE NOT EXISTS (
	SELECT 1 FROM segregation_guides WHERE waste_type = 'Biohazard waste'
);
