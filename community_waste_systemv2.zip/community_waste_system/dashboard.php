<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	$user = current_user();

	$reports = new Reports($pdo);
	$schedules = new Schedules($pdo);
	$complaints = new Complaints($pdo);
	$collections = new Collections($pdo);
	$assignments = new Assignments($pdo);
	$news = new Announcements($pdo);

	$counts = $reports->dashboard_counts($user['role'], $user['id'], $user['barangay']);
	$today_barangay = '';
	$today_personnel = 0;
	if ($user['role'] === 'Resident' || $user['role'] === 'Barangay Personnel') {
		$today_barangay = $user['barangay'];
	}
	if ($user['role'] === 'Collection Personnel') {
		$today_personnel = (int) $user['id'];
	}
	$today_routes = $schedules->show_today($today_barangay, $today_personnel);
	$my_assignments = [];
	if ($user['role'] === 'Collection Personnel') {
		$my_assignments = $assignments->show_for_day($user['id'], date('Y-m-d'));
	}

	$recent_complaints = [];
	$recent_missed = [];
	$recent_news = $news->show_for_role($user['role']);
	$recent_news = array_slice($recent_news, 0, 2);
	if ($user['role'] === 'Barangay Personnel') {
		$recent_complaints = $complaints->show_recent($user['barangay'], 4);
		$recent_missed = $collections->show_recent_missed($user['barangay'], 4);
	} elseif (sees_all($user['role'])) {
		$recent_complaints = $complaints->show_recent('', 4);
		$recent_missed = $collections->show_recent_missed('', 4);
	}

	$page_title = 'Home';
	$nav_current = 'dashboard.php';
	require 'includes/header.php';
?>
	<h1>Home</h1>
	<p class="lead">Today is <?php echo h(format_date(date('Y-m-d'))) ?>, <?php echo h(date('l')) ?>.</p>

	<section class="today">
		<h2>Today’s collection</h2>
		<?php if (!$today_routes && $user['role'] === 'Resident') { ?>
			<p>No truck is scheduled for <?php echo h($user['barangay'] !== '' ? $user['barangay'] : 'your area') ?> today.</p>
		<?php } elseif (!$today_routes && $user['role'] === 'Collection Personnel') { ?>
			<p>You have no standing route on today’s weekday. Check your dated assignment below.</p>
		<?php } elseif (!$today_routes) { ?>
			<p>No active route matches today’s weekday<?php echo $today_barangay !== '' ? ' in ' . h($today_barangay) : '' ?>.</p>
		<?php } else { ?>
			<?php if ($user['role'] === 'Resident') { ?>
				<p>The truck is coming to <?php echo h($user['barangay']) ?> today.</p>
			<?php } ?>
			<div class="table-wrap">
				<table>
					<tr>
						<th>Area</th>
						<th>Waste</th>
						<th>Time</th>
						<th>Collector</th>
					</tr>
					<?php foreach ($today_routes as $route) { ?>
						<tr>
							<td><?php echo h($route['barangay'] . ', ' . $route['zone_name']) ?></td>
							<td><?php echo h($route['waste_category']) ?></td>
							<td><?php echo h(format_time($route['collection_time'])) ?></td>
							<td><?php echo h($route['personnel_name']) ?></td>
						</tr>
					<?php } ?>
				</table>
			</div>
		<?php } ?>
		<?php if ($user['role'] === 'Collection Personnel' && $today_routes) { ?>
			<div class="button-row">
				<a class="btn" href="add_collection.php">Record a trip</a>
			</div>
		<?php } ?>
	</section>

	<?php if ($user['role'] === 'Resident') { ?>
		<div class="tiles">
			<a class="tile" href="schedules.php">
				<span class="tile-number"><?php echo (int) $counts['schedules'] ?></span>
				<span class="tile-title">Collection days</span>
				<span class="tile-text">See when the truck comes to your area.</span>
			</a>
			<a class="tile" href="complaints.php">
				<span class="tile-number"><?php echo (int) $counts['open_reports'] ?></span>
				<span class="tile-title">Open reports</span>
				<span class="tile-text">Problems you sent that are not finished yet.</span>
			</a>
			<a class="tile" href="announcements.php">
				<span class="tile-number"><?php echo (int) $counts['news'] ?></span>
				<span class="tile-title">News items</span>
				<span class="tile-text">Announcements and reminders.</span>
			</a>
		</div>
		<div class="button-row">
			<a class="btn" href="add_complaint.php">Report a problem</a>
			<a class="btn btn-secondary" href="biohazard.php">Biohazard help</a>
			<a class="btn btn-secondary" href="segregation.php">How to sort waste</a>
		</div>
	<?php } elseif ($user['role'] === 'Collection Personnel') { ?>
		<div class="tiles">
			<a class="tile" href="schedules.php">
				<span class="tile-number"><?php echo (int) $counts['routes'] ?></span>
				<span class="tile-title">My routes</span>
				<span class="tile-text">The standing collection days assigned to you.</span>
			</a>
			<a class="tile" href="monitoring.php">
				<span class="tile-number"><?php echo (int) $counts['done_month'] ?></span>
				<span class="tile-title">Finished this month</span>
				<span class="tile-text">Trips you marked as completed.</span>
			</a>
			<a class="tile" href="monitoring.php">
				<span class="tile-number"><?php echo (int) $counts['missed_month'] ?></span>
				<span class="tile-title">Missed this month</span>
				<span class="tile-text">Trips you marked as missed.</span>
			</a>
		</div>
		<h2>Dated assignment for today</h2>
		<?php if (!$my_assignments) { ?>
			<div class="empty"><p>No extra assignment was saved for you today.</p></div>
		<?php } else { ?>
			<div class="table-wrap">
				<table>
					<tr><th>Area</th><th>Waste</th><th>Shift</th><th>Note</th><th>Status</th></tr>
					<?php foreach ($my_assignments as $item) { ?>
						<tr>
							<td><?php echo h(($item['barangay'] ?? '') . ', ' . ($item['zone_name'] ?? '')) ?></td>
							<td><?php echo h($item['waste_category'] ?? '') ?></td>
							<td><?php echo h($item['shift_label']) ?></td>
							<td><?php echo h($item['notes']) ?></td>
							<td><?php echo badge($item['status']) ?></td>
						</tr>
					<?php } ?>
				</table>
			</div>
		<?php } ?>
		<div class="button-row">
			<a class="btn" href="add_activity.php">Write what I did today</a>
		</div>
	<?php } elseif ($user['role'] === 'Barangay Personnel') { ?>
		<div class="tiles">
			<a class="tile" href="schedules.php"><span class="tile-number"><?php echo (int) $counts['schedules'] ?></span><span class="tile-title">Active schedules</span><span class="tile-text">Collection days in <?php echo h($user['barangay']) ?>.</span></a>
			<a class="tile" href="monitoring.php"><span class="tile-number"><?php echo (int) $counts['missed'] ?></span><span class="tile-title">Missed trips</span><span class="tile-text">Collections that did not happen.</span></a>
			<a class="tile" href="complaints.php"><span class="tile-number"><?php echo (int) $counts['open_complaints'] ?></span><span class="tile-title">Open complaints</span><span class="tile-text">Resident reports still waiting.</span></a>
			<a class="tile" href="personnel.php"><span class="tile-number"><?php echo (int) $counts['personnel'] ?></span><span class="tile-title">Collectors</span><span class="tile-text">Active collection personnel in your area.</span></a>
		</div>
	<?php } else { ?>
		<div class="tiles">
			<a class="tile" href="schedules.php"><span class="tile-number"><?php echo (int) $counts['schedules'] ?></span><span class="tile-title">Active schedules</span><span class="tile-text">Collection days for the whole municipality.</span></a>
			<a class="tile" href="monitoring.php"><span class="tile-number"><?php echo (int) $counts['missed'] ?></span><span class="tile-title">Missed trips</span><span class="tile-text">Collections marked as missed.</span></a>
			<a class="tile" href="complaints.php"><span class="tile-number"><?php echo (int) $counts['open_complaints'] ?></span><span class="tile-title">Open complaints</span><span class="tile-text">Reports that are not resolved.</span></a>
			<a class="tile" href="recycling.php"><span class="tile-number"><?php echo h(format_weight($counts['weight'])) ?></span><span class="tile-title">Recycled this month</span><span class="tile-text">Total weight recorded at the center.</span></a>
		</div>
		<div class="button-row">
			<a class="btn" href="reports.php">Open the reports</a>
		</div>
	<?php } ?>

	<?php if ($recent_complaints) { ?>
		<h2>Latest complaints</h2>
		<div class="table-wrap">
			<table>
				<tr><th>Type</th><th>Area</th><th>Status</th><th></th></tr>
				<?php foreach ($recent_complaints as $row) { ?>
					<tr>
						<td><?php echo h($row['complaint_type']) ?></td>
						<td><?php echo h($row['barangay']) ?></td>
						<td><?php echo badge($row['status']) ?></td>
						<td><a href="view_complaint.php?id=<?php echo (int) $row['id'] ?>">Open</a></td>
					</tr>
				<?php } ?>
			</table>
		</div>
	<?php } ?>

	<?php if ($recent_missed) { ?>
		<h2>Latest missed collections</h2>
		<div class="table-wrap">
			<table>
				<tr><th>Date</th><th>Area</th><th>Waste</th><th>Why</th></tr>
				<?php foreach ($recent_missed as $row) { ?>
					<tr>
						<td><?php echo h(format_date($row['collection_date'])) ?></td>
						<td><?php echo h($row['barangay'] . ', ' . $row['zone_name']) ?></td>
						<td><?php echo h($row['waste_category']) ?></td>
						<td><?php echo h($row['remarks']) ?></td>
					</tr>
				<?php } ?>
			</table>
		</div>
	<?php } ?>

	<?php if ($recent_news) { ?>
		<h2>Latest news</h2>
		<div class="news-list">
			<?php foreach ($recent_news as $item) { ?>
				<article class="card news-item">
					<p class="meta"><?php echo h($item['category']) ?> · <?php echo h(format_date($item['publish_date'])) ?></p>
					<h2><?php echo h($item['title']) ?></h2>
					<p><?php echo nl2br(h($item['body'])) ?></p>
				</article>
			<?php } ?>
		</div>
	<?php } ?>
<?php require 'includes/footer.php'; ?>
