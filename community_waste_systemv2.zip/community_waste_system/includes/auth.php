<?php

if (session_status() === PHP_SESSION_NONE) {
	session_start();
}

function h($value){
	return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function current_user(){
	return [
		'id' => $_SESSION['user_id'] ?? 0,
		'full_name' => $_SESSION['full_name'] ?? '',
		'username' => $_SESSION['username'] ?? '',
		'role' => $_SESSION['role'] ?? '',
		'barangay' => $_SESSION['barangay'] ?? '',
	];
}

function require_login(){
	if (empty($_SESSION['user_id'])) {
		header('Location: index.php');
		exit();
	}
}

function require_role($roles){
	if (!in_array($_SESSION['role'] ?? '', $roles, true)) {
		set_flash('That page is for a different kind of account.');
		header('Location: dashboard.php');
		exit();
	}
}

function sees_all($role){
	return in_array($role, ['Administrator', 'MENRO'], true);
}

function owns_record($record_barangay){
	$user = current_user();
	if (sees_all($user['role'])) {
		return true;
	}
	return $record_barangay !== '' && $user['barangay'] === $record_barangay;
}

function set_flash($message){
	$_SESSION['message'] = $message;
}

function flash(){
	if (empty($_SESSION['message'])) {
		return '';
	}
	$message = $_SESSION['message'];
	unset($_SESSION['message']);
	return $message;
}

function deny($message, $location = 'dashboard.php'){
	set_flash($message);
	header('Location: ' . $location);
	exit();
}

function posted($key){
	return trim((string) ($_POST[$key] ?? ''));
}

function role_label($role){
	$labels = [
		'Administrator' => 'System Administrator',
		'MENRO' => 'MENRO',
		'Barangay Personnel' => 'Barangay Environment Personnel',
		'Collection Personnel' => 'Waste Collection Personnel',
		'Resident' => 'Community Resident',
	];
	return $labels[$role] ?? $role;
}

function all_roles(){
	return [
		'Administrator',
		'MENRO',
		'Barangay Personnel',
		'Collection Personnel',
		'Resident',
	];
}

function roles_for_creator($creator_role){
	if ($creator_role === 'Administrator') {
		return all_roles();
	}
	if ($creator_role === 'MENRO') {
		return ['MENRO', 'Barangay Personnel', 'Collection Personnel', 'Resident'];
	}
	return [];
}

function weekdays(){
	return ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
}

function waste_categories(){
	return ['Biodegradable', 'Recyclable', 'Residual', 'Special', 'Biohazard'];
}

function guide_colors(){
	return ['Green', 'Blue', 'Black', 'Red', 'Gold'];
}

function frequencies(){
	return ['Daily', 'Twice a week', 'Weekly', 'Every other week'];
}

function complaint_types(){
	return [
		'Illegal dumping' => 'Trash left in a place that is not a pickup point.',
		'Uncollected garbage' => 'The truck did not collect the bags that were put out.',
		'Blocked drainage' => 'A canal or drain is blocked by trash.',
		'Improper waste disposal' => 'Waste was burned, mixed, or thrown in the wrong place.',
		'Biohazard pickup request' => 'Request a scheduled pickup for safely contained household medical waste.',
		'Biohazard in public area' => 'Needles, sharps, or medical waste are exposed in a public place.',
		'Biohazard mixed with recyclables' => 'Medical or infectious waste was found in recyclable bags or containers.',
		'Biohazard spill or incident' => 'Report a spill, broken container, or possible needlestick exposure.',
	];
}

function announcement_categories(){
	return [
		'Collection announcements',
		'Environmental campaigns',
		'Recycling programs',
		'Waste segregation reminders',
	];
}

function selected($current, $value){
	return (string) $current === (string) $value ? ' selected' : '';
}

function checked_value($current, $value){
	return (string) $current === (string) $value ? ' checked' : '';
}

function day_checked($stored, $day){
	$days = array_map('trim', explode(',', (string) $stored));
	return in_array($day, $days, true) ? ' checked' : '';
}

function format_date($date){
	if (!$date) {
		return '';
	}
	$timestamp = strtotime((string) $date);
	if (!$timestamp) {
		return (string) $date;
	}
	return date('F j, Y', $timestamp);
}

function format_time($time){
	if (!$time) {
		return '';
	}
	$timestamp = strtotime((string) $time);
	if (!$timestamp) {
		return (string) $time;
	}
	return date('g:i A', $timestamp);
}

function time_input($time){
	return substr((string) $time, 0, 5);
}

function format_money($amount){
	return 'PHP ' . number_format((float) $amount, 2);
}

function format_weight($kg){
	return number_format((float) $kg, 1) . ' kg';
}

function badge($status){
	$map = [
		'Completed' => 'badge-good',
		'Resolved' => 'badge-good',
		'Active' => 'badge-good',
		'Published' => 'badge-good',
		'Done' => 'badge-good',
		'Missed' => 'badge-warn',
		'New' => 'badge-warn',
		'Could not finish' => 'badge-warn',
		'Inactive' => 'badge-muted',
		'Hidden' => 'badge-muted',
		'In Progress' => 'badge-info',
		'Assigned' => 'badge-info',
	];
	$extra = $map[$status] ?? 'badge-muted';
	return '<span class="badge ' . $extra . '">' . h($status) . '</span>';
}

function guide_class($color){
	$map = [
		'Green' => 'guide-green',
		'Blue' => 'guide-blue',
		'Black' => 'guide-black',
		'Red' => 'guide-red',
		'Gold' => 'guide-gold',
	];
	return $map[$color] ?? 'guide-green';
}

function area_options($areas, $selected_id){
	$html = '<option value="">Choose an area</option>';
	foreach ($areas as $area) {
		$html .= '<option value="' . h($area['id']) . '"' . selected($area['id'], $selected_id) . '>' . h($area['barangay_name'] . ', ' . $area['zone_name']) . '</option>';
	}
	return $html;
}

function user_options($users, $selected, $empty_label = 'Choose a person'){
	$html = '<option value="">' . h($empty_label) . '</option>';
	foreach ($users as $person) {
		$label = $person['full_name'];
		if (!empty($person['barangay'])) {
			$label .= ' — ' . $person['barangay'];
		}
		$html .= '<option value="' . h($person['id']) . '"' . selected($person['id'], $selected) . '>' . h($label) . '</option>';
	}
	return $html;
}

function schedule_options($rows, $selected){
	$html = '<option value="">Choose the route</option>';
	foreach ($rows as $row) {
		$label = $row['barangay'] . ', ' . $row['zone_name'] . ' — ' . $row['waste_category'] . ' (' . $row['collection_day'] . ')';
		$html .= '<option value="' . h($row['id']) . '"' . selected($row['id'], $selected) . '>' . h($label) . '</option>';
	}
	return $html;
}

function material_options($rows, $selected){
	$html = '<option value="">Choose the material</option>';
	foreach ($rows as $row) {
		$label = $row['material_name'] . ' — ' . format_money($row['price_per_kg']) . ' per ' . $row['unit'];
		$html .= '<option value="' . h($row['id']) . '"' . selected($row['id'], $selected) . '>' . h($label) . '</option>';
	}
	return $html;
}

function save_photo($field){
	if (empty($_FILES[$field]['name'])) {
		return null;
	}
	if (($_FILES[$field]['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
		return false;
	}
	if (($_FILES[$field]['size'] ?? 0) > 5 * 1024 * 1024) {
		return false;
	}
	$allowed = [
		'image/jpeg' => 'jpg',
		'image/png' => 'png',
		'image/webp' => 'webp',
	];
	$info = @getimagesize($_FILES[$field]['tmp_name']);
	if (!$info || empty($allowed[$info['mime']])) {
		return false;
	}
	$name = 'photo_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $allowed[$info['mime']];
	$dir = dirname(__DIR__) . '/uploads';
	if (!is_dir($dir)) {
		mkdir($dir, 0777, true);
	}
	if (!move_uploaded_file($_FILES[$field]['tmp_name'], $dir . '/' . $name)) {
		return false;
	}
	return $name;
}

function remove_photo($name){
	if (!$name) {
		return;
	}
	$path = dirname(__DIR__) . '/uploads/' . basename($name);
	if (is_file($path)) {
		unlink($path);
	}
}
