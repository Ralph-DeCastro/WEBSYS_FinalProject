<?php
	require_once __DIR__ . '/auth.php';
	$user = current_user();
	$current = $nav_current ?? basename($_SERVER['PHP_SELF']);
	$role = $user['role'];

	$links = [
		'dashboard.php' => 'Home',
	];

	if ($role === 'Resident') {
		$links['schedules.php'] = 'Collection Day';
		$links['segregation.php'] = 'How to Sort';
		$links['biohazard.php'] = 'Biohazard';
		$links['add_complaint.php'] = 'Report a Problem';
		$links['complaints.php'] = 'My Reports';
		$links['announcements.php'] = 'News';
		$links['recycling.php'] = 'Recycling';
	} elseif ($role === 'Collection Personnel') {
		$links['schedules.php'] = 'My Route';
		$links['add_collection.php'] = 'Record a Trip';
		$links['monitoring.php'] = 'Trip History';
		$links['activities.php'] = 'My Day';
		$links['announcements.php'] = 'News';
		$links['segregation.php'] = 'How to Sort';
	} else {
		$links['schedules.php'] = 'Schedules';
		$links['monitoring.php'] = 'Monitoring';
		$links['biohazard.php'] = 'Biohazard';
		$links['complaints.php'] = 'Complaints';
		$links['personnel.php'] = 'Personnel';
		$links['census.php'] = 'Census';
		$links['announcements.php'] = 'News';
		$links['segregation.php'] = 'How to Sort';
		if (sees_all($role)) {
			$links['recycling.php'] = 'Recycling Center';
			$links['reports.php'] = 'Reports';
			$links['barangays.php'] = 'Areas';
		}
		if ($role === 'Administrator' || $role === 'MENRO') {
			$links['users.php'] = 'Users';
		}
	}

	$message = flash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="theme-color" content="#ffffff">
	<title><?php echo h($page_title ?? 'Community Waste Collection') ?></title>
	<link rel="stylesheet" href="assets/style.css?v=<?php echo (int) @filemtime(__DIR__ . '/../assets/style.css') ?>">
	<?php if (!empty($extra_css)) { ?><link rel="stylesheet" href="assets/<?php echo h($extra_css) ?>?v=<?php echo (int) @filemtime(__DIR__ . '/../assets/' . basename($extra_css)) ?>"><?php } ?>
</head>
<body<?php echo !empty($body_class) ? ' class="' . h($body_class) . '"' : '' ?>>
	<a class="skip-link" href="#main">Skip to the page</a>
	<header class="topbar">
		<div>
			<p class="brand-kicker">Community Waste Collection</p>
			<p class="hello">Hello, <?php echo h($user['full_name']) ?></p>
			<p class="role"><?php echo h(role_label($role)) ?><?php echo $user['barangay'] !== '' ? ' · ' . h($user['barangay']) : '' ?></p>
		</div>
		<a class="btn btn-light" href="logout.php">Log out</a>
	</header>
	<nav class="nav" aria-label="Main menu">
		<?php foreach ($links as $file => $label) { ?>
			<a href="<?php echo h($file) ?>" class="<?php echo $current === $file ? 'active' : '' ?>"<?php echo $current === $file ? ' aria-current="page"' : '' ?>><?php echo h($label) ?></a>
		<?php } ?>
	</nav>
	<main class="wrap" id="main">
		<?php if ($message !== '') { ?>
			<div class="alert"><?php echo h($message) ?></div>
		<?php } ?>
