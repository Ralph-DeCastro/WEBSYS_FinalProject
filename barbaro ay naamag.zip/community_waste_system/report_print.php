<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';
	require_once 'includes/charts.php';
	require_once 'includes/report_data.php';

	require_login();
	require_role(['Administrator', 'MENRO']);
	$user = current_user();

	$sections = report_sections($pdo);
	$reports = new Reports($pdo);
	$trend = $reports->daily_trend(30);
	$done = 0; $missed = 0;
	foreach ($trend as $day) {
		$done += $day['done'];
		$missed += $day['missed'];
	}
	$complaints = $reports->complaint_status();
	$rate = ($done + $missed) > 0 ? number_format($done / ($done + $missed) * 100, 1) . '%' : '-';
	$file_name = 'waste-report-' . date('Y-m-d');
	$action = (isset($_GET['action']) && $_GET['action'] === 'print') ? 'print' : 'pdf';
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo h($file_name) ?></title>
	<link rel="stylesheet" href="assets/report.css">
</head>
<body>
	<div class="toolbar no-print">
		<a class="back" href="reports.php">&larr; Back to reports</a>
		<button type="button" id="pdf-btn"<?php echo $action === 'pdf' ? ' autofocus' : '' ?>>Download PDF</button>
		<button type="button" id="print-btn"<?php echo $action === 'print' ? ' autofocus' : '' ?>>Print</button>
		<p id="pdf-status" role="status"><?php echo $action === 'print' ? 'This is how the report will print. Press Print when you are ready, or go back.' : 'This is the report that will be saved. Press Download PDF when you are ready, or go back.' ?></p>
	</div>

	<div id="report">
	<header class="doc-head">
		<p class="org">Community Waste Collection and Environmental Management System</p>
		<h1>Management report</h1>
		<p class="meta">Generated <?php echo h(date('F j, Y, g:i A')) ?> by <?php echo h($user['full_name']) ?>, <?php echo h(role_label($user['role'])) ?></p>
	</header>

	<section class="summary">
		<div><strong><?php echo (int) $done ?></strong><span>Trips completed, last 30 days</span></div>
		<div><strong><?php echo (int) $missed ?></strong><span>Trips missed, last 30 days</span></div>
		<div><strong><?php echo h($rate) ?></strong><span>Completion rate</span></div>
		<div><strong><?php echo (int) ($complaints['New'] + $complaints['In Progress']) ?></strong><span>Open complaints</span></div>
	</section>

	<figure class="chart">
		<figcaption>Collections per day, last 30 days</figcaption>
		<?php echo chart_trend_svg($trend) ?>
		<p class="legend"><span class="key key-done"></span> Completed <span class="key key-missed"></span> Missed</p>
	</figure>

	<?php foreach ($sections as $section) { ?>
		<section class="block">
			<h2><?php echo h($section['title']) ?></h2>
			<?php if (!$section['rows']) { ?>
				<p class="none">No records yet.</p>
			<?php } else { ?>
				<table>
					<thead>
						<tr><?php foreach ($section['heads'] as $head) { ?><th><?php echo h($head) ?></th><?php } ?></tr>
					</thead>
					<tbody>
						<?php foreach ($section['rows'] as $row) { ?>
							<tr><?php foreach ($row as $cell) { ?><td><?php echo h($cell) ?></td><?php } ?></tr>
						<?php } ?>
					</tbody>
				</table>
			<?php } ?>
		</section>
	<?php } ?>

	<section class="signatures">
		<div><span class="line"></span><p>Prepared by</p></div>
		<div><span class="line"></span><p>Noted by, MENRO</p></div>
	</section>
	</div>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
	<script>
	(function () {
		var fileName = <?php echo json_encode($file_name . '.pdf') ?>;
		var statusEl = document.getElementById('pdf-status');
		var pdfBtn = document.getElementById('pdf-btn');

		/* The chart gets its colours from the stylesheet, which the PDF builder cannot see inside an SVG. Copy them onto the shapes first. */
		function inlineSvgStyles(root) {
			var props = ['fill', 'stroke', 'stroke-width', 'font-size', 'font-family', 'font-weight', 'text-anchor'];
			root.querySelectorAll('svg, svg *').forEach(function (node) {
				var cs = window.getComputedStyle(node);
				props.forEach(function (p) { node.style.setProperty(p, cs.getPropertyValue(p)); });
			});
		}

		function downloadPdf() {
			if (typeof html2pdf === 'undefined') {
				statusEl.textContent = 'The PDF tool could not load (no internet?). Press Print, then choose Save as PDF.';
				return;
			}
			var report = document.getElementById('report');
			pdfBtn.disabled = true;
			statusEl.textContent = 'Building your PDF...';
			window.scrollTo(0, 0);
			inlineSvgStyles(report);
			var options = {
				margin: [10, 10, 12, 10],
				filename: fileName,
				image: { type: 'jpeg', quality: 0.98 },
				html2canvas: { scale: 2, useCORS: true, scrollX: 0, scrollY: 0 },
				jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
				pagebreak: { mode: ['css', 'legacy'], avoid: ['tr', 'figure', 'h2', '.signatures'] }
			};
			Promise.resolve(html2pdf().set(options).from(report).save()).then(function () {
				statusEl.textContent = 'Done. ' + fileName + ' was saved to your Downloads folder.';
			}, function () {
				statusEl.textContent = 'Could not build the PDF. Press Print, then choose Save as PDF.';
			}).then(function () {
				pdfBtn.disabled = false;
			});
		}

		pdfBtn.addEventListener('click', downloadPdf);
		document.getElementById('print-btn').addEventListener('click', function () { window.print(); });
	})();
	</script>
</body>
</html>
