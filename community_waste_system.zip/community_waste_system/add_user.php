<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO']);
	$user = current_user();
	$users = new Users($pdo);
	$areas = new Barangays($pdo);
	$allowed_roles = roles_for_creator($user['role']);
	$names = $areas->show_names();

	$form = [
		'full_name' => '',
		'username' => '',
		'role' => 'Resident',
		'barangay' => '',
		'contact_number' => '',
		'address' => '',
		'status' => 'Active',
	];
	$error = '';

	if (isset($_POST['submit'])) {
		foreach ($form as $key => $value) {
			$form[$key] = posted($key);
		}
		$password = (string) ($_POST['password'] ?? '');
		if ($form['full_name'] === '') {
			$error = 'Please type the full name.';
		} elseif (!preg_match('/^[A-Za-z0-9.]{3,30}$/', $form['username'])) {
			$error = 'The username should be 3 to 30 letters or numbers, with no spaces.';
		} elseif (strlen($password) < 6) {
			$error = 'Please use a password with at least 6 characters.';
		} elseif (!in_array($form['role'], $allowed_roles, true)) {
			$error = 'Please choose a valid role.';
		} elseif ($form['role'] !== 'Administrator' && $form['barangay'] === '') {
			$error = 'Please choose a barangay for this person.';
		} elseif (!in_array($form['status'], ['Active', 'Inactive'], true)) {
			$error = 'Please choose Active or Inactive.';
		} else {
			try {
				$users->insert_data($form['full_name'], $form['username'], password_hash($password, PASSWORD_DEFAULT), $form['role'], $form['barangay'], $form['contact_number'], $form['address'], $form['status']);
				set_flash($form['full_name'] . ' can now sign in.');
				header('Location: users.php');
				exit();
			} catch (PDOException $e) {
				$error = $e->getCode() === '23000' ? 'That username is already used. Please choose another one.' : 'The account could not be saved. Please try again.';
			}
		}
	}

	$page_title = 'Add a user';
	$nav_current = 'users.php';
	require 'includes/header.php';
?>
	<h1>Add a user</h1>
	<p class="lead">Create an account for one person. Tell them the username and password yourself.</p>
	<?php if ($error !== '') { ?><div class="alert alert-bad"><?php echo h($error) ?></div><?php } ?>
	<form class="form-card card" method="post">
		<label for="full_name">Full name</label>
		<input id="full_name" type="text" name="full_name" value="<?php echo h($form['full_name']) ?>" required>
		<label for="username">Username <span class="hint">Letters and numbers only. No spaces.</span></label>
		<input id="username" type="text" name="username" value="<?php echo h($form['username']) ?>" required>
		<label for="password">Password <span class="hint">At least 6 characters.</span></label>
		<input id="password" type="password" name="password" required>
		<label for="role">Role</label>
		<select id="role" name="role">
			<?php foreach ($allowed_roles as $role) { ?>
				<option value="<?php echo h($role) ?>"<?php echo selected($form['role'], $role) ?>><?php echo h(role_label($role)) ?></option>
			<?php } ?>
		</select>
		<label for="barangay">Barangay <span class="hint">Leave blank only for a system administrator.</span></label>
		<select id="barangay" name="barangay">
			<option value="">No barangay</option>
			<?php foreach ($names as $name) { ?>
				<option value="<?php echo h($name['barangay_name']) ?>"<?php echo selected($form['barangay'], $name['barangay_name']) ?>><?php echo h($name['barangay_name']) ?></option>
			<?php } ?>
		</select>
		<label for="contact_number">Contact number <span class="hint">Optional.</span></label>
		<input id="contact_number" type="text" name="contact_number" value="<?php echo h($form['contact_number']) ?>">
		<label for="address">Address <span class="hint">Optional.</span></label>
		<input id="address" type="text" name="address" value="<?php echo h($form['address']) ?>">
		<label for="status">Status</label>
		<select id="status" name="status">
			<option value="Active"<?php echo selected($form['status'], 'Active') ?>>Active</option>
			<option value="Inactive"<?php echo selected($form['status'], 'Inactive') ?>>Inactive</option>
		</select>
		<div class="button-row">
			<button name="submit" type="submit">Save user</button>
			<a class="btn btn-secondary" href="users.php">Back to the list</a>
		</div>
	</form>
<?php require 'includes/footer.php'; ?>
