<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	if (!empty($_SESSION['user_id'])) {
		header('Location: dashboard.php');
		exit();
	}

	$error = '';
	$username = '';

	try {
		$users = new Users($pdo);
		$users->show_data();
	} catch (PDOException $e) {
		header('Location: install.php');
		exit();
	}

	if (isset($_POST['submit'])) {
		$username = posted('username');
		$password = (string) ($_POST['password'] ?? '');
		$row = $users->find_by_username($username);

		if ($row && $row['status'] === 'Active' && password_verify($password, $row['password'])) {
			session_regenerate_id(true);
			$_SESSION['user_id'] = $row['id'];
			$_SESSION['full_name'] = $row['full_name'];
			$_SESSION['username'] = $row['username'];
			$_SESSION['role'] = $row['role'];
			$_SESSION['barangay'] = $row['barangay'];
			header('Location: dashboard.php');
			exit();
		}

		$error = 'The username or password is not correct. Please try again.';
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Sign in</title>
	<link rel="stylesheet" href="assets/style.css">
</head>
<body>
	<div class="login-page">
		<main class="login-card">
			<p class="meta">Community Waste Collection</p>
			<h1>Sign in</h1>
			<p class="lead">Barangay means your village or local area. MENRO is the municipal environment office.</p>
			<?php if ($error !== '') { ?>
				<div class="alert alert-bad"><?php echo h($error) ?></div>
			<?php } ?>
			<form method="post">
				<label for="username">Username</label>
				<input id="username" type="text" name="username" autocomplete="username" value="<?php echo h($username) ?>" required>
				<label for="password">Password</label>
				<input id="password" type="password" name="password" autocomplete="current-password" required>
				<div class="button-row">
					<button name="submit" type="submit">Sign in</button>
				</div>
			</form>
			<div class="demo">
				<h2>Sample accounts</h2>
				<p>These accounts are already loaded for the class demonstration.</p>
				<div class="table-wrap">
					<table>
						<tr>
							<th>Who</th>
							<th>Username</th>
							<th>Password</th>
						</tr>
						<tr>
							<td>System Administrator</td>
							<td>admin</td>
							<td>admin123</td>
						</tr>
						<tr>
							<td>MENRO</td>
							<td>m.santos</td>
							<td>menro123</td>
						</tr>
						<tr>
							<td>Barangay Environment Personnel</td>
							<td>j.ramos</td>
							<td>barangay123</td>
						</tr>
						<tr>
							<td>Waste Collection Personnel</td>
							<td>j.delacruz</td>
							<td>collector123</td>
						</tr>
						<tr>
							<td>Community Resident, Poblacion</td>
							<td>r.mendoza</td>
							<td>resident123</td>
						</tr>
						<tr>
							<td>Community Resident, Santa Cruz</td>
							<td>p.santos</td>
							<td>resident123</td>
						</tr>
						<tr>
							<td>Waste Collection Personnel, San Isidro</td>
							<td>a.reyes</td>
							<td>collector123</td>
						</tr>
					</table>
				</div>
			</div>
		</main>
	</div>
</body>
</html>
