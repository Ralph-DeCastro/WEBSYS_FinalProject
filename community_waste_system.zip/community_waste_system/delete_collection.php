<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO', 'Barangay Personnel']);
	$collections = new Collections($pdo);
	$id = (int) ($_POST['id'] ?? $_GET['id'] ?? 0);
	$row = $collections->show_data_id($id);
	if (!$row) {
		deny('That trip could not be found.', 'monitoring.php');
	}
	if (!owns_record($row['barangay'])) {
		deny('You can only remove trips in your own barangay.', 'monitoring.php');
	}
	if (isset($_POST['confirm'])) {
		$collections->delete_data($id);
		set_flash('The trip record was removed.');
		header('Location: monitoring.php');
		exit();
	}

	$page_title = 'Remove a trip';
	$nav_current = 'monitoring.php';
	require 'includes/header.php';
?>
	<h1>Remove this trip record?</h1>
	<p class="lead"><?php echo h(format_date($row['collection_date'])) ?> in <?php echo h($row['barangay'] . ', ' . $row['zone_name']) ?> will be removed from the history.</p>
	<form method="post">
		<input type="hidden" name="id" value="<?php echo (int) $id ?>">
		<div class="button-row">
			<button class="btn-danger" name="confirm" type="submit">Yes, remove this trip</button>
			<a class="btn btn-secondary" href="monitoring.php">No, keep it</a>
		</div>
	</form>
<?php require 'includes/footer.php'; ?>
