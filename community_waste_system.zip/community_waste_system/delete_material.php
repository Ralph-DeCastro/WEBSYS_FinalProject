<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO']);
	$materials = new Materials($pdo);
	$transactions = new Transactions($pdo);
	$id = (int) ($_POST['id'] ?? $_GET['id'] ?? 0);
	$row = $materials->show_data_id($id);
	if (!$row) {
		deny('That material could not be found.', 'recycling.php');
	}
	$error = '';
	$used = $transactions->count_by_material($id);
	if ($used > 0) {
		$error = 'This material is already used on a transaction. Mark it Inactive instead of removing it.';
	} elseif (isset($_POST['confirm'])) {
		$materials->delete_data($id);
		set_flash('The material was removed.');
		header('Location: recycling.php');
		exit();
	}

	$page_title = 'Remove a material';
	$nav_current = 'recycling.php';
	require 'includes/header.php';
?>
	<h1>Remove this material?</h1>
	<p class="lead"><?php echo h($row['material_name']) ?> will be removed from the center list.</p>
	<?php if ($error !== '') { ?>
		<div class="alert alert-bad"><?php echo h($error) ?></div>
		<a class="btn btn-secondary" href="recycling.php">Back to the center</a>
	<?php } else { ?>
		<form method="post">
			<input type="hidden" name="id" value="<?php echo (int) $id ?>">
			<div class="button-row">
				<button class="btn-danger" name="confirm" type="submit">Yes, remove this material</button>
				<a class="btn btn-secondary" href="recycling.php">No, keep it</a>
			</div>
		</form>
	<?php } ?>
<?php require 'includes/footer.php'; ?>
