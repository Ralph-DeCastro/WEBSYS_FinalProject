<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO', 'Barangay Personnel', 'Collection Personnel']);
	$user = current_user();
	$activities = new Activities($pdo);
	if ($user['role'] === 'Collection Personnel') {
		$rows = $activities->show_filtered('', (int) $user['id']);
	} elseif (!sees_all($user['role'])) {
		$rows = $activities->show_filtered($user['barangay'], 0);
	} else {
		$rows = $activities->show_data();
	}

	$page_title = 'Daily activity';
	$nav_current = $user['role'] === 'Collection Personnel' ? 'activities.php' : 'personnel.php';
	require 'includes/header.php';
?>
	<h1><?php echo $user['role'] === 'Collection Personnel' ? 'My day' : 'Daily activity' ?></h1>
	<p class="lead">This is a short note about what a collector did on a given day.</p>
	<div class="button-row">
		<a class="btn" href="add_activity.php">Write an activity</a>
	</div>
	<?php if (!$rows) { ?>
		<div class="empty"><p>No daily notes have been saved yet.</p></div>
	<?php } else { ?>
		<div class="table-wrap">
			<table>
				<tr>
					<th>Date</th>
					<th>Collector</th>
					<th>What was done</th>
					<th>Status</th>
					<th>Note</th>
					<th>Actions</th>
				</tr>
				<?php foreach ($rows as $row) { ?>
					<tr>
						<td><?php echo h(format_date($row['activity_date'])) ?></td>
						<td><?php echo h($row['personnel_name']) ?></td>
						<td><?php echo h($row['task_done']) ?></td>
						<td><?php echo badge($row['status']) ?></td>
						<td><?php echo h($row['notes']) ?></td>
						<td class="actions">
							<?php if ($user['role'] !== 'Collection Personnel' || (int) $row['personnel_id'] === (int) $user['id']) { ?>
								<a href="edit_activity.php?id=<?php echo (int) $row['id'] ?>">Edit</a>
								<a href="delete_activity.php?id=<?php echo (int) $row['id'] ?>">Remove</a>
							<?php } ?>
						</td>
					</tr>
				<?php } ?>
			</table>
		</div>
	<?php } ?>
<?php require 'includes/footer.php'; ?>
