<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	$user = current_user();
	if ($user['role'] === 'Collection Personnel') {
		deny('Complaints are handled by the barangay and the environment office.', 'dashboard.php');
	}
	$complaints = new Complaints($pdo);
	$status = (string) ($_GET['status'] ?? '');
	if (!in_array($status, ['', 'New', 'In Progress', 'Resolved'], true)) {
		$status = '';
	}
	if ($user['role'] === 'Resident') {
		$rows = $complaints->show_filtered('', $status, (int) $user['id']);
	} elseif (!sees_all($user['role'])) {
		$rows = $complaints->show_filtered($user['barangay'], $status, 0);
	} else {
		$rows = $complaints->show_filtered('', $status, 0);
	}
	$can_manage = in_array($user['role'], ['Administrator', 'MENRO', 'Barangay Personnel'], true);

	$page_title = $user['role'] === 'Resident' ? 'My reports' : 'Complaints';
	$nav_current = 'complaints.php';
	require 'includes/header.php';
?>
	<h1><?php echo $user['role'] === 'Resident' ? 'My reports' : 'Environmental complaints' ?></h1>
	<p class="lead"><?php echo $user['role'] === 'Resident' ? 'These are the problems you sent to the office.' : 'These are problems reported by residents.' ?></p>
	<div class="button-row">
		<a class="btn" href="add_complaint.php">Report a problem</a>
	</div>
	<form class="filter" method="get">
		<div>
			<label for="status">Show</label>
			<select id="status" name="status">
				<option value="">All reports</option>
				<option value="New"<?php echo selected($status, 'New') ?>>New</option>
				<option value="In Progress"<?php echo selected($status, 'In Progress') ?>>In progress</option>
				<option value="Resolved"<?php echo selected($status, 'Resolved') ?>>Resolved</option>
			</select>
		</div>
		<button type="submit">Show the list</button>
	</form>
	<?php if (!$rows) { ?>
		<div class="empty"><p>No reports match this list yet.</p></div>
	<?php } else { ?>
		<p class="scroll-hint">Move sideways if you cannot see every column.</p>
		<div class="table-wrap">
			<table>
				<tr>
					<th>Date</th>
					<th>Problem</th>
					<th>Where</th>
					<?php if ($user['role'] !== 'Resident') { ?><th>Reported by</th><?php } ?>
					<th>Status</th>
					<th>Actions</th>
				</tr>
				<?php foreach ($rows as $row) { ?>
					<tr>
						<td><?php echo h(format_date($row['created_at'])) ?></td>
						<td><?php echo h($row['complaint_type']) ?></td>
						<td><?php echo h($row['barangay']) ?><br><span class="meta"><?php echo h($row['location']) ?></span></td>
						<?php if ($user['role'] !== 'Resident') { ?><td><?php echo h($row['resident_name']) ?></td><?php } ?>
						<td><?php echo badge($row['status']) ?></td>
						<td class="actions">
							<a href="view_complaint.php?id=<?php echo (int) $row['id'] ?>">Open</a>
							<?php if ($can_manage && sees_all($user['role'])) { ?>
								<a href="delete_complaint.php?id=<?php echo (int) $row['id'] ?>">Remove</a>
							<?php } ?>
						</td>
					</tr>
				<?php } ?>
			</table>
		</div>
	<?php } ?>
<?php require 'includes/footer.php'; ?>
