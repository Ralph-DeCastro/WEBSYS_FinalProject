<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO']);
	$materials = new Materials($pdo);
	$form = [
		'material_name' => '',
		'category' => 'Recyclable',
		'unit' => 'kg',
		'price_per_kg' => '',
		'status' => 'Active',
	];
	$error = '';

	if (isset($_POST['submit'])) {
		foreach ($form as $key => $value) {
			$form[$key] = posted($key);
		}
		if ($form['material_name'] === '') {
			$error = 'Please type the material name.';
		} elseif (!is_numeric($form['price_per_kg']) || (float) $form['price_per_kg'] < 0) {
			$error = 'Please type the price per kilo. Use 0 if the center accepts it for free.';
		} elseif (!in_array($form['status'], ['Active', 'Inactive'], true)) {
			$error = 'Please choose Active or Inactive.';
		} else {
			$materials->insert_data($form['material_name'], $form['category'] === '' ? 'Recyclable' : $form['category'], $form['unit'] === '' ? 'kg' : $form['unit'], (float) $form['price_per_kg'], $form['status']);
			set_flash('The material was saved.');
			header('Location: recycling.php');
			exit();
		}
	}

	$page_title = 'Add a material';
	$nav_current = 'recycling.php';
	require 'includes/header.php';
?>
	<h1>Add a material</h1>
	<p class="lead">This is one item the recycling center accepts, and the price paid per kilo.</p>
	<?php if ($error !== '') { ?><div class="alert alert-bad"><?php echo h($error) ?></div><?php } ?>
	<form class="form-card card" method="post">
		<label for="material_name">Material name</label>
		<input id="material_name" type="text" name="material_name" value="<?php echo h($form['material_name']) ?>" required>
		<label for="category">Category</label>
		<input id="category" type="text" name="category" value="<?php echo h($form['category']) ?>">
		<label for="unit">Unit</label>
		<input id="unit" type="text" name="unit" value="<?php echo h($form['unit']) ?>">
		<label for="price_per_kg">Price per kilo (PHP)</label>
		<input id="price_per_kg" type="number" name="price_per_kg" min="0" step="0.01" value="<?php echo h($form['price_per_kg']) ?>" required>
		<label for="status">Status</label>
		<select id="status" name="status">
			<option value="Active"<?php echo selected($form['status'], 'Active') ?>>Active</option>
			<option value="Inactive"<?php echo selected($form['status'], 'Inactive') ?>>Inactive</option>
		</select>
		<div class="button-row">
			<button name="submit" type="submit">Save material</button>
			<a class="btn btn-secondary" href="recycling.php">Back to the center</a>
		</div>
	</form>
<?php require 'includes/footer.php'; ?>
