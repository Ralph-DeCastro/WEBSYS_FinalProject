<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO']);
	$user = current_user();
	$users = new Users($pdo);
	$areas = new Barangays($pdo);
	$id = (int) ($_POST['id'] ?? $_GET['id'] ?? 0);
	$row = $users->show_data_id($id);
	if (!$row) {
		deny('That account could not be found.', 'users.php');
	}
	if ($user['role'] !== 'Administrator' && $row['role'] === 'Administrator') {
		deny('Only a system administrator can change that account.', 'users.php');
	}

	$allowed_roles = roles_for_creator($user['role']);
	$names = $areas->show_names();
	$form = [
		'full_name' => $row['full_name'],
		'username' => $row['username'],
		'role' => $row['role'],
		'barangay' => $row['barangay'],
		'contact_number' => $row['contact_number'],
		'address' => $row['address'],
		'status' => $row['status'],
	];
	$error = '';

	if (isset($_POST['edit'])) {
		foreach ($form as $key => $value) {
			$form[$key] = posted($key);
		}
		$password = (string) ($_POST['password'] ?? '');
		if ($form['full_name'] === '') {
			$error = 'Please type the full name.';
		} elseif (!preg_match('/^[A-Za-z0-9.]{3,30}$/', $form['username'])) {
			$error = 'The username should be 3 to 30 letters or numbers, with no spaces.';
		} elseif ($password !== '' && strlen($password) < 6) {
			$error = 'Please use a password with at least 6 characters, or leave it blank to keep the old one.';
		} elseif (!in_array($form['role'], $allowed_roles, true)) {
			$error = 'Please choose a valid role.';
		} elseif ($form['role'] !== 'Administrator' && $form['barangay'] === '') {
			$error = 'Please choose a barangay for this person.';
		} elseif ((int) $id === (int) $user['id'] && $form['status'] !== 'Active') {
			$error = 'You cannot turn off the account you are using.';
		} elseif ($row['role'] === 'Administrator' && $form['role'] !== 'Administrator' && $users->count_by_role('Administrator') <= 1) {
			$error = 'Keep at least one system administrator.';
		} else {
			try {
				$users->update_data($id, $form['full_name'], $form['username'], $form['role'], $form['barangay'], $form['contact_number'], $form['address'], $form['status']);
				if ($password !== '') {
					$users->update_password($id, password_hash($password, PASSWORD_DEFAULT));
				}
				if ((int) $id === (int) $user['id']) {
					$_SESSION['full_name'] = $form['full_name'];
					$_SESSION['username'] = $form['username'];
					$_SESSION['role'] = $form['role'];
					$_SESSION['barangay'] = $form['barangay'];
				}
				set_flash('The account was updated.');
				header('Location: users.php');
				exit();
			} catch (PDOException $e) {
				$error = $e->getCode() === '23000' ? 'That username is already used. Please choose another one.' : 'The account could not be saved. Please try again.';
			}
		}
	}

	$page_title = 'Edit a user';
	$nav_current = 'users.php';
	require 'includes/header.php';
?>
	<h1>Edit a user</h1>
	<p class="lead">Change this account. Leave the password blank if it should stay the same.</p>
	<?php if ($error !== '') { ?><div class="alert alert-bad"><?php echo h($error) ?></div><?php } ?>
	<form class="form-card card" method="post">
		<input type="hidden" name="id" value="<?php echo (int) $id ?>">
		<label for="full_name">Full name</label>
		<input id="full_name" type="text" name="full_name" value="<?php echo h($form['full_name']) ?>" required>
		<label for="username">Username</label>
		<input id="username" type="text" name="username" value="<?php echo h($form['username']) ?>" required>
		<label for="password">New password <span class="hint">Optional. Leave blank to keep the current password.</span></label>
		<input id="password" type="password" name="password">
		<label for="role">Role</label>
		<select id="role" name="role">
			<?php foreach ($allowed_roles as $role) { ?>
				<option value="<?php echo h($role) ?>"<?php echo selected($form['role'], $role) ?>><?php echo h(role_label($role)) ?></option>
			<?php } ?>
		</select>
		<label for="barangay">Barangay</label>
		<select id="barangay" name="barangay">
			<option value="">No barangay</option>
			<?php foreach ($names as $name) { ?>
				<option value="<?php echo h($name['barangay_name']) ?>"<?php echo selected($form['barangay'], $name['barangay_name']) ?>><?php echo h($name['barangay_name']) ?></option>
			<?php } ?>
			<?php if ($form['barangay'] !== '' && !in_array($form['barangay'], array_column($names, 'barangay_name'), true)) { ?>
				<option value="<?php echo h($form['barangay']) ?>" selected><?php echo h($form['barangay']) ?></option>
			<?php } ?>
		</select>
		<label for="contact_number">Contact number <span class="hint">Optional.</span></label>
		<input id="contact_number" type="text" name="contact_number" value="<?php echo h($form['contact_number']) ?>">
		<label for="address">Address <span class="hint">Optional.</span></label>
		<input id="address" type="text" name="address" value="<?php echo h($form['address']) ?>">
		<label for="status">Status</label>
		<select id="status" name="status">
			<option value="Active"<?php echo selected($form['status'], 'Active') ?>>Active</option>
			<option value="Inactive"<?php echo selected($form['status'], 'Inactive') ?>>Inactive</option>
		</select>
		<div class="button-row">
			<button name="edit" type="submit">Save changes</button>
			<a class="btn btn-secondary" href="users.php">Back to the list</a>
		</div>
	</form>
<?php require 'includes/footer.php'; ?>
