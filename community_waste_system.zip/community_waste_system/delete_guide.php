<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO']);
	$guides = new Guides($pdo);
	$id = (int) ($_POST['id'] ?? $_GET['id'] ?? 0);
	$row = $guides->show_data_id($id);
	if (!$row) {
		deny('That guide could not be found.', 'segregation.php');
	}
	if (isset($_POST['confirm'])) {
		$guides->delete_data($id);
		set_flash('The sorting guide was removed.');
		header('Location: segregation.php');
		exit();
	}

	$page_title = 'Remove a sorting guide';
	$nav_current = 'segregation.php';
	require 'includes/header.php';
?>
	<h1>Remove this guide?</h1>
	<p class="lead"><?php echo h($row['waste_type']) ?> will no longer appear on the How to Sort page.</p>
	<form method="post">
		<input type="hidden" name="id" value="<?php echo (int) $id ?>">
		<div class="button-row">
			<button class="btn-danger" name="confirm" type="submit">Yes, remove this guide</button>
			<a class="btn btn-secondary" href="segregation.php">No, keep it</a>
		</div>
	</form>
<?php require 'includes/footer.php'; ?>
