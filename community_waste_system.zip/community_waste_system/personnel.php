<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO', 'Barangay Personnel']);
	$user = current_user();
	$users = new Users($pdo);
	$barangay = sees_all($user['role']) ? '' : $user['barangay'];
	$rows = $users->show_by_role('Collection Personnel', $barangay);

	$page_title = 'Collection personnel';
	$nav_current = 'personnel.php';
	require 'includes/header.php';
?>
	<h1>Collection personnel</h1>
	<p class="lead"><?php echo sees_all($user['role']) ? 'These are the workers who collect waste.' : 'These are the collectors in ' . h($user['barangay']) . '.' ?></p>
	<div class="button-row">
		<a class="btn" href="add_assignment.php">Assign a route</a>
		<a class="btn btn-secondary" href="activities.php">Daily activity</a>
		<a class="btn btn-secondary" href="assignments.php">All assignments</a>
		<?php if (sees_all($user['role'])) { ?>
			<a class="btn btn-secondary" href="add_user.php">Add a person</a>
		<?php } ?>
	</div>
	<?php if (!$rows) { ?>
		<div class="empty"><p>No collection workers are listed<?php echo $barangay !== '' ? ' for this barangay' : '' ?> yet.</p></div>
	<?php } else { ?>
		<div class="table-wrap">
			<table>
				<tr>
					<th>Name</th>
					<th>Barangay</th>
					<th>Contact</th>
					<th>Status</th>
					<?php if (sees_all($user['role'])) { ?><th>Actions</th><?php } ?>
				</tr>
				<?php foreach ($rows as $row) { ?>
					<tr>
						<td><?php echo h($row['full_name']) ?><br><span class="meta"><?php echo h($row['username']) ?></span></td>
						<td><?php echo h($row['barangay']) ?></td>
						<td><?php echo h($row['contact_number']) ?></td>
						<td><?php echo badge($row['status']) ?></td>
						<?php if (sees_all($user['role'])) { ?>
							<td class="actions"><a href="edit_user.php?id=<?php echo (int) $row['id'] ?>">Edit account</a></td>
						<?php } ?>
					</tr>
				<?php } ?>
			</table>
		</div>
	<?php } ?>
<?php require 'includes/footer.php'; ?>
