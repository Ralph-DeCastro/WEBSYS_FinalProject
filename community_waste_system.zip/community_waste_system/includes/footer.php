	</main>
	<footer class="site-footer">
		<p>Community Waste Collection and Environmental Management System</p>
	</footer>
</body>
</html>
