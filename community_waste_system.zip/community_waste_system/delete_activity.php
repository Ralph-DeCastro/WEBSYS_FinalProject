<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO', 'Barangay Personnel', 'Collection Personnel']);
	$user = current_user();
	$activities = new Activities($pdo);
	$id = (int) ($_POST['id'] ?? $_GET['id'] ?? 0);
	$row = $activities->show_data_id($id);
	if (!$row) {
		deny('That note could not be found.', 'activities.php');
	}
	if ($user['role'] === 'Collection Personnel' && (int) $row['personnel_id'] !== (int) $user['id']) {
		deny('You can only remove your own daily notes.', 'activities.php');
	}
	if ($user['role'] === 'Barangay Personnel' && $row['personnel_barangay'] !== $user['barangay']) {
		deny('You can only remove notes for collectors in your barangay.', 'activities.php');
	}
	if (isset($_POST['confirm'])) {
		$activities->delete_data($id);
		set_flash('The daily note was removed.');
		header('Location: activities.php');
		exit();
	}

	$page_title = 'Remove an activity';
	$nav_current = $user['role'] === 'Collection Personnel' ? 'activities.php' : 'personnel.php';
	require 'includes/header.php';
?>
	<h1>Remove this note?</h1>
	<p class="lead"><?php echo h($row['task_done']) ?> by <?php echo h($row['personnel_name']) ?> on <?php echo h(format_date($row['activity_date'])) ?> will be removed.</p>
	<form method="post">
		<input type="hidden" name="id" value="<?php echo (int) $id ?>">
		<div class="button-row">
			<button class="btn-danger" name="confirm" type="submit">Yes, remove this note</button>
			<a class="btn btn-secondary" href="activities.php">No, keep it</a>
		</div>
	</form>
<?php require 'includes/footer.php'; ?>
