<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO']);
	$transactions = new Transactions($pdo);
	$id = (int) ($_POST['id'] ?? $_GET['id'] ?? 0);
	$row = $transactions->show_data_id($id);
	if (!$row) {
		deny('That transaction could not be found.', 'recycling.php');
	}
	if (isset($_POST['confirm'])) {
		$transactions->delete_data($id);
		set_flash('The transaction was removed.');
		header('Location: recycling.php');
		exit();
	}

	$page_title = 'Remove a transaction';
	$nav_current = 'recycling.php';
	require 'includes/header.php';
?>
	<h1>Remove this transaction?</h1>
	<p class="lead"><?php echo h(format_weight($row['weight_kg'])) ?> of <?php echo h($row['material_name']) ?> from <?php echo h($row['person_name']) ?> on <?php echo h(format_date($row['record_date'])) ?> will be removed.</p>
	<form method="post">
		<input type="hidden" name="id" value="<?php echo (int) $id ?>">
		<div class="button-row">
			<button class="btn-danger" name="confirm" type="submit">Yes, remove this transaction</button>
			<a class="btn btn-secondary" href="recycling.php">No, keep it</a>
		</div>
	</form>
<?php require 'includes/footer.php'; ?>
