<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO']);
	$user = current_user();
	$users = new Users($pdo);
	$schedules = new Schedules($pdo);
	$id = (int) ($_POST['id'] ?? $_GET['id'] ?? 0);
	$row = $users->show_data_id($id);
	if (!$row) {
		deny('That account could not be found.', 'users.php');
	}
	if ($user['role'] !== 'Administrator' && $row['role'] === 'Administrator') {
		deny('Only a system administrator can remove that account.', 'users.php');
	}

	$error = '';
	$assigned = $schedules->count_by_personnel($id);
	if ((int) $id === (int) $user['id']) {
		$error = 'You cannot remove the account you are using.';
	} elseif ($row['role'] === 'Administrator' && $users->count_by_role('Administrator') <= 1) {
		$error = 'Keep at least one system administrator.';
	} elseif ($assigned > 0) {
		$error = 'This person is still on a collection schedule. Change that schedule first.';
	} elseif (isset($_POST['confirm'])) {
		$users->delete_data($id);
		set_flash($row['full_name'] . ' was removed.');
		header('Location: users.php');
		exit();
	}

	$page_title = 'Remove a user';
	$nav_current = 'users.php';
	require 'includes/header.php';
?>
	<h1>Remove this user?</h1>
	<p class="lead"><?php echo h($row['full_name']) ?> will no longer be able to sign in.</p>
	<?php if ($error !== '') { ?>
		<div class="alert alert-bad"><?php echo h($error) ?></div>
		<a class="btn btn-secondary" href="users.php">Back to the list</a>
	<?php } else { ?>
		<form method="post">
			<input type="hidden" name="id" value="<?php echo (int) $id ?>">
			<div class="button-row">
				<button class="btn-danger" name="confirm" type="submit">Yes, remove this user</button>
				<a class="btn btn-secondary" href="users.php">No, keep this user</a>
			</div>
		</form>
	<?php } ?>
<?php require 'includes/footer.php'; ?>
