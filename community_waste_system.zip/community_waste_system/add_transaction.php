<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO']);
	$user = current_user();
	$materials = new Materials($pdo);
	$transactions = new Transactions($pdo);
	$users = new Users($pdo);
	$catalog = $materials->show_active();
	$residents = $users->show_by_role('Resident');
	$types = ['Drop-off', 'Sale', 'Center pickup'];
	$form = [
		'material_id' => '',
		'transaction_type' => 'Drop-off',
		'person_user_id' => '',
		'person_name' => '',
		'weight_kg' => '',
		'record_date' => date('Y-m-d'),
		'notes' => '',
	];
	$error = '';

	if (isset($_POST['submit'])) {
		foreach ($form as $key => $value) {
			$form[$key] = posted($key);
		}
		$material = $materials->show_data_id((int) $form['material_id']);
		$person_id = null;
		if ($form['person_user_id'] !== '') {
			$person = $users->show_data_id((int) $form['person_user_id']);
			if ($person) {
				$person_id = (int) $person['id'];
				$form['person_name'] = $person['full_name'];
			}
		}
		if (!$material || $material['status'] !== 'Active') {
			$error = 'Please choose an active material.';
		} elseif (!in_array($form['transaction_type'], $types, true)) {
			$error = 'Please choose the kind of transaction.';
		} elseif ($form['person_name'] === '') {
			$error = 'Please type the name, or choose a resident.';
		} elseif (!is_numeric($form['weight_kg']) || (float) $form['weight_kg'] <= 0) {
			$error = 'Please type the weight in kilos.';
		} elseif (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $form['record_date'])) {
			$error = 'Please choose the date.';
		} else {
			$amount = round((float) $form['weight_kg'] * (float) $material['price_per_kg'], 2);
			$transactions->insert_data((int) $material['id'], $form['transaction_type'], $form['person_name'], $person_id, (float) $form['weight_kg'], $amount, $form['record_date'], $form['notes'], (int) $user['id']);
			set_flash('The transaction was saved. Amount: ' . format_money($amount) . '.');
			header('Location: recycling.php');
			exit();
		}
	}

	$page_title = 'Record a transaction';
	$nav_current = 'recycling.php';
	require 'includes/header.php';
?>
	<h1>Record a transaction</h1>
	<p class="lead">The amount is the weight times the current price per kilo.</p>
	<?php if ($error !== '') { ?><div class="alert alert-bad"><?php echo h($error) ?></div><?php } ?>
	<?php if (!$catalog) { ?>
		<div class="empty"><p>Add an active material before recording a transaction.</p></div>
		<a class="btn" href="add_material.php">Add a material</a>
	<?php } else { ?>
		<form class="form-card card" method="post">
			<label for="material_id">Material</label>
			<select id="material_id" name="material_id" required>
				<?php echo material_options($catalog, $form['material_id']) ?>
			</select>
			<label for="transaction_type">Kind of transaction</label>
			<select id="transaction_type" name="transaction_type">
				<?php foreach ($types as $type) { ?>
					<option<?php echo selected($form['transaction_type'], $type) ?>><?php echo h($type) ?></option>
				<?php } ?>
			</select>
			<label for="person_user_id">Resident <span class="hint">Optional. Leave blank for a buyer or a walk-in.</span></label>
			<select id="person_user_id" name="person_user_id">
				<?php echo user_options($residents, $form['person_user_id'], 'Type the name instead') ?>
			</select>
			<label for="person_name">Name</label>
			<input id="person_name" type="text" name="person_name" value="<?php echo h($form['person_name']) ?>">
			<label for="weight_kg">Weight (kg)</label>
			<input id="weight_kg" type="number" name="weight_kg" min="0.1" step="0.1" value="<?php echo h($form['weight_kg']) ?>" required>
			<label for="record_date">Date</label>
			<input id="record_date" type="date" name="record_date" value="<?php echo h($form['record_date']) ?>" required>
			<label for="notes">Notes <span class="hint">Optional.</span></label>
			<textarea id="notes" name="notes"><?php echo h($form['notes']) ?></textarea>
			<div class="button-row">
				<button name="submit" type="submit">Save transaction</button>
				<a class="btn btn-secondary" href="recycling.php">Back to the center</a>
			</div>
		</form>
	<?php } ?>
<?php require 'includes/footer.php'; ?>
