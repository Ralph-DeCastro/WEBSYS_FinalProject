<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	$user = current_user();
	$news = new Announcements($pdo);
	$can_edit = in_array($user['role'], ['Administrator', 'MENRO', 'Barangay Personnel'], true);
	$rows = $can_edit ? $news->show_data() : $news->show_for_role($user['role']);

	$page_title = 'News and reminders';
	$nav_current = 'announcements.php';
	require 'includes/header.php';
?>
	<h1>News and reminders</h1>
	<p class="lead">Collection announcements, campaigns, recycling programs, and sorting reminders.</p>
	<?php if ($can_edit) { ?>
		<div class="button-row"><a class="btn" href="add_announcement.php">Post an announcement</a></div>
	<?php } ?>
	<?php if (!$rows) { ?>
		<div class="empty"><p>There is no news to show yet.</p></div>
	<?php } else { ?>
		<div class="news-list">
			<?php foreach ($rows as $row) { ?>
				<article class="card news-item">
					<p class="meta"><?php echo h($row['category']) ?> · <?php echo h(format_date($row['publish_date'])) ?> · For <?php echo h($row['audience']) ?></p>
					<h2><?php echo h($row['title']) ?></h2>
					<p><?php echo nl2br(h($row['body'])) ?></p>
					<?php if ($can_edit) { ?>
						<p><?php echo badge($row['status']) ?> <span class="meta">Posted by <?php echo h($row['author_name']) ?></span></p>
						<div class="button-row">
							<a class="btn btn-secondary" href="edit_announcement.php?id=<?php echo (int) $row['id'] ?>">Edit</a>
							<a class="btn btn-danger" href="delete_announcement.php?id=<?php echo (int) $row['id'] ?>">Remove</a>
						</div>
					<?php } ?>
				</article>
			<?php } ?>
		</div>
	<?php } ?>
<?php require 'includes/footer.php'; ?>
