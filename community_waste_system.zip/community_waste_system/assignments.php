<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO', 'Barangay Personnel', 'Collection Personnel']);
	$user = current_user();
	$assignments = new Assignments($pdo);
	if ($user['role'] === 'Collection Personnel') {
		$rows = $assignments->show_filtered('', (int) $user['id']);
	} elseif (!sees_all($user['role'])) {
		$rows = $assignments->show_filtered($user['barangay'], 0);
	} else {
		$rows = $assignments->show_data();
	}
	$can_edit = in_array($user['role'], ['Administrator', 'MENRO', 'Barangay Personnel'], true);

	$page_title = 'Assignments';
	$nav_current = 'personnel.php';
	require 'includes/header.php';
?>
	<h1><?php echo $user['role'] === 'Collection Personnel' ? 'My assignments' : 'Assignment schedule' ?></h1>
	<p class="lead">A dated assignment tells a collector which route to take on one day.</p>
	<?php if ($can_edit) { ?>
		<div class="button-row"><a class="btn" href="add_assignment.php">Assign a route</a></div>
	<?php } ?>
	<?php if (!$rows) { ?>
		<div class="empty"><p>No assignments have been saved yet.</p></div>
	<?php } else { ?>
		<p class="scroll-hint">Move sideways if you cannot see every column.</p>
		<div class="table-wrap">
			<table>
				<tr>
					<th>Date</th>
					<th>Collector</th>
					<th>Route</th>
					<th>Shift</th>
					<th>Status</th>
					<th>Note</th>
					<?php if ($can_edit) { ?><th>Actions</th><?php } ?>
				</tr>
				<?php foreach ($rows as $row) { ?>
					<tr>
						<td><?php echo h(format_date($row['assignment_date'])) ?></td>
						<td><?php echo h($row['personnel_name']) ?></td>
						<td><?php echo $row['barangay'] ? h($row['barangay'] . ', ' . $row['zone_name'] . ' — ' . $row['waste_category']) : 'Route was removed' ?></td>
						<td><?php echo h($row['shift_label']) ?></td>
						<td><?php echo badge($row['status']) ?></td>
						<td><?php echo h($row['notes']) ?></td>
						<?php if ($can_edit) { ?>
							<td class="actions">
								<a href="edit_assignment.php?id=<?php echo (int) $row['id'] ?>">Edit</a>
								<a href="delete_assignment.php?id=<?php echo (int) $row['id'] ?>">Remove</a>
							</td>
						<?php } ?>
					</tr>
				<?php } ?>
			</table>
		</div>
	<?php } ?>
<?php require 'includes/footer.php'; ?>
