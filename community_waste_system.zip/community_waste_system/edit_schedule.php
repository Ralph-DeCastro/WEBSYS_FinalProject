<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO', 'Barangay Personnel']);
	$user = current_user();
	$schedules = new Schedules($pdo);
	$areas_model = new Barangays($pdo);
	$users = new Users($pdo);
	$id = (int) ($_POST['id'] ?? $_GET['id'] ?? 0);
	$row = $schedules->show_data_id($id);
	if (!$row) {
		deny('That collection day could not be found.', 'schedules.php');
	}
	if (!owns_record($row['barangay'])) {
		deny('You can only change collection days in your own barangay.', 'schedules.php');
	}

	$areas = $areas_model->show_data();
	if (!sees_all($user['role'])) {
		$areas = array_values(array_filter($areas, function ($area) use ($user) {
			return $area['barangay_name'] === $user['barangay'];
		}));
	}
	$people = $users->show_by_role('Collection Personnel', sees_all($user['role']) ? '' : $user['barangay']);
	$selected_area = '';
	foreach ($areas as $area) {
		if ($area['barangay_name'] === $row['barangay'] && $area['zone_name'] === $row['zone_name']) {
			$selected_area = $area['id'];
		}
	}
	$stored_days = array_map('trim', explode(',', (string) $row['collection_day']));
	$form = [
		'area_id' => $selected_area,
		'waste_category' => $row['waste_category'],
		'personnel_id' => $row['personnel_id'],
		'frequency' => $row['frequency'],
		'days' => array_values(array_intersect(weekdays(), $stored_days)),
		'collection_time' => time_input($row['collection_time']),
		'notes' => $row['notes'],
		'status' => $row['status'],
	];
	$error = '';

	if (isset($_POST['edit'])) {
		$form['area_id'] = posted('area_id');
		$form['waste_category'] = posted('waste_category');
		$form['personnel_id'] = posted('personnel_id');
		$form['frequency'] = posted('frequency');
		$form['collection_time'] = posted('collection_time');
		$form['notes'] = posted('notes');
		$form['status'] = posted('status');
		$days = $_POST['days'] ?? [];
		$form['days'] = is_array($days) ? array_values(array_intersect(weekdays(), $days)) : [];
		$area = $areas_model->show_data_id((int) $form['area_id']);
		$person = $users->show_data_id((int) $form['personnel_id']);

		if (!$area) {
			$error = 'Please choose an area.';
		} elseif (!owns_record($area['barangay_name'])) {
			$error = 'You can only save a schedule for your own barangay.';
		} elseif (!in_array($form['waste_category'], waste_categories(), true)) {
			$error = 'Please choose the kind of waste.';
		} elseif (!$person || $person['role'] !== 'Collection Personnel') {
			$error = 'Please choose a collection worker.';
		} elseif (!sees_all($user['role']) && $person['barangay'] !== $user['barangay']) {
			$error = 'Choose a collector from your barangay.';
		} elseif (!in_array($form['frequency'], frequencies(), true)) {
			$error = 'Please choose how often the truck comes.';
		} elseif (!$form['days']) {
			$error = 'Please choose at least one day.';
		} elseif ($form['collection_time'] === '') {
			$error = 'Please choose the time.';
		} else {
			$schedules->update_data($id, $area['barangay_name'], $area['zone_name'], $form['waste_category'], (int) $person['id'], $form['frequency'], implode(', ', $form['days']), $form['collection_time'], $form['notes'], $form['status'] === 'Inactive' ? 'Inactive' : 'Active');
			set_flash('The collection day was updated.');
			header('Location: schedules.php');
			exit();
		}
	}

	$page_title = 'Edit a collection day';
	$nav_current = 'schedules.php';
	require 'includes/header.php';
?>
	<h1>Edit a collection day</h1>
	<p class="lead">This is the standing route for <?php echo h($row['barangay'] . ', ' . $row['zone_name']) ?>.</p>
	<?php if ($error !== '') { ?><div class="alert alert-bad"><?php echo h($error) ?></div><?php } ?>
	<form class="form-card card" method="post">
		<input type="hidden" name="id" value="<?php echo (int) $id ?>">
		<label for="area_id">Area</label>
		<select id="area_id" name="area_id" required>
			<?php echo area_options($areas, $form['area_id']) ?>
		</select>
		<label for="waste_category">Kind of waste</label>
		<select id="waste_category" name="waste_category">
			<?php foreach (waste_categories() as $category) { ?>
				<option<?php echo selected($form['waste_category'], $category) ?>><?php echo h($category) ?></option>
			<?php } ?>
		</select>
		<label for="personnel_id">Collector</label>
		<select id="personnel_id" name="personnel_id" required>
			<?php echo user_options($people, $form['personnel_id'], 'Choose a collector') ?>
		</select>
		<label for="frequency">How often</label>
		<select id="frequency" name="frequency">
			<?php foreach (frequencies() as $frequency) { ?>
				<option<?php echo selected($form['frequency'], $frequency) ?>><?php echo h($frequency) ?></option>
			<?php } ?>
		</select>
		<label>Days</label>
		<div class="checks">
			<?php foreach (weekdays() as $day) { ?>
				<label><input type="checkbox" name="days[]" value="<?php echo h($day) ?>"<?php echo in_array($day, $form['days'], true) ? ' checked' : '' ?>> <?php echo h($day) ?></label>
			<?php } ?>
		</div>
		<label for="collection_time">Time</label>
		<input id="collection_time" type="time" name="collection_time" value="<?php echo h($form['collection_time']) ?>" required>
		<label for="notes">Note for residents <span class="hint">Optional.</span></label>
		<textarea id="notes" name="notes"><?php echo h($form['notes']) ?></textarea>
		<label for="status">Status</label>
		<select id="status" name="status">
			<option value="Active"<?php echo selected($form['status'], 'Active') ?>>Active</option>
			<option value="Inactive"<?php echo selected($form['status'], 'Inactive') ?>>Inactive</option>
		</select>
		<div class="button-row">
			<button name="edit" type="submit">Save changes</button>
			<a class="btn btn-secondary" href="schedules.php">Back to the list</a>
		</div>
	</form>
<?php require 'includes/footer.php'; ?>
