<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO', 'Barangay Personnel']);
	$user = current_user();
	$news = new Announcements($pdo);
	$audiences = ['Everyone', 'Residents', 'Collection Personnel', 'Barangay Staff'];
	$form = [
		'title' => '',
		'category' => 'Collection announcements',
		'body' => '',
		'audience' => 'Everyone',
		'publish_date' => date('Y-m-d'),
		'status' => 'Published',
	];
	$error = '';

	if (isset($_POST['submit'])) {
		foreach ($form as $key => $value) {
			$form[$key] = posted($key);
		}
		if ($form['title'] === '' || $form['body'] === '') {
			$error = 'Please write a title and the message.';
		} elseif (!in_array($form['category'], announcement_categories(), true)) {
			$error = 'Please choose the kind of announcement.';
		} elseif (!in_array($form['audience'], $audiences, true)) {
			$error = 'Please choose who should see this.';
		} elseif (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $form['publish_date'])) {
			$error = 'Please choose the date.';
		} elseif (!in_array($form['status'], ['Published', 'Hidden'], true)) {
			$error = 'Please choose Published or Hidden.';
		} else {
			$news->insert_data($form['title'], $form['category'], $form['body'], $form['audience'], (int) $user['id'], $form['publish_date'], $form['status']);
			set_flash('The announcement was saved.');
			header('Location: announcements.php');
			exit();
		}
	}

	$page_title = 'Post an announcement';
	$nav_current = 'announcements.php';
	require 'includes/header.php';
?>
	<h1>Post an announcement</h1>
	<p class="lead">Write it in plain words. Hidden announcements stay off the public list until you publish them.</p>
	<?php if ($error !== '') { ?><div class="alert alert-bad"><?php echo h($error) ?></div><?php } ?>
	<form class="form-card card" method="post">
		<label for="title">Title</label>
		<input id="title" type="text" name="title" value="<?php echo h($form['title']) ?>" required>
		<label for="category">Kind of news</label>
		<select id="category" name="category">
			<?php foreach (announcement_categories() as $category) { ?>
				<option<?php echo selected($form['category'], $category) ?>><?php echo h($category) ?></option>
			<?php } ?>
		</select>
		<label for="body">Message</label>
		<textarea id="body" name="body" required><?php echo h($form['body']) ?></textarea>
		<label for="audience">Who should see it</label>
		<select id="audience" name="audience">
			<?php foreach ($audiences as $audience) { ?>
				<option<?php echo selected($form['audience'], $audience) ?>><?php echo h($audience) ?></option>
			<?php } ?>
		</select>
		<label for="publish_date">Date</label>
		<input id="publish_date" type="date" name="publish_date" value="<?php echo h($form['publish_date']) ?>" required>
		<label for="status">Status</label>
		<select id="status" name="status">
			<option value="Published"<?php echo selected($form['status'], 'Published') ?>>Published</option>
			<option value="Hidden"<?php echo selected($form['status'], 'Hidden') ?>>Hidden</option>
		</select>
		<div class="button-row">
			<button name="submit" type="submit">Save announcement</button>
			<a class="btn btn-secondary" href="announcements.php">Back to the news</a>
		</div>
	</form>
<?php require 'includes/footer.php'; ?>
