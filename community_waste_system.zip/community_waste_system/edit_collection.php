<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO', 'Barangay Personnel', 'Collection Personnel']);
	$user = current_user();
	$collections = new Collections($pdo);
	$users = new Users($pdo);
	$id = (int) ($_POST['id'] ?? $_GET['id'] ?? 0);
	$row = $collections->show_data_id($id);
	if (!$row) {
		deny('That trip could not be found.', 'monitoring.php');
	}
	if ($user['role'] === 'Collection Personnel' && (int) $row['personnel_id'] !== (int) $user['id']) {
		deny('You can only change trips assigned to you.', 'monitoring.php');
	}
	if ($user['role'] === 'Barangay Personnel' && !owns_record($row['barangay'])) {
		deny('You can only change trips in your own barangay.', 'monitoring.php');
	}

	$people = $users->show_by_role('Collection Personnel', sees_all($user['role']) ? '' : $user['barangay']);
	$form = [
		'collection_date' => $row['collection_date'],
		'status' => $row['status'],
		'personnel_id' => $row['personnel_id'],
		'remarks' => $row['remarks'],
	];
	$error = '';

	if (isset($_POST['edit'])) {
		$form['collection_date'] = posted('collection_date');
		$form['status'] = posted('status');
		$form['remarks'] = posted('remarks');
		$form['personnel_id'] = $user['role'] === 'Collection Personnel' ? $user['id'] : posted('personnel_id');
		$person = $users->show_data_id((int) $form['personnel_id']);

		if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $form['collection_date'])) {
			$error = 'Please choose the date.';
		} elseif (!in_array($form['status'], ['Completed', 'Missed'], true)) {
			$error = 'Please choose whether the trip was finished or missed.';
		} elseif ($form['status'] === 'Missed' && $form['remarks'] === '') {
			$error = 'Please say why the truck missed this route.';
		} elseif (!$person || $person['role'] !== 'Collection Personnel') {
			$error = 'Please choose a collection worker.';
		} else {
			$collections->update_data($id, $form['collection_date'], $form['status'], (int) $person['id'], $form['remarks']);
			set_flash('The trip record was updated.');
			header('Location: monitoring.php');
			exit();
		}
	}

	$page_title = 'Edit a trip';
	$nav_current = 'monitoring.php';
	require 'includes/header.php';
?>
	<h1>Edit a trip</h1>
	<p class="lead"><?php echo h($row['waste_category']) ?> collection in <?php echo h($row['barangay'] . ', ' . $row['zone_name']) ?>.</p>
	<?php if ($error !== '') { ?><div class="alert alert-bad"><?php echo h($error) ?></div><?php } ?>
	<form class="form-card card" method="post">
		<input type="hidden" name="id" value="<?php echo (int) $id ?>">
		<label for="collection_date">Date</label>
		<input id="collection_date" type="date" name="collection_date" value="<?php echo h($form['collection_date']) ?>" required>
		<?php if ($user['role'] !== 'Collection Personnel') { ?>
			<label for="personnel_id">Collector</label>
			<select id="personnel_id" name="personnel_id" required>
				<?php echo user_options($people, $form['personnel_id'], 'Choose a collector') ?>
			</select>
		<?php } ?>
		<label>What happened</label>
		<label class="choice">
			<input type="radio" name="status" value="Completed"<?php echo checked_value($form['status'], 'Completed') ?>>
			<span>Completed</span>
			<small>The truck collected the waste on this route.</small>
		</label>
		<label class="choice">
			<input type="radio" name="status" value="Missed"<?php echo checked_value($form['status'], 'Missed') ?>>
			<span>Missed</span>
			<small>The truck did not collect the waste.</small>
		</label>
		<label for="remarks">What happened</label>
		<textarea id="remarks" name="remarks"><?php echo h($form['remarks']) ?></textarea>
		<div class="button-row">
			<button name="edit" type="submit">Save changes</button>
			<a class="btn btn-secondary" href="monitoring.php">Back to the list</a>
		</div>
	</form>
<?php require 'includes/footer.php'; ?>
