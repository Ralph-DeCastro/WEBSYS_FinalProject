<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO', 'Barangay Personnel']);
	$news = new Announcements($pdo);
	$id = (int) ($_POST['id'] ?? $_GET['id'] ?? 0);
	$row = $news->show_data_id($id);
	if (!$row) {
		deny('That announcement could not be found.', 'announcements.php');
	}
	if (isset($_POST['confirm'])) {
		$news->delete_data($id);
		set_flash('The announcement was removed.');
		header('Location: announcements.php');
		exit();
	}

	$page_title = 'Remove an announcement';
	$nav_current = 'announcements.php';
	require 'includes/header.php';
?>
	<h1>Remove this announcement?</h1>
	<p class="lead"><?php echo h($row['title']) ?> will no longer be shown.</p>
	<form method="post">
		<input type="hidden" name="id" value="<?php echo (int) $id ?>">
		<div class="button-row">
			<button class="btn-danger" name="confirm" type="submit">Yes, remove this announcement</button>
			<a class="btn btn-secondary" href="announcements.php">No, keep it</a>
		</div>
	</form>
<?php require 'includes/footer.php'; ?>
