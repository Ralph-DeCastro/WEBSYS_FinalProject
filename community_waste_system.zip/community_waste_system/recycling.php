<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	$user = current_user();
	if (!in_array($user['role'], ['Administrator', 'MENRO', 'Resident', 'Barangay Personnel'], true)) {
		deny('The recycling center page is for the office and for residents.', 'dashboard.php');
	}
	$materials = new Materials($pdo);
	$transactions = new Transactions($pdo);
	$reports = new Reports($pdo);
	$can_manage = sees_all($user['role']);
	$material_rows = $can_manage ? $materials->show_data() : $materials->show_active();
	$summary = $reports->material_summary();
	$counts = $reports->dashboard_counts('Administrator', $user['id'], $user['barangay']);
	$transaction_rows = $user['role'] === 'Resident' ? $transactions->show_by_user($user['id']) : $transactions->show_data();

	$page_title = 'Recycling center';
	$nav_current = 'recycling.php';
	require 'includes/header.php';
?>
	<h1>Recycling center</h1>
	<?php if ($user['role'] === 'Resident') { ?>
		<p class="lead">Bring clean, dry items to the center. The office pays by the kilo for the materials below.</p>
	<?php } else { ?>
		<p class="lead">Register materials, record the weight, and save each drop-off or sale.</p>
		<p class="big-number"><?php echo h(format_weight($counts['weight'])) ?></p>
		<p class="meta">Total weight recorded this month.</p>
	<?php } ?>

	<?php if ($can_manage) { ?>
		<div class="button-row">
			<a class="btn" href="add_material.php">Add a material</a>
			<a class="btn btn-secondary" href="add_transaction.php">Record a transaction</a>
		</div>
	<?php } ?>

	<h2>Weight by material</h2>
	<?php if (!$summary) { ?>
		<div class="empty"><p>No materials have been registered yet.</p></div>
	<?php } else { ?>
		<div class="table-wrap">
			<table>
				<tr>
					<th>Material</th>
					<th>Total weight</th>
					<th>Total amount</th>
					<th>Records</th>
				</tr>
				<?php foreach ($summary as $row) { ?>
					<tr>
						<td><?php echo h($row['material_name']) ?></td>
						<td><?php echo h(format_weight($row['total_weight'])) ?></td>
						<td><?php echo h(format_money($row['total_amount'])) ?></td>
						<td><?php echo (int) $row['trip_count'] ?></td>
					</tr>
				<?php } ?>
			</table>
		</div>
	<?php } ?>

	<h2><?php echo $can_manage ? 'Registered materials' : 'What the center accepts' ?></h2>
	<?php if (!$material_rows) { ?>
		<div class="empty"><p>No materials are listed yet.</p></div>
	<?php } else { ?>
		<div class="table-wrap">
			<table>
				<tr>
					<th>Material</th>
					<th>Price</th>
					<th>Status</th>
					<?php if ($can_manage) { ?><th>Actions</th><?php } ?>
				</tr>
				<?php foreach ($material_rows as $row) { ?>
					<tr>
						<td><?php echo h($row['material_name']) ?></td>
						<td><?php echo h(format_money($row['price_per_kg'])) ?> per <?php echo h($row['unit']) ?></td>
						<td><?php echo badge($row['status']) ?></td>
						<?php if ($can_manage) { ?>
							<td class="actions">
								<a href="edit_material.php?id=<?php echo (int) $row['id'] ?>">Edit</a>
								<a href="delete_material.php?id=<?php echo (int) $row['id'] ?>">Remove</a>
							</td>
						<?php } ?>
					</tr>
				<?php } ?>
			</table>
		</div>
	<?php } ?>

	<h2><?php echo $user['role'] === 'Resident' ? 'My drop-offs' : 'Transactions' ?></h2>
	<?php if (!$transaction_rows) { ?>
		<div class="empty"><p><?php echo $user['role'] === 'Resident' ? 'You have no recorded drop-offs yet.' : 'No transactions have been saved yet.' ?></p></div>
	<?php } else { ?>
		<p class="scroll-hint">Move sideways if you cannot see every column.</p>
		<div class="table-wrap">
			<table>
				<tr>
					<th>Date</th>
					<th>Type</th>
					<th>Material</th>
					<th>Who</th>
					<th>Weight</th>
					<th>Amount</th>
					<?php if ($can_manage) { ?><th>Actions</th><?php } ?>
				</tr>
				<?php foreach ($transaction_rows as $row) { ?>
					<tr>
						<td><?php echo h(format_date($row['record_date'])) ?></td>
						<td><?php echo h($row['transaction_type']) ?></td>
						<td><?php echo h($row['material_name']) ?></td>
						<td><?php echo h($row['person_name']) ?></td>
						<td><?php echo h(format_weight($row['weight_kg'])) ?></td>
						<td><?php echo h(format_money($row['amount'])) ?></td>
						<?php if ($can_manage) { ?>
							<td class="actions">
								<a href="edit_transaction.php?id=<?php echo (int) $row['id'] ?>">Edit</a>
								<a href="delete_transaction.php?id=<?php echo (int) $row['id'] ?>">Remove</a>
							</td>
						<?php } ?>
					</tr>
				<?php } ?>
			</table>
		</div>
	<?php } ?>
<?php require 'includes/footer.php'; ?>
