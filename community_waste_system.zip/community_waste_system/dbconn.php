<?php

	$host = 'localhost';
	$username = 'root';
	$password = '';
	$db_name = 'community_waste_db';
	$charset = 'utf8mb4';

	$dsn = "mysql:host=$host;dbname=$db_name;charset=$charset";

	$attributes = [
		PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
		PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
		PDO::ATTR_EMULATE_PREPARES => false,
	];

	try {
		$pdo = new PDO($dsn, $username, $password, $attributes);
	} catch (PDOException $e) {
		http_response_code(503);
		echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">';
		echo '<title>Setup needed</title>';
		echo '<style>body{font-family:Segoe UI,Arial,sans-serif;background:#eef6f0;color:#142018;margin:0;padding:48px 20px;}main{max-width:720px;margin:0 auto;background:#fff;border:3px solid #146c43;border-radius:18px;padding:32px;}h1{font-size:40px;line-height:1.2;margin:0 0 12px;}p{font-size:22px;line-height:1.5;}a{display:inline-block;margin-top:12px;background:#146c43;color:#fff;text-decoration:none;font-size:22px;padding:16px 28px;border-radius:12px;}</style>';
		echo '</head><body><main><h1>The system still needs to be set up.</h1>';
		echo '<p>The database is not ready yet. Open the setup page, then come back and sign in.</p>';
		echo '<a href="install.php">Set up the system</a></main></body></html>';
		exit();
	}
