<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	$user = current_user();
	$schedules = new Schedules($pdo);

	if ($user['role'] === 'Collection Personnel') {
		$rows = $schedules->show_by_personnel($user['id']);
	} elseif (!sees_all($user['role'])) {
		$rows = $schedules->show_by_barangay($user['barangay']);
	} else {
		$rows = $schedules->show_data();
	}
	$can_edit = in_array($user['role'], ['Administrator', 'MENRO', 'Barangay Personnel'], true);

	$page_title = 'Collection schedule';
	$nav_current = 'schedules.php';
	require 'includes/header.php';
?>
	<h1><?php echo $user['role'] === 'Collection Personnel' ? 'My route' : 'Collection schedule' ?></h1>
	<p class="lead">These are the days the truck comes to collect waste.</p>
	<?php if ($can_edit) { ?>
		<div class="button-row"><a class="btn" href="add_schedule.php">Add a collection day</a></div>
	<?php } ?>
	<?php if (!$rows) { ?>
		<div class="empty"><p>No collection days have been saved<?php echo $user['role'] === 'Resident' ? ' for your area' : '' ?> yet.</p></div>
	<?php } else { ?>
		<p class="scroll-hint">Move sideways if you cannot see every column.</p>
		<div class="table-wrap">
			<table>
				<tr>
					<th>Area</th>
					<th>Waste</th>
					<th>How often</th>
					<th>Days</th>
					<th>Time</th>
					<th>Collector</th>
					<th>Status</th>
					<?php if ($can_edit) { ?><th>Actions</th><?php } ?>
				</tr>
				<?php foreach ($rows as $row) { ?>
					<tr>
						<td><?php echo h($row['barangay'] . ', ' . $row['zone_name']) ?><?php if ($row['notes']) { ?><br><span class="meta"><?php echo h($row['notes']) ?></span><?php } ?></td>
						<td><?php echo h($row['waste_category']) ?></td>
						<td><?php echo h($row['frequency']) ?></td>
						<td><?php echo h($row['collection_day']) ?></td>
						<td><?php echo h(format_time($row['collection_time'])) ?></td>
						<td><?php echo h($row['personnel_name']) ?></td>
						<td><?php echo badge($row['status']) ?></td>
						<?php if ($can_edit) { ?>
							<td class="actions">
								<a href="edit_schedule.php?id=<?php echo (int) $row['id'] ?>">Edit</a>
								<a href="delete_schedule.php?id=<?php echo (int) $row['id'] ?>">Remove</a>
							</td>
						<?php } ?>
					</tr>
				<?php } ?>
			</table>
		</div>
	<?php } ?>
<?php require 'includes/footer.php'; ?>
