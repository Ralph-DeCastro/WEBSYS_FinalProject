<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO', 'Barangay Personnel']);
	$user = current_user();
	$assignments = new Assignments($pdo);
	$schedules = new Schedules($pdo);
	$users = new Users($pdo);
	$id = (int) ($_POST['id'] ?? $_GET['id'] ?? 0);
	$row = $assignments->show_data_id($id);
	if (!$row) {
		deny('That assignment could not be found.', 'assignments.php');
	}
	if (!sees_all($user['role']) && $row['personnel_barangay'] !== $user['barangay']) {
		deny('You can only change assignments for collectors in your barangay.', 'assignments.php');
	}
	$people = $users->show_by_role('Collection Personnel', sees_all($user['role']) ? '' : $user['barangay']);
	$routes = sees_all($user['role']) ? $schedules->show_data() : $schedules->show_by_barangay($user['barangay']);
	$shifts = ['Morning', 'Afternoon'];
	$statuses = ['Assigned', 'Done', 'Missed'];
	$form = [
		'personnel_id' => $row['personnel_id'],
		'schedule_id' => $row['schedule_id'],
		'assignment_date' => $row['assignment_date'],
		'shift_label' => $row['shift_label'],
		'status' => $row['status'],
		'notes' => $row['notes'],
	];
	$error = '';

	if (isset($_POST['edit'])) {
		foreach ($form as $key => $value) {
			$form[$key] = posted($key);
		}
		$person = $users->show_data_id((int) $form['personnel_id']);
		$route = $schedules->show_data_id((int) $form['schedule_id']);
		if (!$person || $person['role'] !== 'Collection Personnel') {
			$error = 'Please choose a collector.';
		} elseif (!sees_all($user['role']) && $person['barangay'] !== $user['barangay']) {
			$error = 'Choose a collector from your barangay.';
		} elseif (!$route) {
			$error = 'Please choose a route.';
		} elseif (!owns_record($route['barangay'])) {
			$error = 'You can only assign a route in your own barangay.';
		} elseif (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $form['assignment_date'])) {
			$error = 'Please choose the date.';
		} elseif (!in_array($form['shift_label'], $shifts, true) || !in_array($form['status'], $statuses, true)) {
			$error = 'Please choose the shift and the status.';
		} else {
			$assignments->update_data($id, (int) $person['id'], (int) $route['id'], $form['assignment_date'], $form['shift_label'], $form['status'], $form['notes']);
			set_flash('The assignment was updated.');
			header('Location: assignments.php');
			exit();
		}
	}

	$page_title = 'Edit an assignment';
	$nav_current = 'personnel.php';
	require 'includes/header.php';
?>
	<h1>Edit an assignment</h1>
	<p class="lead">Change the collector, the route, or the result of this day.</p>
	<?php if ($error !== '') { ?><div class="alert alert-bad"><?php echo h($error) ?></div><?php } ?>
	<form class="form-card card" method="post">
		<input type="hidden" name="id" value="<?php echo (int) $id ?>">
		<label for="personnel_id">Collector</label>
		<select id="personnel_id" name="personnel_id" required>
			<?php echo user_options($people, $form['personnel_id'], 'Choose a collector') ?>
		</select>
		<label for="schedule_id">Route</label>
		<select id="schedule_id" name="schedule_id" required>
			<?php echo schedule_options($routes, $form['schedule_id']) ?>
		</select>
		<label for="assignment_date">Date</label>
		<input id="assignment_date" type="date" name="assignment_date" value="<?php echo h($form['assignment_date']) ?>" required>
		<label for="shift_label">Shift</label>
		<select id="shift_label" name="shift_label">
			<?php foreach ($shifts as $shift) { ?>
				<option<?php echo selected($form['shift_label'], $shift) ?>><?php echo h($shift) ?></option>
			<?php } ?>
		</select>
		<label for="status">Status</label>
		<select id="status" name="status">
			<?php foreach ($statuses as $status) { ?>
				<option<?php echo selected($form['status'], $status) ?>><?php echo h($status) ?></option>
			<?php } ?>
		</select>
		<label for="notes">Note <span class="hint">Optional.</span></label>
		<textarea id="notes" name="notes"><?php echo h($form['notes']) ?></textarea>
		<div class="button-row">
			<button name="edit" type="submit">Save changes</button>
			<a class="btn btn-secondary" href="assignments.php">Back to the list</a>
		</div>
	</form>
<?php require 'includes/footer.php'; ?>
