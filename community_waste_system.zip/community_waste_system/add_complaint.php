<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	$user = current_user();
	if ($user['role'] === 'Collection Personnel') {
		deny('Please record a missed trip instead of a resident complaint.', 'add_collection.php');
	}
	$complaints = new Complaints($pdo);
	$users = new Users($pdo);
	$areas = new Barangays($pdo);
	$residents = $users->show_by_role('Resident', sees_all($user['role']) || $user['role'] === 'Resident' ? '' : $user['barangay']);
	$names = $areas->show_names();
	$form = [
		'resident_id' => $user['role'] === 'Resident' ? $user['id'] : '',
		'resident_name' => $user['role'] === 'Resident' ? $user['full_name'] : '',
		'complaint_type' => '',
		'barangay' => $user['role'] === 'Resident' || $user['role'] === 'Barangay Personnel' ? $user['barangay'] : '',
		'location' => '',
		'description' => '',
	];
	$error = '';

	if (isset($_POST['submit'])) {
		$form['complaint_type'] = posted('complaint_type');
		$form['location'] = posted('location');
		$form['description'] = posted('description');
		$form['barangay'] = posted('barangay');
		$form['resident_id'] = posted('resident_id');
		$form['resident_name'] = posted('resident_name');
		$photo = save_photo('photo');

		if ($user['role'] === 'Resident') {
			$form['resident_id'] = $user['id'];
			$form['resident_name'] = $user['full_name'];
			$form['barangay'] = $user['barangay'];
		} elseif ($form['resident_id'] !== '') {
			$resident = $users->show_data_id((int) $form['resident_id']);
			if (!$resident || $resident['role'] !== 'Resident') {
				$error = 'Please choose a resident from the list, or leave it blank and type the name.';
			} elseif ($user['role'] === 'Barangay Personnel' && $resident['barangay'] !== $user['barangay']) {
				$error = 'Choose a resident from your barangay.';
			} else {
				$form['resident_name'] = $resident['full_name'];
				$form['barangay'] = $resident['barangay'];
			}
		}

		if ($error === '' && $photo === false) {
			$error = 'The photo must be a JPG or PNG, and smaller than 5 MB.';
		} elseif ($error === '' && !array_key_exists($form['complaint_type'], complaint_types())) {
			$error = 'Please choose the kind of problem.';
		} elseif ($error === '' && $form['resident_name'] === '') {
			$error = 'Please type the name of the person reporting the problem.';
		} elseif ($error === '' && $form['barangay'] === '') {
			$error = 'Please choose the barangay.';
		} elseif ($error === '' && $user['role'] === 'Barangay Personnel' && $form['barangay'] !== $user['barangay']) {
			$error = 'You can only file a report for your own barangay.';
		} elseif ($error === '' && $form['location'] === '') {
			$error = 'Please say where the problem is.';
		} elseif ($error === '' && $form['description'] === '') {
			$error = 'Please describe the problem in a sentence or two.';
		}

		if ($error === '') {
			$resident_id = $form['resident_id'] === '' ? (int) $user['id'] : (int) $form['resident_id'];
			$complaints->insert_data($resident_id, $form['resident_name'], $form['complaint_type'], $form['barangay'], $form['location'], $form['description'], $photo);
			set_flash('The report was sent. The office can now see it.');
			header('Location: complaints.php');
			exit();
		}
		if (is_string($photo)) {
			remove_photo($photo);
		}
	}

	$page_title = 'Report a problem';
	$nav_current = 'add_complaint.php';
	require 'includes/header.php';
?>
	<h1>Report a problem</h1>
	<p class="lead">Tell the office about dumping, uncollected garbage, a blocked drain, or waste in the wrong place. A photo helps, but it is optional.</p>
	<?php if ($error !== '') { ?><div class="alert alert-bad"><?php echo h($error) ?></div><?php } ?>
	<form class="form-card card" method="post" enctype="multipart/form-data">
		<label>What is the problem?</label>
		<?php foreach (complaint_types() as $type => $help) { ?>
			<label class="choice">
				<input type="radio" name="complaint_type" value="<?php echo h($type) ?>"<?php echo checked_value($form['complaint_type'], $type) ?> required>
				<span><?php echo h($type) ?></span>
				<small><?php echo h($help) ?></small>
			</label>
		<?php } ?>
		<?php if ($user['role'] === 'Resident') { ?>
			<p>This report will use your name and barangay: <strong><?php echo h($user['full_name']) ?></strong>, <?php echo h($user['barangay']) ?>.</p>
		<?php } else { ?>
			<label for="resident_id">Resident <span class="hint">Choose a person with an account, or leave this blank and type the name.</span></label>
			<select id="resident_id" name="resident_id">
				<?php echo user_options($residents, $form['resident_id'], 'Type the name instead') ?>
			</select>
			<label for="resident_name">Name</label>
			<input id="resident_name" type="text" name="resident_name" value="<?php echo h($form['resident_name']) ?>">
			<label for="barangay">Barangay</label>
			<select id="barangay" name="barangay">
				<option value="">Choose a barangay</option>
				<?php foreach ($names as $name) { ?>
					<option value="<?php echo h($name['barangay_name']) ?>"<?php echo selected($form['barangay'], $name['barangay_name']) ?>><?php echo h($name['barangay_name']) ?></option>
				<?php } ?>
			</select>
		<?php } ?>
		<label for="location">Where is it? <span class="hint">Street, landmark, or house.</span></label>
		<input id="location" type="text" name="location" value="<?php echo h($form['location']) ?>" required>
		<label for="description">What should the office know?</label>
		<textarea id="description" name="description" required><?php echo h($form['description']) ?></textarea>
		<label for="photo">Photo <span class="hint">Optional. JPG or PNG, up to 5 MB.</span></label>
		<input id="photo" type="file" name="photo" accept="image/jpeg,image/png,image/webp">
		<div class="button-row">
			<button name="submit" type="submit">Send this report</button>
			<a class="btn btn-secondary" href="complaints.php">Back to the list</a>
		</div>
	</form>
<?php require 'includes/footer.php'; ?>
