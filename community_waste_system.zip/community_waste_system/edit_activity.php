<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO', 'Barangay Personnel', 'Collection Personnel']);
	$user = current_user();
	$activities = new Activities($pdo);
	$id = (int) ($_POST['id'] ?? $_GET['id'] ?? 0);
	$row = $activities->show_data_id($id);
	if (!$row) {
		deny('That note could not be found.', 'activities.php');
	}
	if ($user['role'] === 'Collection Personnel' && (int) $row['personnel_id'] !== (int) $user['id']) {
		deny('You can only change your own daily notes.', 'activities.php');
	}
	if ($user['role'] === 'Barangay Personnel' && $row['personnel_barangay'] !== $user['barangay']) {
		deny('You can only change notes for collectors in your barangay.', 'activities.php');
	}
	$statuses = ['Done', 'In Progress', 'Could not finish'];
	$form = [
		'activity_date' => $row['activity_date'],
		'task_done' => $row['task_done'],
		'status' => $row['status'],
		'notes' => $row['notes'],
	];
	$error = '';

	if (isset($_POST['edit'])) {
		foreach ($form as $key => $value) {
			$form[$key] = posted($key);
		}
		if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $form['activity_date'])) {
			$error = 'Please choose the date.';
		} elseif ($form['task_done'] === '') {
			$error = 'Please say what was done.';
		} elseif (!in_array($form['status'], $statuses, true)) {
			$error = 'Please choose a status.';
		} else {
			$activities->update_data($id, $form['activity_date'], $form['task_done'], $form['status'], $form['notes']);
			set_flash('The daily note was updated.');
			header('Location: activities.php');
			exit();
		}
	}

	$page_title = 'Edit an activity';
	$nav_current = $user['role'] === 'Collection Personnel' ? 'activities.php' : 'personnel.php';
	require 'includes/header.php';
?>
	<h1>Edit an activity</h1>
	<p class="lead">Note for <?php echo h($row['personnel_name']) ?>.</p>
	<?php if ($error !== '') { ?><div class="alert alert-bad"><?php echo h($error) ?></div><?php } ?>
	<form class="form-card card" method="post">
		<input type="hidden" name="id" value="<?php echo (int) $id ?>">
		<label for="activity_date">Date</label>
		<input id="activity_date" type="date" name="activity_date" value="<?php echo h($form['activity_date']) ?>" required>
		<label for="task_done">What was done</label>
		<input id="task_done" type="text" name="task_done" value="<?php echo h($form['task_done']) ?>" required>
		<label for="status">Status</label>
		<select id="status" name="status">
			<?php foreach ($statuses as $status) { ?>
				<option<?php echo selected($form['status'], $status) ?>><?php echo h($status) ?></option>
			<?php } ?>
		</select>
		<label for="notes">More detail <span class="hint">Optional.</span></label>
		<textarea id="notes" name="notes"><?php echo h($form['notes']) ?></textarea>
		<div class="button-row">
			<button name="edit" type="submit">Save changes</button>
			<a class="btn btn-secondary" href="activities.php">Back to the list</a>
		</div>
	</form>
<?php require 'includes/footer.php'; ?>
