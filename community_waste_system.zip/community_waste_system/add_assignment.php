<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO', 'Barangay Personnel']);
	$user = current_user();
	$assignments = new Assignments($pdo);
	$schedules = new Schedules($pdo);
	$users = new Users($pdo);
	$people = $users->show_by_role('Collection Personnel', sees_all($user['role']) ? '' : $user['barangay']);
	$routes = sees_all($user['role']) ? $schedules->show_data() : $schedules->show_by_barangay($user['barangay']);
	$shifts = ['Morning', 'Afternoon'];
	$statuses = ['Assigned', 'Done', 'Missed'];
	$form = [
		'personnel_id' => '',
		'schedule_id' => '',
		'assignment_date' => date('Y-m-d'),
		'shift_label' => 'Morning',
		'status' => 'Assigned',
		'notes' => '',
	];
	$error = '';

	if (isset($_POST['submit'])) {
		foreach ($form as $key => $value) {
			$form[$key] = posted($key);
		}
		$person = $users->show_data_id((int) $form['personnel_id']);
		$route = $schedules->show_data_id((int) $form['schedule_id']);
		if (!$person || $person['role'] !== 'Collection Personnel') {
			$error = 'Please choose a collector.';
		} elseif (!sees_all($user['role']) && $person['barangay'] !== $user['barangay']) {
			$error = 'Choose a collector from your barangay.';
		} elseif (!$route) {
			$error = 'Please choose a route.';
		} elseif (!owns_record($route['barangay'])) {
			$error = 'You can only assign a route in your own barangay.';
		} elseif (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $form['assignment_date'])) {
			$error = 'Please choose the date.';
		} elseif (!in_array($form['shift_label'], $shifts, true) || !in_array($form['status'], $statuses, true)) {
			$error = 'Please choose the shift and the status.';
		} else {
			$assignments->insert_data((int) $person['id'], (int) $route['id'], $form['assignment_date'], $form['shift_label'], $form['status'], $form['notes']);
			set_flash('The assignment was saved.');
			header('Location: assignments.php');
			exit();
		}
	}

	$page_title = 'Assign a route';
	$nav_current = 'personnel.php';
	require 'includes/header.php';
?>
	<h1>Assign a route</h1>
	<p class="lead">Choose the collector, the route, and the day.</p>
	<?php if ($error !== '') { ?><div class="alert alert-bad"><?php echo h($error) ?></div><?php } ?>
	<?php if (!$people || !$routes) { ?>
		<div class="empty"><p>You need at least one collector and one collection day in this area before you can assign a route.</p></div>
		<a class="btn btn-secondary" href="personnel.php">Back to personnel</a>
	<?php } else { ?>
		<form class="form-card card" method="post">
			<label for="personnel_id">Collector</label>
			<select id="personnel_id" name="personnel_id" required>
				<?php echo user_options($people, $form['personnel_id'], 'Choose a collector') ?>
			</select>
			<label for="schedule_id">Route</label>
			<select id="schedule_id" name="schedule_id" required>
				<?php echo schedule_options($routes, $form['schedule_id']) ?>
			</select>
			<label for="assignment_date">Date</label>
			<input id="assignment_date" type="date" name="assignment_date" value="<?php echo h($form['assignment_date']) ?>" required>
			<label for="shift_label">Shift</label>
			<select id="shift_label" name="shift_label">
				<?php foreach ($shifts as $shift) { ?>
					<option<?php echo selected($form['shift_label'], $shift) ?>><?php echo h($shift) ?></option>
				<?php } ?>
			</select>
			<label for="status">Status</label>
			<select id="status" name="status">
				<?php foreach ($statuses as $status) { ?>
					<option<?php echo selected($form['status'], $status) ?>><?php echo h($status) ?></option>
				<?php } ?>
			</select>
			<label for="notes">Note <span class="hint">Optional.</span></label>
			<textarea id="notes" name="notes"><?php echo h($form['notes']) ?></textarea>
			<div class="button-row">
				<button name="submit" type="submit">Save assignment</button>
				<a class="btn btn-secondary" href="assignments.php">Back to the list</a>
			</div>
		</form>
	<?php } ?>
<?php require 'includes/footer.php'; ?>
