<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO']);
	$areas = new Barangays($pdo);
	$id = (int) ($_POST['id'] ?? $_GET['id'] ?? 0);
	$row = $areas->show_data_id($id);
	if (!$row) {
		deny('That area could not be found.', 'barangays.php');
	}
	$form = [
		'barangay_name' => $row['barangay_name'],
		'zone_name' => $row['zone_name'],
		'notes' => $row['notes'],
	];
	$error = '';

	if (isset($_POST['edit'])) {
		$form = [
			'barangay_name' => posted('barangay_name'),
			'zone_name' => posted('zone_name'),
			'notes' => posted('notes'),
		];
		if ($form['barangay_name'] === '' || $form['zone_name'] === '') {
			$error = 'Please type the barangay and the zone.';
		} else {
			$areas->update_data($id, $form['barangay_name'], $form['zone_name'], $form['notes']);
			set_flash('The area was updated. Schedules already saved keep the old area name until you edit them.');
			header('Location: barangays.php');
			exit();
		}
	}

	$page_title = 'Edit an area';
	$nav_current = 'barangays.php';
	require 'includes/header.php';
?>
	<h1>Edit an area</h1>
	<p class="lead">Changing the name here does not rename schedules that were already saved.</p>
	<?php if ($error !== '') { ?><div class="alert alert-bad"><?php echo h($error) ?></div><?php } ?>
	<form class="form-card card" method="post">
		<input type="hidden" name="id" value="<?php echo (int) $id ?>">
		<label for="barangay_name">Barangay</label>
		<input id="barangay_name" type="text" name="barangay_name" value="<?php echo h($form['barangay_name']) ?>" required>
		<label for="zone_name">Zone</label>
		<input id="zone_name" type="text" name="zone_name" value="<?php echo h($form['zone_name']) ?>" required>
		<label for="notes">Notes <span class="hint">Optional.</span></label>
		<input id="notes" type="text" name="notes" value="<?php echo h($form['notes']) ?>">
		<div class="button-row">
			<button name="edit" type="submit">Save changes</button>
			<a class="btn btn-secondary" href="barangays.php">Back to the list</a>
		</div>
	</form>
<?php require 'includes/footer.php'; ?>
