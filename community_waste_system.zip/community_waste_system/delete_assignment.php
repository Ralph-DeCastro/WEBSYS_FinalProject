<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO', 'Barangay Personnel']);
	$user = current_user();
	$assignments = new Assignments($pdo);
	$id = (int) ($_POST['id'] ?? $_GET['id'] ?? 0);
	$row = $assignments->show_data_id($id);
	if (!$row) {
		deny('That assignment could not be found.', 'assignments.php');
	}
	if (!sees_all($user['role']) && $row['personnel_barangay'] !== $user['barangay']) {
		deny('You can only remove assignments for collectors in your barangay.', 'assignments.php');
	}
	if (isset($_POST['confirm'])) {
		$assignments->delete_data($id);
		set_flash('The assignment was removed.');
		header('Location: assignments.php');
		exit();
	}

	$page_title = 'Remove an assignment';
	$nav_current = 'personnel.php';
	require 'includes/header.php';
?>
	<h1>Remove this assignment?</h1>
	<p class="lead"><?php echo h($row['personnel_name']) ?> on <?php echo h(format_date($row['assignment_date'])) ?> will be removed from the schedule.</p>
	<form method="post">
		<input type="hidden" name="id" value="<?php echo (int) $id ?>">
		<div class="button-row">
			<button class="btn-danger" name="confirm" type="submit">Yes, remove this assignment</button>
			<a class="btn btn-secondary" href="assignments.php">No, keep it</a>
		</div>
	</form>
<?php require 'includes/footer.php'; ?>
