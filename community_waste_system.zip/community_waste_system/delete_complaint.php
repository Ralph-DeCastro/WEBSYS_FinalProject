<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO']);
	$complaints = new Complaints($pdo);
	$id = (int) ($_POST['id'] ?? $_GET['id'] ?? 0);
	$row = $complaints->show_data_id($id);
	if (!$row) {
		deny('That report could not be found.', 'complaints.php');
	}
	if (isset($_POST['confirm'])) {
		remove_photo($row['photo']);
		$complaints->delete_data($id);
		set_flash('The report was removed.');
		header('Location: complaints.php');
		exit();
	}

	$page_title = 'Remove a report';
	$nav_current = 'complaints.php';
	require 'includes/header.php';
?>
	<h1>Remove this report?</h1>
	<p class="lead"><?php echo h($row['complaint_type']) ?> from <?php echo h($row['resident_name']) ?> in <?php echo h($row['barangay']) ?> will be removed. The photo will be removed too.</p>
	<form method="post">
		<input type="hidden" name="id" value="<?php echo (int) $id ?>">
		<div class="button-row">
			<button class="btn-danger" name="confirm" type="submit">Yes, remove this report</button>
			<a class="btn btn-secondary" href="view_complaint.php?id=<?php echo (int) $id ?>">No, keep it</a>
		</div>
	</form>
<?php require 'includes/footer.php'; ?>
