<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO']);
	$reports = new Reports($pdo);
	$completion = $reports->completion_by_barangay();
	$missed = $reports->missed_list();
	$by_type = $reports->complaints_by_type();
	$complaint_rows = $reports->complaint_rows();
	$materials = $reports->material_summary();

	$page_title = 'Reports';
	$nav_current = 'reports.php';
	require 'includes/header.php';
?>
	<h1>Reports</h1>
	<p class="lead">These numbers come from the trip records, resident reports, and recycling transactions.</p>
	<div class="button-row no-print">
		<button type="button" onclick="window.print()">Print this page</button>
	</div>

	<h2>Collection completion</h2>
	<?php if (!$completion) { ?>
		<div class="empty"><p>No trips have been recorded yet.</p></div>
	<?php } else { ?>
		<div class="table-wrap">
			<table>
				<tr>
					<th>Barangay</th>
					<th>Completed</th>
					<th>Missed</th>
					<th>Total</th>
				</tr>
				<?php foreach ($completion as $row) { ?>
					<tr>
						<td><?php echo h($row['barangay']) ?></td>
						<td><?php echo (int) $row['completed_count'] ?></td>
						<td><?php echo (int) $row['missed_count'] ?></td>
						<td><?php echo (int) $row['total_count'] ?></td>
					</tr>
				<?php } ?>
			</table>
		</div>
	<?php } ?>

	<h2>Missed collections</h2>
	<?php if (!$missed) { ?>
		<div class="empty"><p>No missed collections have been recorded.</p></div>
	<?php } else { ?>
		<div class="table-wrap">
			<table>
				<tr>
					<th>Date</th>
					<th>Area</th>
					<th>Waste</th>
					<th>Collector</th>
					<th>Why</th>
				</tr>
				<?php foreach ($missed as $row) { ?>
					<tr>
						<td><?php echo h(format_date($row['collection_date'])) ?></td>
						<td><?php echo h($row['barangay'] . ', ' . $row['zone_name']) ?></td>
						<td><?php echo h($row['waste_category']) ?></td>
						<td><?php echo h($row['personnel_name']) ?></td>
						<td><?php echo h($row['remarks']) ?></td>
					</tr>
				<?php } ?>
			</table>
		</div>
	<?php } ?>

	<h2>Environmental complaints</h2>
	<?php if (!$by_type) { ?>
		<div class="empty"><p>No complaints have been recorded.</p></div>
	<?php } else { ?>
		<div class="table-wrap">
			<table>
				<tr>
					<th>Problem</th>
					<th>New</th>
					<th>In progress</th>
					<th>Resolved</th>
					<th>Total</th>
				</tr>
				<?php foreach ($by_type as $row) { ?>
					<tr>
						<td><?php echo h($row['complaint_type']) ?></td>
						<td><?php echo (int) $row['new_count'] ?></td>
						<td><?php echo (int) $row['progress_count'] ?></td>
						<td><?php echo (int) $row['resolved_count'] ?></td>
						<td><?php echo (int) $row['total_count'] ?></td>
					</tr>
				<?php } ?>
			</table>
		</div>
		<h2>Complaint list</h2>
		<div class="table-wrap">
			<table>
				<tr>
					<th>Date</th>
					<th>Problem</th>
					<th>Resident</th>
					<th>Area</th>
					<th>Status</th>
				</tr>
				<?php foreach ($complaint_rows as $row) { ?>
					<tr>
						<td><?php echo h(format_date($row['created_at'])) ?></td>
						<td><?php echo h($row['complaint_type']) ?></td>
						<td><?php echo h($row['resident_name']) ?></td>
						<td><?php echo h($row['barangay'] . ', ' . $row['location']) ?></td>
						<td><?php echo badge($row['status']) ?></td>
					</tr>
				<?php } ?>
			</table>
		</div>
	<?php } ?>

	<h2>Recyclable materials</h2>
	<?php if (!$materials) { ?>
		<div class="empty"><p>No recycling materials have been registered.</p></div>
	<?php } else { ?>
		<div class="table-wrap">
			<table>
				<tr>
					<th>Material</th>
					<th>Total weight</th>
					<th>Total amount</th>
					<th>Records</th>
				</tr>
				<?php foreach ($materials as $row) { ?>
					<tr>
						<td><?php echo h($row['material_name']) ?></td>
						<td><?php echo h(format_weight($row['total_weight'])) ?></td>
						<td><?php echo h(format_money($row['total_amount'])) ?></td>
						<td><?php echo (int) $row['trip_count'] ?></td>
					</tr>
				<?php } ?>
			</table>
		</div>
	<?php } ?>
<?php require 'includes/footer.php'; ?>
