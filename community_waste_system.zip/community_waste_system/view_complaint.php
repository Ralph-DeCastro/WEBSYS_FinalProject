<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	$user = current_user();
	$complaints = new Complaints($pdo);
	$id = (int) ($_POST['id'] ?? $_GET['id'] ?? 0);
	$row = $complaints->show_data_id($id);
	if (!$row) {
		deny('That report could not be found.', 'complaints.php');
	}
	if ($user['role'] === 'Resident' && (int) $row['resident_id'] !== (int) $user['id']) {
		deny('You can only open your own reports.', 'complaints.php');
	}
	if ($user['role'] === 'Collection Personnel') {
		deny('That page is for the office and the resident who sent the report.', 'dashboard.php');
	}
	if ($user['role'] === 'Barangay Personnel' && !owns_record($row['barangay'])) {
		deny('You can only open reports in your own barangay.', 'complaints.php');
	}

	$can_update = in_array($user['role'], ['Administrator', 'MENRO', 'Barangay Personnel'], true);
	$form = [
		'status' => $row['status'],
		'response_notes' => (string) $row['response_notes'],
	];
	$error = '';

	if ($can_update && isset($_POST['edit'])) {
		$form['status'] = posted('status');
		$form['response_notes'] = posted('response_notes');
		if (!in_array($form['status'], ['New', 'In Progress', 'Resolved'], true)) {
			$error = 'Please choose a status.';
		} elseif ($form['status'] === 'Resolved' && $form['response_notes'] === '') {
			$error = 'Please write what the office did before marking this resolved.';
		} else {
			$complaints->update_status($id, $form['status'], $form['response_notes'], (int) $user['id']);
			set_flash('The report was updated.');
			header('Location: view_complaint.php?id=' . $id);
			exit();
		}
	}

	$page_title = 'Report details';
	$nav_current = 'complaints.php';
	require 'includes/header.php';
?>
	<h1><?php echo h($row['complaint_type']) ?></h1>
	<p class="lead"><?php echo h($row['barangay']) ?> · <?php echo h($row['location']) ?></p>
	<?php if ($error !== '') { ?><div class="alert alert-bad"><?php echo h($error) ?></div><?php } ?>
	<article class="card">
		<p><?php echo badge($row['status']) ?></p>
		<p><strong>Reported by:</strong> <?php echo h($row['resident_name']) ?></p>
		<p><strong>Sent on:</strong> <?php echo h(format_date($row['created_at'])) ?></p>
		<p><?php echo nl2br(h($row['description'])) ?></p>
		<?php if (!empty($row['photo'])) { ?>
			<img class="photo" src="uploads/<?php echo h($row['photo']) ?>" alt="Photo sent with this report">
		<?php } ?>
		<?php if ($row['response_notes']) { ?>
			<h2>Reply from the office</h2>
			<p><?php echo nl2br(h($row['response_notes'])) ?></p>
		<?php } elseif ($user['role'] === 'Resident') { ?>
			<p class="meta">The office has not written a reply yet.</p>
		<?php } ?>
	</article>
	<?php if ($can_update) { ?>
		<h2>Update this report</h2>
		<form class="form-card card" method="post">
			<input type="hidden" name="id" value="<?php echo (int) $id ?>">
			<label for="status">Status</label>
			<select id="status" name="status">
				<option value="New"<?php echo selected($form['status'], 'New') ?>>New</option>
				<option value="In Progress"<?php echo selected($form['status'], 'In Progress') ?>>In progress</option>
				<option value="Resolved"<?php echo selected($form['status'], 'Resolved') ?>>Resolved</option>
			</select>
			<label for="response_notes">Reply the resident can read</label>
			<textarea id="response_notes" name="response_notes"><?php echo h($form['response_notes']) ?></textarea>
			<div class="button-row">
				<button name="edit" type="submit">Save the update</button>
				<?php if (sees_all($user['role'])) { ?>
					<a class="btn btn-danger" href="delete_complaint.php?id=<?php echo (int) $id ?>">Remove this report</a>
				<?php } ?>
			</div>
		</form>
	<?php } ?>
	<p><a class="btn btn-secondary" href="complaints.php">Back to the list</a></p>
<?php require 'includes/footer.php'; ?>
