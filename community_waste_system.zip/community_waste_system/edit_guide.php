<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO']);
	$guides = new Guides($pdo);
	$id = (int) ($_POST['id'] ?? $_GET['id'] ?? 0);
	$row = $guides->show_data_id($id);
	if (!$row) {
		deny('That guide could not be found.', 'segregation.php');
	}
	$form = [
		'waste_type' => $row['waste_type'],
		'description' => $row['description'],
		'examples' => $row['examples'],
		'how_to_prepare' => $row['how_to_prepare'],
		'color_label' => $row['color_label'],
	];
	$error = '';

	if (isset($_POST['edit'])) {
		foreach ($form as $key => $value) {
			$form[$key] = posted($key);
		}
		if ($form['waste_type'] === '' || $form['description'] === '' || $form['examples'] === '' || $form['how_to_prepare'] === '') {
			$error = 'Please fill in the title, the description, the examples, and what to do.';
		} elseif (!in_array($form['color_label'], guide_colors(), true)) {
			$error = 'Please choose a color.';
		} else {
			$guides->update_data($id, $form['waste_type'], $form['description'], $form['examples'], $form['how_to_prepare'], $form['color_label']);
			set_flash('The sorting guide was updated.');
			header('Location: segregation.php');
			exit();
		}
	}

	$page_title = 'Edit a sorting guide';
	$nav_current = 'segregation.php';
	require 'includes/header.php';
?>
	<h1>Edit a sorting guide</h1>
	<p class="lead">Keep the words short and plain.</p>
	<?php if ($error !== '') { ?><div class="alert alert-bad"><?php echo h($error) ?></div><?php } ?>
	<form class="form-card card" method="post">
		<input type="hidden" name="id" value="<?php echo (int) $id ?>">
		<label for="waste_type">Title</label>
		<input id="waste_type" type="text" name="waste_type" value="<?php echo h($form['waste_type']) ?>" required>
		<label for="color_label">Color</label>
		<select id="color_label" name="color_label">
			<?php foreach (guide_colors() as $color) { ?>
				<option<?php echo selected($form['color_label'], $color) ?>><?php echo h($color) ?></option>
			<?php } ?>
		</select>
		<label for="description">What it is</label>
		<textarea id="description" name="description" required><?php echo h($form['description']) ?></textarea>
		<label for="examples">Examples</label>
		<textarea id="examples" name="examples" required><?php echo h($form['examples']) ?></textarea>
		<label for="how_to_prepare">What to do</label>
		<textarea id="how_to_prepare" name="how_to_prepare" required><?php echo h($form['how_to_prepare']) ?></textarea>
		<div class="button-row">
			<button name="edit" type="submit">Save changes</button>
			<a class="btn btn-secondary" href="segregation.php">Back to the guide</a>
		</div>
	</form>
<?php require 'includes/footer.php'; ?>
