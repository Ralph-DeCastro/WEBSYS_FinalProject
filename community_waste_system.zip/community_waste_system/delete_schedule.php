<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO', 'Barangay Personnel']);
	$schedules = new Schedules($pdo);
	$id = (int) ($_POST['id'] ?? $_GET['id'] ?? 0);
	$row = $schedules->show_data_id($id);
	if (!$row) {
		deny('That collection day could not be found.', 'schedules.php');
	}
	if (!owns_record($row['barangay'])) {
		deny('You can only remove collection days in your own barangay.', 'schedules.php');
	}
	if (isset($_POST['confirm'])) {
		$schedules->delete_data($id);
		set_flash('The collection day was removed. Trip records already saved were kept.');
		header('Location: schedules.php');
		exit();
	}

	$page_title = 'Remove a collection day';
	$nav_current = 'schedules.php';
	require 'includes/header.php';
?>
	<h1>Remove this collection day?</h1>
	<p class="lead"><?php echo h($row['waste_category']) ?> collection for <?php echo h($row['barangay'] . ', ' . $row['zone_name']) ?> on <?php echo h($row['collection_day']) ?> will be removed.</p>
	<form method="post">
		<input type="hidden" name="id" value="<?php echo (int) $id ?>">
		<div class="button-row">
			<button class="btn-danger" name="confirm" type="submit">Yes, remove this collection day</button>
			<a class="btn btn-secondary" href="schedules.php">No, keep it</a>
		</div>
	</form>
<?php require 'includes/footer.php'; ?>
