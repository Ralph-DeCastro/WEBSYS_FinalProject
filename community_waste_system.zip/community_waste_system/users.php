<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO']);
	$user = current_user();
	$users = new Users($pdo);
	$rows = $users->show_data();

	$page_title = 'Users';
	$nav_current = 'users.php';
	require 'includes/header.php';
?>
	<h1>Users</h1>
	<p class="lead">These are the people who can sign in.</p>
	<div class="button-row">
		<a class="btn" href="add_user.php">Add a user</a>
	</div>
	<?php if (!$rows) { ?>
		<div class="empty"><p>No users have been saved yet.</p></div>
	<?php } else { ?>
		<p class="scroll-hint">Move sideways if you cannot see the buttons.</p>
		<div class="table-wrap">
			<table>
				<tr>
					<th>Name</th>
					<th>Username</th>
					<th>Role</th>
					<th>Barangay</th>
					<th>Contact</th>
					<th>Status</th>
					<th>Actions</th>
				</tr>
				<?php foreach ($rows as $row) { ?>
					<?php if ($user['role'] !== 'Administrator' && $row['role'] === 'Administrator') { continue; } ?>
					<tr>
						<td><?php echo h($row['full_name']) ?></td>
						<td><?php echo h($row['username']) ?></td>
						<td><?php echo h(role_label($row['role'])) ?></td>
						<td><?php echo h($row['barangay']) ?></td>
						<td><?php echo h($row['contact_number']) ?></td>
						<td><?php echo badge($row['status']) ?></td>
						<td class="actions">
							<a href="edit_user.php?id=<?php echo (int) $row['id'] ?>">Edit</a>
							<a href="delete_user.php?id=<?php echo (int) $row['id'] ?>">Remove</a>
						</td>
					</tr>
				<?php } ?>
			</table>
		</div>
	<?php } ?>
<?php require 'includes/footer.php'; ?>
