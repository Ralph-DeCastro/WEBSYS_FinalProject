<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	$user = current_user();
	$guides = new Guides($pdo);
	$rows = $guides->show_data();
	$can_edit = sees_all($user['role']);

	$page_title = 'How to sort waste';
	$nav_current = 'segregation.php';
	require 'includes/header.php';
?>
	<h1>How to sort waste</h1>
	<p class="lead">Use a separate bag for each kind of waste. The color tells the collector what is inside.</p>
	<?php if ($can_edit) { ?>
		<div class="button-row"><a class="btn" href="add_guide.php">Add a sorting guide</a></div>
	<?php } ?>
	<?php if (!$rows) { ?>
		<div class="empty"><p>The sorting guide has not been written yet.</p></div>
	<?php } else { ?>
		<div class="guides">
			<?php foreach ($rows as $row) { ?>
				<article class="guide <?php echo h(guide_class($row['color_label'])) ?>">
					<p><span class="swatch"><?php echo h($row['color_label']) ?></span></p>
					<h2><?php echo h($row['waste_type']) ?></h2>
					<p><?php echo nl2br(h($row['description'])) ?></p>
					<p><strong>Examples:</strong> <?php echo nl2br(h($row['examples'])) ?></p>
					<p><strong>What to do:</strong> <?php echo nl2br(h($row['how_to_prepare'])) ?></p>
					<?php if ($can_edit) { ?>
						<div class="button-row">
							<a class="btn btn-secondary" href="edit_guide.php?id=<?php echo (int) $row['id'] ?>">Edit</a>
							<a class="btn btn-danger" href="delete_guide.php?id=<?php echo (int) $row['id'] ?>">Remove</a>
						</div>
					<?php } ?>
				</article>
			<?php } ?>
		</div>
	<?php } ?>
<?php require 'includes/footer.php'; ?>
