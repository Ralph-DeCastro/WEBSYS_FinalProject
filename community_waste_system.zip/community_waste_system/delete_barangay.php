<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO']);
	$areas = new Barangays($pdo);
	$id = (int) ($_POST['id'] ?? $_GET['id'] ?? 0);
	$row = $areas->show_data_id($id);
	if (!$row) {
		deny('That area could not be found.', 'barangays.php');
	}
	if (isset($_POST['confirm'])) {
		$areas->delete_data($id);
		set_flash('The area was removed. Schedules already saved were kept.');
		header('Location: barangays.php');
		exit();
	}

	$page_title = 'Remove an area';
	$nav_current = 'barangays.php';
	require 'includes/header.php';
?>
	<h1>Remove this area?</h1>
	<p class="lead"><?php echo h($row['barangay_name'] . ', ' . $row['zone_name']) ?> will be removed from the area list. Collection days already saved will stay.</p>
	<form method="post">
		<input type="hidden" name="id" value="<?php echo (int) $id ?>">
		<div class="button-row">
			<button class="btn-danger" name="confirm" type="submit">Yes, remove this area</button>
			<a class="btn btn-secondary" href="barangays.php">No, keep this area</a>
		</div>
	</form>
<?php require 'includes/footer.php'; ?>
