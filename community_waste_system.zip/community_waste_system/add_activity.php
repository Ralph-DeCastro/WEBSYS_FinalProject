<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO', 'Barangay Personnel', 'Collection Personnel']);
	$user = current_user();
	$activities = new Activities($pdo);
	$users = new Users($pdo);
	$people = $users->show_by_role('Collection Personnel', sees_all($user['role']) ? '' : $user['barangay']);
	$statuses = ['Done', 'In Progress', 'Could not finish'];
	$form = [
		'personnel_id' => $user['role'] === 'Collection Personnel' ? $user['id'] : '',
		'activity_date' => date('Y-m-d'),
		'task_done' => '',
		'status' => 'Done',
		'notes' => '',
	];
	$error = '';

	if (isset($_POST['submit'])) {
		foreach ($form as $key => $value) {
			$form[$key] = posted($key);
		}
		if ($user['role'] === 'Collection Personnel') {
			$form['personnel_id'] = $user['id'];
		}
		$person = $users->show_data_id((int) $form['personnel_id']);
		if (!$person || $person['role'] !== 'Collection Personnel') {
			$error = 'Please choose a collector.';
		} elseif ($user['role'] === 'Barangay Personnel' && $person['barangay'] !== $user['barangay']) {
			$error = 'Choose a collector from your barangay.';
		} elseif ($user['role'] === 'Collection Personnel' && (int) $person['id'] !== (int) $user['id']) {
			$error = 'You can only write your own daily note.';
		} elseif (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $form['activity_date'])) {
			$error = 'Please choose the date.';
		} elseif ($form['task_done'] === '') {
			$error = 'Please say what was done.';
		} elseif (!in_array($form['status'], $statuses, true)) {
			$error = 'Please choose a status.';
		} else {
			$activities->insert_data((int) $person['id'], $form['activity_date'], $form['task_done'], $form['status'], $form['notes']);
			set_flash('The daily note was saved.');
			header('Location: activities.php');
			exit();
		}
	}

	$page_title = 'Write an activity';
	$nav_current = $user['role'] === 'Collection Personnel' ? 'activities.php' : 'personnel.php';
	require 'includes/header.php';
?>
	<h1>Write an activity</h1>
	<p class="lead">Use a short phrase, such as “Started the route” or “Truck problem”.</p>
	<?php if ($error !== '') { ?><div class="alert alert-bad"><?php echo h($error) ?></div><?php } ?>
	<form class="form-card card" method="post">
		<?php if ($user['role'] === 'Collection Personnel') { ?>
			<p>This note will be saved under your name.</p>
		<?php } else { ?>
			<label for="personnel_id">Collector</label>
			<select id="personnel_id" name="personnel_id" required>
				<?php echo user_options($people, $form['personnel_id'], 'Choose a collector') ?>
			</select>
		<?php } ?>
		<label for="activity_date">Date</label>
		<input id="activity_date" type="date" name="activity_date" value="<?php echo h($form['activity_date']) ?>" required>
		<label for="task_done">What was done</label>
		<input id="task_done" type="text" name="task_done" value="<?php echo h($form['task_done']) ?>" required>
		<label for="status">Status</label>
		<select id="status" name="status">
			<?php foreach ($statuses as $status) { ?>
				<option<?php echo selected($form['status'], $status) ?>><?php echo h($status) ?></option>
			<?php } ?>
		</select>
		<label for="notes">More detail <span class="hint">Optional.</span></label>
		<textarea id="notes" name="notes"><?php echo h($form['notes']) ?></textarea>
		<div class="button-row">
			<button name="submit" type="submit">Save activity</button>
			<a class="btn btn-secondary" href="activities.php">Back to the list</a>
		</div>
	</form>
<?php require 'includes/footer.php'; ?>
