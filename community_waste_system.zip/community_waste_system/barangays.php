<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO']);
	$areas = new Barangays($pdo);
	$rows = $areas->show_data();

	$page_title = 'Areas';
	$nav_current = 'barangays.php';
	require 'includes/header.php';
?>
	<h1>Areas</h1>
	<p class="lead">These are the barangays and zones used on the collection schedule.</p>
	<div class="button-row">
		<a class="btn" href="add_barangay.php">Add an area</a>
	</div>
	<?php if (!$rows) { ?>
		<div class="empty"><p>No areas have been saved yet.</p></div>
	<?php } else { ?>
		<div class="table-wrap">
			<table>
				<tr>
					<th>Barangay</th>
					<th>Zone</th>
					<th>Notes</th>
					<th>Actions</th>
				</tr>
				<?php foreach ($rows as $row) { ?>
					<tr>
						<td><?php echo h($row['barangay_name']) ?></td>
						<td><?php echo h($row['zone_name']) ?></td>
						<td><?php echo h($row['notes']) ?></td>
						<td class="actions">
							<a href="edit_barangay.php?id=<?php echo (int) $row['id'] ?>">Edit</a>
							<a href="delete_barangay.php?id=<?php echo (int) $row['id'] ?>">Remove</a>
						</td>
					</tr>
				<?php } ?>
			</table>
		</div>
	<?php } ?>
<?php require 'includes/footer.php'; ?>
