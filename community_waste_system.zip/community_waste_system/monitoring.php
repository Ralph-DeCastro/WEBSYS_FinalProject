<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO', 'Barangay Personnel', 'Collection Personnel']);
	$user = current_user();
	$collections = new Collections($pdo);
	$status = (string) ($_GET['status'] ?? '');
	if (!in_array($status, ['', 'Completed', 'Missed'], true)) {
		$status = '';
	}
	$barangay = '';
	$personnel_id = 0;
	if ($user['role'] === 'Collection Personnel') {
		$personnel_id = (int) $user['id'];
	} elseif (!sees_all($user['role'])) {
		$barangay = $user['barangay'];
	}
	$rows = $collections->show_filtered($barangay, $status, $personnel_id);
	$can_edit = in_array($user['role'], ['Administrator', 'MENRO', 'Barangay Personnel', 'Collection Personnel'], true);

	$page_title = 'Collection monitoring';
	$nav_current = 'monitoring.php';
	require 'includes/header.php';
?>
	<h1><?php echo $user['role'] === 'Collection Personnel' ? 'Trip history' : 'Collection monitoring' ?></h1>
	<p class="lead">This list shows which routes were finished and which were missed.</p>
	<div class="button-row">
		<a class="btn" href="add_collection.php">Record a trip</a>
	</div>
	<form class="filter" method="get">
		<div>
			<label for="status">Show</label>
			<select id="status" name="status">
				<option value="">All trips</option>
				<option value="Completed"<?php echo selected($status, 'Completed') ?>>Completed</option>
				<option value="Missed"<?php echo selected($status, 'Missed') ?>>Missed</option>
			</select>
		</div>
		<button type="submit">Show the list</button>
	</form>
	<?php if (!$rows) { ?>
		<div class="empty"><p>No trips match this list yet.</p></div>
	<?php } else { ?>
		<p class="scroll-hint">Move sideways if you cannot see every column.</p>
		<div class="table-wrap">
			<table>
				<tr>
					<th>Date</th>
					<th>Area</th>
					<th>Waste</th>
					<th>Result</th>
					<th>Collector</th>
					<th>What happened</th>
					<?php if ($can_edit) { ?><th>Actions</th><?php } ?>
				</tr>
				<?php foreach ($rows as $row) { ?>
					<tr>
						<td><?php echo h(format_date($row['collection_date'])) ?></td>
						<td><?php echo h($row['barangay'] . ', ' . $row['zone_name']) ?></td>
						<td><?php echo h($row['waste_category']) ?></td>
						<td><?php echo badge($row['status']) ?></td>
						<td><?php echo h($row['personnel_name']) ?></td>
						<td><?php echo h($row['remarks']) ?></td>
						<?php if ($can_edit) { ?>
							<td class="actions">
								<a href="edit_collection.php?id=<?php echo (int) $row['id'] ?>">Edit</a>
								<?php if ($user['role'] !== 'Collection Personnel') { ?>
									<a href="delete_collection.php?id=<?php echo (int) $row['id'] ?>">Remove</a>
								<?php } ?>
							</td>
						<?php } ?>
					</tr>
				<?php } ?>
			</table>
		</div>
	<?php } ?>
<?php require 'includes/footer.php'; ?>
