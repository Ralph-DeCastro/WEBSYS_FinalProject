<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO', 'Barangay Personnel', 'Collection Personnel']);
	$user = current_user();
	$schedules = new Schedules($pdo);
	$collections = new Collections($pdo);

	if ($user['role'] === 'Collection Personnel') {
		$routes = $schedules->show_by_personnel($user['id']);
	} elseif (!sees_all($user['role'])) {
		$routes = $schedules->show_by_barangay($user['barangay']);
	} else {
		$routes = $schedules->show_data();
	}
	$routes = array_values(array_filter($routes, function ($route) {
		return $route['status'] === 'Active';
	}));

	$form = [
		'schedule_id' => '',
		'collection_date' => date('Y-m-d'),
		'status' => 'Completed',
		'remarks' => '',
	];
	$error = '';

	if (isset($_POST['submit'])) {
		$form['schedule_id'] = posted('schedule_id');
		$form['collection_date'] = posted('collection_date');
		$form['status'] = posted('status');
		$form['remarks'] = posted('remarks');
		$route = $schedules->show_data_id((int) $form['schedule_id']);
		$allowed_ids = array_map(function ($item) {
			return (int) $item['id'];
		}, $routes);

		if (!$route || !in_array((int) $route['id'], $allowed_ids, true)) {
			$error = 'Please choose one of your routes.';
		} elseif (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $form['collection_date'])) {
			$error = 'Please choose the date.';
		} elseif (!in_array($form['status'], ['Completed', 'Missed'], true)) {
			$error = 'Please choose whether the trip was finished or missed.';
		} elseif ($form['status'] === 'Missed' && $form['remarks'] === '') {
			$error = 'Please say why the truck missed this route.';
		} else {
			$collections->insert_data((int) $route['id'], $route['barangay'], $route['zone_name'], $route['waste_category'], $form['collection_date'], $form['status'], (int) $route['personnel_id'], $form['remarks'], (int) $user['id']);
			set_flash($form['status'] === 'Completed' ? 'The finished trip was saved.' : 'The missed trip was saved.');
			header('Location: monitoring.php');
			exit();
		}
	}

	$page_title = 'Record a trip';
	$nav_current = 'monitoring.php';
	require 'includes/header.php';
?>
	<h1>Record a trip</h1>
	<p class="lead">Save what happened on one collection route. Choose Missed if the truck did not collect the waste.</p>
	<?php if ($error !== '') { ?><div class="alert alert-bad"><?php echo h($error) ?></div><?php } ?>
	<?php if (!$routes) { ?>
		<div class="empty"><p>There is no active route to record yet.</p></div>
		<a class="btn btn-secondary" href="monitoring.php">Back to the list</a>
	<?php } else { ?>
		<form class="form-card card" method="post">
			<label for="schedule_id">Route</label>
			<select id="schedule_id" name="schedule_id" required>
				<?php echo schedule_options($routes, $form['schedule_id']) ?>
			</select>
			<label for="collection_date">Date</label>
			<input id="collection_date" type="date" name="collection_date" value="<?php echo h($form['collection_date']) ?>" required>
			<label>What happened</label>
			<label class="choice">
				<input type="radio" name="status" value="Completed"<?php echo checked_value($form['status'], 'Completed') ?> required>
				<span>Completed</span>
				<small>The truck collected the waste on this route.</small>
			</label>
			<label class="choice">
				<input type="radio" name="status" value="Missed"<?php echo checked_value($form['status'], 'Missed') ?>>
				<span>Missed</span>
				<small>The truck did not collect the waste. Please say why.</small>
			</label>
			<label for="remarks">What happened <span class="hint">Required when the trip was missed.</span></label>
			<textarea id="remarks" name="remarks"><?php echo h($form['remarks']) ?></textarea>
			<div class="button-row">
				<button name="submit" type="submit">Save this trip</button>
				<a class="btn btn-secondary" href="monitoring.php">Back to the list</a>
			</div>
		</form>
	<?php } ?>
<?php require 'includes/footer.php'; ?>
