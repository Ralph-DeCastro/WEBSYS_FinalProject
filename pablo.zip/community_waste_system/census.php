<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO', 'Barangay Personnel']);
	$user = current_user();
	$households = new Households($pdo);
	$areas_model = new Barangays($pdo);
	$ready = $households->ready();

	$scope = sees_all($user['role']) ? '' : $user['barangay'];
	$status = (string) ($_GET['status'] ?? '');
	if (!in_array($status, ['', 'Active', 'Inactive'], true)) {
		$status = '';
	}
	$biohazard = !empty($_GET['biohazard']);
	$search = trim((string) ($_GET['q'] ?? ''));
	$barangay = $scope;
	if ($scope === '') {
		$wanted = (string) ($_GET['barangay'] ?? '');
		foreach ($areas_model->show_names() as $name) {
			if ($name['barangay_name'] === $wanted) {
				$barangay = $wanted;
			}
		}
	}

	$totals = ['households' => 0, 'people' => 0, 'biohazard' => 0, 'inactive' => 0];
	$by_area = [];
	$rows = [];
	if ($ready) {
		$totals = $households->totals($scope);
		$by_area = $households->by_area($scope);
		$rows = $households->show_filtered($barangay, $status, $biohazard, $search);
	}

	$page_title = 'Census';
	$nav_current = 'census.php';
	require 'includes/header.php';
?>
	<h1>Household census</h1>
	<p class="lead">This is the count of households and people the trucks serve<?php echo $scope !== '' ? ' in ' . h($scope) : '' ?>. It helps plan routes and spot areas with no collection day.</p>

	<?php if (!$ready) { ?>
		<div class="alert alert-bad">The census table is not set up yet. Open <a href="install.php">the setup page</a> once. It will add the table without erasing any records.</div>
	<?php } else { ?>
		<div class="tiles">
			<a class="tile" href="census.php"><span class="tile-number"><?php echo (int) $totals['households'] ?></span><span class="tile-title">Households</span><span class="tile-text">Active households counted.</span></a>
			<a class="tile" href="census.php"><span class="tile-number"><?php echo (int) $totals['people'] ?></span><span class="tile-title">People</span><span class="tile-text">Total living in those households.</span></a>
			<a class="tile" href="census.php?biohazard=1"><span class="tile-number"><?php echo (int) $totals['biohazard'] ?></span><span class="tile-title">Biohazard pickup</span><span class="tile-text">Households that need a medical waste pickup.</span></a>
			<a class="tile" href="census.php?status=Inactive"><span class="tile-number"><?php echo (int) $totals['inactive'] ?></span><span class="tile-title">Inactive</span><span class="tile-text">Moved away or no longer served.</span></a>
		</div>

		<div class="button-row">
			<a class="btn" href="add_household.php">Add a household</a>
		</div>

		<h2>By area</h2>
		<?php if (!$by_area) { ?>
			<div class="empty"><p>No households have been counted yet.</p></div>
		<?php } else { ?>
			<div class="table-wrap">
				<table>
					<tr>
						<th>Area</th>
						<th>Households</th>
						<th>People</th>
						<th>Average size</th>
						<th>Biohazard pickup</th>
						<th>Collection day</th>
					</tr>
					<?php foreach ($by_area as $area) { ?>
						<tr>
							<td><?php echo h($area['barangay'] . ', ' . $area['zone_name']) ?></td>
							<td><?php echo (int) $area['households'] ?></td>
							<td><?php echo (int) $area['people'] ?></td>
							<td><?php echo h(number_format($area['people'] / $area['households'], 1)) ?></td>
							<td><?php echo (int) $area['biohazard'] ?></td>
							<td><?php echo (int) $area['no_schedule'] > 0 ? '<span class="badge badge-warn">No active schedule</span>' : '<span class="badge badge-good">Scheduled</span>' ?></td>
						</tr>
					<?php } ?>
				</table>
			</div>
		<?php } ?>

		<h2>Households</h2>
		<form class="filter" method="get">
			<?php if ($scope === '') { ?>
				<div>
					<label for="barangay">Barangay</label>
					<select id="barangay" name="barangay">
						<option value="">All barangays</option>
						<?php foreach ($areas_model->show_names() as $name) { ?>
							<option value="<?php echo h($name['barangay_name']) ?>"<?php echo selected($barangay, $name['barangay_name']) ?>><?php echo h($name['barangay_name']) ?></option>
						<?php } ?>
					</select>
				</div>
			<?php } ?>
			<div>
				<label for="status">Show</label>
				<select id="status" name="status">
					<option value="">All households</option>
					<option value="Active"<?php echo selected($status, 'Active') ?>>Active</option>
					<option value="Inactive"<?php echo selected($status, 'Inactive') ?>>Inactive</option>
				</select>
			</div>
			<div>
				<label for="q">Name or address</label>
				<input id="q" type="text" name="q" value="<?php echo h($search) ?>">
			</div>
			<label class="choice">
				<input type="checkbox" name="biohazard" value="1"<?php echo checked_value($biohazard ? '1' : '', '1') ?>>
				<span>Biohazard pickup only</span>
			</label>
			<button type="submit">Show the list</button>
		</form>

		<?php if (!$rows) { ?>
			<div class="empty"><p>No households match this list.</p></div>
		<?php } else { ?>
			<p class="scroll-hint">Move sideways if you cannot see every column.</p>
			<div class="table-wrap">
				<table>
					<tr>
						<th>Household head</th>
						<th>Area</th>
						<th>Address</th>
						<th>People</th>
						<th>Kind</th>
						<th>Bags put out at</th>
						<th>Biohazard</th>
						<th>Account</th>
						<th>Counted</th>
						<th>Status</th>
						<th>Actions</th>
					</tr>
					<?php foreach ($rows as $row) { ?>
						<tr>
							<td><?php echo h($row['household_head']) ?></td>
							<td><?php echo h($row['barangay'] . ', ' . $row['zone_name']) ?></td>
							<td><?php echo h($row['address']) ?></td>
							<td><?php echo (int) $row['member_count'] ?></td>
							<td><?php echo h($row['household_type']) ?></td>
							<td><?php echo h($row['pickup_point']) ?></td>
							<td><?php echo $row['needs_biohazard'] ? '<span class="badge badge-warn">Pickup</span>' : '' ?></td>
							<td><?php echo h($row['account_name'] ?? '') ?></td>
							<td><?php echo h(format_date($row['census_date'])) ?></td>
							<td><?php echo badge($row['status']) ?></td>
							<td class="actions">
								<a href="edit_household.php?id=<?php echo (int) $row['id'] ?>">Edit</a>
								<a href="delete_household.php?id=<?php echo (int) $row['id'] ?>">Remove</a>
							</td>
						</tr>
					<?php } ?>
				</table>
			</div>
		<?php } ?>

		<section class="card">
			<h2>Handle with care</h2>
			<p>Household records are personal information. Record only what the collection program needs. Never write health details, only whether a sealed medical waste pickup is needed. Residents and collectors cannot open this page.</p>
		</section>
	<?php } ?>
<?php require 'includes/footer.php'; ?>
