<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';
	require_once 'includes/household_form.php';

	require_login();
	require_role(['Administrator', 'MENRO', 'Barangay Personnel']);
	$user = current_user();
	$households = new Households($pdo);
	if (!$households->ready()) {
		deny('The census table is not set up yet. Open install.php once, then try again.', 'dashboard.php');
	}
	$areas_model = new Barangays($pdo);
	$users = new Users($pdo);
	$id = (int) ($_POST['id'] ?? $_GET['id'] ?? 0);
	$row = $households->show_data_id($id);
	if (!$row) {
		deny('That household could not be found.', 'census.php');
	}
	if (!owns_record($row['barangay'])) {
		deny('You can only change households in your own barangay.', 'census.php');
	}

	$scope = sees_all($user['role']) ? '' : $user['barangay'];
	$areas = $areas_model->show_data();
	if ($scope !== '') {
		$areas = array_values(array_filter($areas, function ($area) use ($scope) {
			return $area['barangay_name'] === $scope;
		}));
	}
	$residents = $users->show_by_role('Resident', $scope);

	$selected_area = '';
	foreach ($areas as $area) {
		if ($area['barangay_name'] === $row['barangay'] && $area['zone_name'] === $row['zone_name']) {
			$selected_area = $area['id'];
		}
	}
	$form = [
		'area_id' => $selected_area,
		'household_head' => $row['household_head'],
		'address' => $row['address'],
		'contact_number' => $row['contact_number'],
		'member_count' => (string) $row['member_count'],
		'household_type' => $row['household_type'],
		'pickup_point' => $row['pickup_point'],
		'needs_biohazard' => (bool) $row['needs_biohazard'],
		'resident_user_id' => $row['resident_user_id'] === null ? '' : (string) $row['resident_user_id'],
		'census_date' => $row['census_date'],
		'status' => $row['status'],
	];
	$error = '';

	if (isset($_POST['edit'])) {
		$form = household_from_post();
		list($error, $area) = household_check($form, $areas_model, $users, $households, $user, $id);
		if ($error === '') {
			$households->update_data(
				$id, $area['barangay_name'], $area['zone_name'], $form['household_head'], $form['address'],
				$form['contact_number'], (int) $form['member_count'], $form['household_type'], $form['pickup_point'],
				$form['needs_biohazard'] ? 1 : 0, $form['resident_user_id'] === '' ? null : (int) $form['resident_user_id'],
				$form['census_date'], $form['status']
			);
			set_flash('The household was updated.');
			header('Location: census.php');
			exit();
		}
	}

	$page_title = 'Edit a household';
	$nav_current = 'census.php';
	require 'includes/header.php';
?>
	<h1>Edit a household</h1>
	<p class="lead">If a family moved away, set the status to Inactive instead of removing the record. The counts will stay correct.</p>
	<?php if ($error !== '') { ?><div class="alert alert-bad"><?php echo h($error) ?></div><?php } ?>
	<?php household_form($form, $areas, $residents, 'edit', 'Save changes', $id) ?>
<?php require 'includes/footer.php'; ?>
