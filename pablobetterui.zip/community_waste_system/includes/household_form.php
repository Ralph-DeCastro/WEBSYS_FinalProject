<?php

function text_length($value){
	return function_exists('mb_strlen') ? mb_strlen($value) : strlen($value);
}

function household_from_post(){
	return [
		'area_id' => posted('area_id'),
		'household_head' => posted('household_head'),
		'address' => posted('address'),
		'contact_number' => posted('contact_number'),
		'member_count' => posted('member_count'),
		'household_type' => posted('household_type'),
		'pickup_point' => posted('pickup_point'),
		'needs_biohazard' => !empty($_POST['needs_biohazard']),
		'resident_user_id' => posted('resident_user_id'),
		'census_date' => posted('census_date'),
		'status' => posted('status'),
	];
}

function household_check($form, $areas_model, $users, $households, $user, $exclude_id = 0){
	$area = $areas_model->show_data_id((int) $form['area_id']);
	$error = '';

	if (!$area) {
		$error = 'Please choose an area.';
	} elseif (!sees_all($user['role']) && $area['barangay_name'] !== $user['barangay']) {
		$error = 'You can only record households in your own barangay.';
	} elseif ($form['household_head'] === '' || text_length($form['household_head']) > 120) {
		$error = 'Please type the name of the household head, up to 120 letters.';
	} elseif ($form['address'] === '' || text_length($form['address']) > 255) {
		$error = 'Please type the street or house address.';
	} elseif (!ctype_digit($form['member_count']) || (int) $form['member_count'] < 1 || (int) $form['member_count'] > 50) {
		$error = 'Please type how many people live here, from 1 to 50.';
	} elseif (!in_array($form['household_type'], household_types(), true)) {
		$error = 'Please choose the kind of household.';
	} elseif (!preg_match('/^[0-9+()\- ]{0,30}$/', $form['contact_number'])) {
		$error = 'The contact number should only have numbers, spaces, + and dashes.';
	} elseif (text_length($form['pickup_point']) > 255) {
		$error = 'The pickup point is too long. Please shorten it.';
	} elseif (!valid_date($form['census_date']) || $form['census_date'] > date('Y-m-d')) {
		$error = 'Please choose the date the household was counted. It cannot be in the future.';
	} elseif (!in_array($form['status'], ['Active', 'Inactive'], true)) {
		$error = 'Please choose a status.';
	}

	if ($error === '' && $form['resident_user_id'] !== '') {
		$person = $users->show_data_id((int) $form['resident_user_id']);
		if (!$person || $person['role'] !== 'Resident') {
			$error = 'Please choose a resident from the list, or leave it as no account.';
		} elseif ($person['barangay'] !== $area['barangay_name']) {
			$error = 'That resident lives in a different barangay.';
		}
	}

	if ($error === '' && $households->duplicate_exists($area['barangay_name'], $area['zone_name'], $form['address'], $form['household_head'], (int) $exclude_id)) {
		$error = 'This household is already on the list at that address.';
	}

	return [$error, $area];
}

function household_form($form, $areas, $residents, $submit_name, $submit_label, $id = 0){
?>
	<form class="form-card card" method="post">
		<?php if ($id) { ?><input type="hidden" name="id" value="<?php echo (int) $id ?>"><?php } ?>
		<label for="area_id">Area</label>
		<select id="area_id" name="area_id" required>
			<?php echo area_options($areas, $form['area_id']) ?>
		</select>
		<label for="household_head">Household head <span class="hint">The person the household is counted under.</span></label>
		<input id="household_head" type="text" name="household_head" maxlength="120" value="<?php echo h($form['household_head']) ?>" required>
		<label for="address">Address <span class="hint">Street, house number, or landmark.</span></label>
		<input id="address" type="text" name="address" maxlength="255" value="<?php echo h($form['address']) ?>" required>
		<label for="member_count">People living here</label>
		<input id="member_count" type="number" name="member_count" min="1" max="50" value="<?php echo h($form['member_count']) ?>" required>
		<label for="household_type">Kind of household</label>
		<select id="household_type" name="household_type">
			<?php foreach (household_types() as $type) { ?>
				<option value="<?php echo h($type) ?>"<?php echo selected($form['household_type'], $type) ?>><?php echo h($type) ?></option>
			<?php } ?>
		</select>
		<label for="pickup_point">Where the bags are put out <span class="hint">Optional.</span></label>
		<input id="pickup_point" type="text" name="pickup_point" maxlength="255" value="<?php echo h($form['pickup_point']) ?>">
		<label for="contact_number">Contact number <span class="hint">Optional.</span></label>
		<input id="contact_number" type="text" name="contact_number" maxlength="30" value="<?php echo h($form['contact_number']) ?>">
		<label class="choice">
			<input type="checkbox" name="needs_biohazard" value="1"<?php echo $form['needs_biohazard'] ? ' checked' : '' ?>>
			<span>Needs biohazard pickup</span>
			<small>Tick this only if the household regularly has sealed medical waste, such as used needles. Do not write any health details here.</small>
		</label>
		<label for="resident_user_id">Resident account <span class="hint">Optional. Link a person who signs in to this system.</span></label>
		<select id="resident_user_id" name="resident_user_id">
			<?php echo user_options($residents, $form['resident_user_id'], 'No account') ?>
		</select>
		<label for="census_date">Date counted</label>
		<input id="census_date" type="date" name="census_date" max="<?php echo h(date('Y-m-d')) ?>" value="<?php echo h($form['census_date']) ?>" required>
		<label for="status">Status</label>
		<select id="status" name="status">
			<option value="Active"<?php echo selected($form['status'], 'Active') ?>>Active</option>
			<option value="Inactive"<?php echo selected($form['status'], 'Inactive') ?>>Inactive (moved away or no longer served)</option>
		</select>
		<div class="button-row">
			<button name="<?php echo h($submit_name) ?>" type="submit"><?php echo h($submit_label) ?></button>
			<a class="btn btn-secondary" href="census.php">Back to the list</a>
		</div>
	</form>
<?php
}
