<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	$user = current_user();
	$schedules = new Schedules($pdo);

	if ($user['role'] === 'Collection Personnel') {
		$routes = $schedules->show_by_personnel($user['id']);
	} elseif (!sees_all($user['role'])) {
		$routes = $schedules->show_by_barangay($user['barangay']);
	} else {
		$routes = $schedules->show_data();
	}
	$routes = array_values(array_filter($routes, function ($route) {
		return $route['status'] === 'Active' && $route['waste_category'] === 'Biohazard';
	}));

	$flagged = null;
	if (in_array($user['role'], ['Administrator', 'MENRO', 'Barangay Personnel'], true)) {
		try {
			$flagged_totals = (new Households($pdo))->totals(sees_all($user['role']) ? '' : $user['barangay']);
			$flagged = (int) $flagged_totals['biohazard'];
		} catch (PDOException $e) {
			$flagged = null;
		}
	}

	$page_title = 'Biohazard waste';
	$nav_current = 'biohazard.php';
	require 'includes/header.php';
?>
	<h1>Biohazard waste</h1>
	<p class="lead">Keep medical waste separate from regular garbage and recycling. The barangay coordinates pickup or a safe hand-off to an accredited hauler; this system does not treat or dispose of infectious waste.</p>

	<section class="card">
		<h2>Household safety</h2>
		<ul>
			<li>Used needles, syringes, lancets, soiled dressings, and used masks should be kept out of regular trash and recyclables.</li>
			<li>Place sharps in a tightly closed, puncture-resistant plastic container. Do not use thin bags or glass containers.</li>
			<li>Place other medical-care items in a leak-resistant, tightly sealed bag and clearly mark it as biohazard waste.</li>
			<li>Keep the container away from children, animals, collectors, and food.</li>
			<li>Never recap, bend, or handle loose needles. Do not burn or bury this waste.</li>
		</ul>
	</section>

	<div class="button-row">
		<a class="btn" href="add_complaint.php">Request pickup or report an incident</a>
		<a class="btn btn-secondary" href="complaints.php"><?php echo $user['role'] === 'Resident' ? 'View my reports' : 'View biohazard reports' ?></a>
	</div>

	<?php if ($flagged !== null) { ?>
		<section class="card">
			<h2>Households that need a pickup</h2>
			<p><strong><?php echo $flagged ?></strong> active household<?php echo $flagged === 1 ? '' : 's' ?> in the census <?php echo $flagged === 1 ? 'is' : 'are' ?> marked as needing a biohazard pickup.</p>
			<div class="button-row"><a class="btn btn-secondary" href="census.php?biohazard=1">See the list</a></div>
		</section>
	<?php } ?>

	<h2>Biohazard pickup schedule</h2>
	<?php if (!$routes) { ?>
		<div class="empty"><p>No active biohazard pickup schedule is shown for <?php echo h($user['role'] === 'Resident' || $user['role'] === 'Barangay Personnel' ? $user['barangay'] : 'the system'); ?>.</p></div>
	<?php } else { ?>
		<div class="table-wrap">
			<table>
				<tr>
					<th>Area</th>
					<th>How often</th>
					<th>Days</th>
					<th>Time</th>
					<th>Collector</th>
					<th>Note</th>
				</tr>
				<?php foreach ($routes as $route) { ?>
					<tr>
						<td><?php echo h($route['barangay'] . ', ' . $route['zone_name']) ?></td>
						<td><?php echo h($route['frequency']) ?></td>
						<td><?php echo h($route['collection_day']) ?></td>
						<td><?php echo h(format_time($route['collection_time'])) ?></td>
						<td><?php echo h($route['personnel_name']) ?></td>
						<td><?php echo h($route['notes']) ?></td>
					</tr>
				<?php } ?>
			</table>
		</div>
	<?php } ?>

	<section class="card">
		<h2>When reporting</h2>
		<p>For a pickup request, give the barangay and the safest hand-off location. For exposed sharps or a spill, describe the exact public location and keep people away. Do not place yourself at risk to clean or move the waste.</p>
	</section>
<?php require 'includes/footer.php'; ?>
