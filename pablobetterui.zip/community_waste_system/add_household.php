<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';
	require_once 'includes/household_form.php';

	require_login();
	require_role(['Administrator', 'MENRO', 'Barangay Personnel']);
	$user = current_user();
	$households = new Households($pdo);
	if (!$households->ready()) {
		deny('The census table is not set up yet. Open install.php once, then try again.', 'dashboard.php');
	}
	$areas_model = new Barangays($pdo);
	$users = new Users($pdo);
	$scope = sees_all($user['role']) ? '' : $user['barangay'];
	$areas = $areas_model->show_data();
	if ($scope !== '') {
		$areas = array_values(array_filter($areas, function ($area) use ($scope) {
			return $area['barangay_name'] === $scope;
		}));
	}
	$residents = $users->show_by_role('Resident', $scope);

	$form = [
		'area_id' => '',
		'household_head' => '',
		'address' => '',
		'contact_number' => '',
		'member_count' => '',
		'household_type' => 'Residential',
		'pickup_point' => '',
		'needs_biohazard' => false,
		'resident_user_id' => '',
		'census_date' => date('Y-m-d'),
		'status' => 'Active',
	];
	$error = '';

	if (isset($_POST['submit'])) {
		$form = household_from_post();
		list($error, $area) = household_check($form, $areas_model, $users, $households, $user);
		if ($error === '') {
			$households->insert_data(
				$area['barangay_name'], $area['zone_name'], $form['household_head'], $form['address'],
				$form['contact_number'], (int) $form['member_count'], $form['household_type'], $form['pickup_point'],
				$form['needs_biohazard'] ? 1 : 0, $form['resident_user_id'] === '' ? null : (int) $form['resident_user_id'],
				$form['census_date'], $form['status'], (int) $user['id']
			);
			set_flash('The household was saved.');
			header('Location: census.php');
			exit();
		}
	}

	$page_title = 'Add a household';
	$nav_current = 'census.php';
	require 'includes/header.php';
?>
	<h1>Add a household</h1>
	<p class="lead">Record one household in the census. Only write what the collection program needs.</p>
	<?php if ($error !== '') { ?><div class="alert alert-bad"><?php echo h($error) ?></div><?php } ?>
	<?php household_form($form, $areas, $residents, 'submit', 'Save household') ?>
<?php require 'includes/footer.php'; ?>
