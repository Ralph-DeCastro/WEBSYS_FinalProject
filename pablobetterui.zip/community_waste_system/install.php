<?php
	require_once 'includes/auth.php';

	$host = 'localhost';
	$username = 'root';
	$password = '';
	$db_name = 'community_waste_db';
	$charset = 'utf8mb4';
	$attributes = [
		PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
		PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
		PDO::ATTR_EMULATE_PREPARES => false,
	];

	$error = '';
	$done = false;
	$already = false;
	$household_count = 0;
	$households_loaded = false;

	function run_sql_file($pdo, $path){
		$script = file_get_contents($path);
		$parts = preg_split('/;\s*[\r\n]+/', $script);
		foreach ($parts as $statement) {
			$statement = trim($statement);
			if ($statement === '') {
				continue;
			}
			$pdo->exec($statement);
		}
	}

	function seed_households($pdo){
		$find = $pdo->prepare("SELECT id FROM users WHERE username = :username");
		$user_id = function ($username) use ($find) {
			$find->execute([':username' => $username]);
			$id = $find->fetchColumn();
			return $id === false ? null : (int) $id;
		};
		$recorded_by = $user_id('m.santos');
		if ($recorded_by === null) {
			$first = $pdo->query("SELECT id FROM users ORDER BY id LIMIT 1")->fetchColumn();
			$recorded_by = $first === false ? 0 : (int) $first;
		}
		$households = new Households($pdo);
		$day = function ($days) {
			return date('Y-m-d', strtotime('-' . $days . ' days'));
		};

		$households->insert_data('Poblacion', 'Zone 1', 'Rosa Mendoza', '12 Rizal Street', '09211234567', 5, 'Residential', 'Front gate, Rizal Street', 0, $user_id('r.mendoza'), $day(30), 'Active', $recorded_by);
		$households->insert_data('Poblacion', 'Zone 1', 'Eduardo Villanueva', '18 Rizal Street', '', 3, 'Residential', 'Beside the corner post', 1, null, $day(30), 'Active', $recorded_by);
		$households->insert_data('Poblacion', 'Zone 2', 'Lourdes Tan', 'Market Row, Stall 4', '09171112222', 4, 'Commercial', 'Beside the market gate', 0, null, $day(28), 'Active', $recorded_by);
		$households->insert_data('Poblacion', 'Zone 2', 'Carlos Bautista', '7 Mabuhay Lane', '', 6, 'Residential', 'In front of the house', 0, null, $day(28), 'Active', $recorded_by);
		$households->insert_data('San Isidro', 'Zone 1', 'Elena Cruz', '3 Main Road', '09183334444', 4, 'Residential', 'Main road, near the post', 1, null, $day(21), 'Active', $recorded_by);
		$households->insert_data('Santa Cruz', 'Zone 1', 'Pedro Santos', 'Chapel Road', '09221234567', 5, 'Residential', 'In front of the chapel', 0, $user_id('p.santos'), $day(14), 'Active', $recorded_by);
		$households->insert_data('Santa Cruz', 'Zone 1', 'Nena Dizon', '9 Chapel Road', '', 2, 'Residential', 'Chapel Road', 0, null, $day(14), 'Inactive', $recorded_by);
		$households->insert_data('Mabini', 'Zone 1', 'Ramon Aquino', 'Outer Road, km 2', '', 7, 'Residential', 'Roadside, near the sign', 0, null, $day(7), 'Active', $recorded_by);
	}

	function seed_sample($pdo){
		$users = new Users($pdo);
		$areas = new Barangays($pdo);
		$schedules = new Schedules($pdo);
		$collections = new Collections($pdo);
		$complaints = new Complaints($pdo);
		$guides = new Guides($pdo);
		$materials = new Materials($pdo);
		$transactions = new Transactions($pdo);
		$assignments = new Assignments($pdo);
		$activities = new Activities($pdo);
		$news = new Announcements($pdo);

		$passwords = [
			'admin' => password_hash('admin123', PASSWORD_DEFAULT),
			'menro' => password_hash('menro123', PASSWORD_DEFAULT),
			'barangay' => password_hash('barangay123', PASSWORD_DEFAULT),
			'collector' => password_hash('collector123', PASSWORD_DEFAULT),
			'resident' => password_hash('resident123', PASSWORD_DEFAULT),
		];

		$users->insert_data('System Administrator', 'admin', $passwords['admin'], 'Administrator', '', '09170000000', 'Municipal Hall', 'Active');
		$admin_id = (int) $pdo->lastInsertId();
		$users->insert_data('Maria Santos', 'm.santos', $passwords['menro'], 'MENRO', 'Poblacion', '09171234567', 'MENRO Office', 'Active');
		$menro_id = (int) $pdo->lastInsertId();
		$users->insert_data('Jose Ramos', 'j.ramos', $passwords['barangay'], 'Barangay Personnel', 'Poblacion', '09181234567', 'Barangay Hall, Poblacion', 'Active');
		$users->insert_data('Juan Dela Cruz', 'j.delacruz', $passwords['collector'], 'Collection Personnel', 'Poblacion', '09191234567', 'Depot Road', 'Active');
		$juan_id = (int) $pdo->lastInsertId();
		$users->insert_data('Ana Reyes', 'a.reyes', $passwords['collector'], 'Collection Personnel', 'San Isidro', '09201234567', 'San Isidro Depot', 'Active');
		$ana_id = (int) $pdo->lastInsertId();
		$users->insert_data('Rosa Mendoza', 'r.mendoza', $passwords['resident'], 'Resident', 'Poblacion', '09211234567', '12 Rizal Street', 'Active');
		$rosa_id = (int) $pdo->lastInsertId();
		$users->insert_data('Pedro Santos', 'p.santos', $passwords['resident'], 'Resident', 'Santa Cruz', '09221234567', 'Chapel Road', 'Active');
		$pedro_id = (int) $pdo->lastInsertId();

		$areas->insert_data('Poblacion', 'Zone 1', 'Town center');
		$areas->insert_data('Poblacion', 'Zone 2', 'Market area');
		$areas->insert_data('San Isidro', 'Zone 1', 'Along the main road');
		$areas->insert_data('Santa Cruz', 'Zone 1', 'Chapel area');
		$areas->insert_data('Mabini', 'Zone 1', 'Outer road');

		$weekdays = 'Monday, Tuesday, Wednesday, Thursday, Friday, Saturday';
		$schedules->insert_data('Poblacion', 'Zone 1', 'Biodegradable', $juan_id, 'Daily', $weekdays, '06:00:00', 'Put the green bag out before 6:00 AM.', 'Active');
		$schedule_bio = (int) $pdo->lastInsertId();
		$schedules->insert_data('Poblacion', 'Zone 1', 'Recyclable', $juan_id, 'Weekly', 'Wednesday', '06:30:00', 'Rinse bottles and keep them dry.', 'Active');
		$schedules->insert_data('Poblacion', 'Zone 2', 'Residual', $juan_id, 'Twice a week', 'Tuesday, Friday', '07:00:00', 'Tie the bag shut.', 'Active');
		$schedules->insert_data('Poblacion', 'Zone 1', 'Biohazard', $juan_id, 'Weekly', 'Saturday', '10:00:00', 'Household biohazard pickup only. Never mix it with regular garbage or recyclables.', 'Active');
		$schedules->insert_data('San Isidro', 'Zone 1', 'Biodegradable', $ana_id, 'Daily', $weekdays, '07:00:00', 'Start at the main road.', 'Active');
		$schedule_san = (int) $pdo->lastInsertId();
		$schedules->insert_data('Santa Cruz', 'Zone 1', 'Biodegradable', $ana_id, 'Twice a week', 'Tuesday, Friday', '08:00:00', 'Chapel road first.', 'Active');
		$schedule_cruz = (int) $pdo->lastInsertId();
		$schedules->insert_data('Mabini', 'Zone 1', 'Special', $juan_id, 'Weekly', 'Saturday', '09:00:00', 'Batteries, bulbs, and medicine only.', 'Active');

		$today = date('Y-m-d');
		$yesterday = date('Y-m-d', strtotime('-1 day'));
		$three_days = date('Y-m-d', strtotime('-3 days'));

		$collections->insert_data($schedule_bio, 'Poblacion', 'Zone 1', 'Biodegradable', $today, 'Completed', $juan_id, 'All bags along Rizal Street were collected.', $juan_id);
		$collections->insert_data($schedule_bio, 'Poblacion', 'Zone 1', 'Biodegradable', $yesterday, 'Completed', $juan_id, 'Route finished before 8:00 AM.', $juan_id);
		$collections->insert_data($schedule_san, 'San Isidro', 'Zone 1', 'Biodegradable', $three_days, 'Completed', $ana_id, 'Route finished.', $ana_id);
		$collections->insert_data($schedule_cruz, 'Santa Cruz', 'Zone 1', 'Biodegradable', $yesterday, 'Missed', $ana_id, 'The truck broke down before reaching Santa Cruz.', $ana_id);

		$complaints->insert_data($rosa_id, 'Rosa Mendoza', 'Uncollected garbage', 'Poblacion', 'Rizal Street corner', 'The bags from the last pickup are still outside the house.', null);
		$complaints->insert_data($pedro_id, 'Pedro Santos', 'Blocked drainage', 'Santa Cruz', 'In front of the chapel', 'Leaves and plastic are blocking the canal.', null);

		$guides->insert_data('Biodegradable waste', 'Food scraps, leaves, and other waste that can break down.', 'Fruit peels, leftover rice, vegetable scraps, garden leaves, and wet paper.', 'Drain the liquid. Use a green bag or a bag marked BIO. Put it out on the morning of collection day.', 'Green');
		$guides->insert_data('Recyclable waste', 'Clean items that can be made into new products.', 'Plastic bottles, paper, cardboard, glass bottles, and metal cans.', 'Rinse the containers. Keep them dry. Flatten boxes. Use a blue bag or a bag marked RECYCLE.', 'Blue');
		$guides->insert_data('Residual waste', 'Trash that cannot be composted or recycled.', 'Dirty plastic wrappers, foam, snack packs, and worn-out household items.', 'Bag it securely. Do not mix in food waste or bottles.', 'Black');
		$guides->insert_data('Special waste', 'Items that can harm people or the soil if they go in the regular truck.', 'Batteries, light bulbs, paint, medicine, electronics, and sharp objects.', 'Do not put these in the regular truck. Bring them to the recycling center or wait for the Saturday special pickup.', 'Red');
		$guides->insert_data('Community guidelines', 'Simple rules that keep the street clean and the truck on time.', 'Put trash out before the truck time. Tie every bag. Keep the drain in front of the house clear.', 'Do not burn trash. Do not leave bags out overnight if animals can open them. If the truck misses the street, report it in this system.', 'Gold');

		$materials->insert_data('Plastic bottles', 'Recyclable', 'kg', 12, 'Active');
		$plastic_id = (int) $pdo->lastInsertId();
		$materials->insert_data('Cardboard', 'Recyclable', 'kg', 5, 'Active');
		$cardboard_id = (int) $pdo->lastInsertId();
		$materials->insert_data('Aluminum cans', 'Recyclable', 'kg', 40, 'Active');
		$can_id = (int) $pdo->lastInsertId();
		$materials->insert_data('Glass bottles', 'Recyclable', 'kg', 2, 'Active');
		$materials->insert_data('Paper', 'Recyclable', 'kg', 4, 'Active');

		$transactions->insert_data($plastic_id, 'Drop-off', 'Rosa Mendoza', $rosa_id, 2.5, 30, $today, 'Clean bottles.', $menro_id);
		$transactions->insert_data($cardboard_id, 'Drop-off', 'Pedro Santos', $pedro_id, 4, 20, $yesterday, 'Flattened boxes.', $menro_id);
		$transactions->insert_data($can_id, 'Sale', 'Recycling Center', null, 20, 800, $three_days, 'Cans sold to the buyer.', $menro_id);

		$assignments->insert_data($juan_id, $schedule_bio, $today, 'Morning', 'Assigned', 'Start at the town hall.');
		$assignments->insert_data($ana_id, $schedule_san, $today, 'Morning', 'Assigned', 'Bring the extra bags.');

		$activities->insert_data($juan_id, $today, 'Started the route', 'Done', 'Left the depot at 5:40 AM.');
		$activities->insert_data($ana_id, $yesterday, 'Truck problem', 'Could not finish', 'The truck stopped before Santa Cruz.');

		$news->insert_data('Poblacion pickup starts at 6:00 in the morning', 'Collection announcements', 'Please put your bags out before 6:00 AM. The truck will not return for bags that are put out late.', 'Everyone', $menro_id, $today, 'Published');
		$news->insert_data('Clean drainage week', 'Environmental campaigns', 'This week, keep the canal in front of your house clear of leaves and plastic. A blocked drain floods the street when it rains.', 'Everyone', $admin_id, $today, 'Published');
		$news->insert_data('Bring clean bottles and cans to the center', 'Recycling programs', 'The recycling center pays for clean plastic bottles, cardboard, and aluminum cans. Rinse them first and keep them dry.', 'Residents', $menro_id, $today, 'Published');
		$news->insert_data('Green bag for food, blue bag for bottles and paper', 'Waste segregation reminders', 'Food waste goes in the green bag. Bottles, paper, and cans go in the blue bag. Wrappers go in a separate bag.', 'Everyone', $menro_id, $today, 'Published');

		seed_households($pdo);
	}

	try {
		$server = new PDO("mysql:host=$host;charset=$charset", $username, $password, $attributes);
		$server->exec("CREATE DATABASE IF NOT EXISTS `$db_name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
		$setup = new PDO("mysql:host=$host;dbname=$db_name;charset=$charset", $username, $password, $attributes);
		run_sql_file($setup, __DIR__ . '/database.sql');
		require_once 'dbconn.php';
		require_once 'classes.php';

		$reset = isset($_POST['reset']) && isset($_POST['yes']);
		$user_count = 0;
		try {
			$count_prep = $pdo->query("SELECT COUNT(*) FROM users");
			$user_count = (int) $count_prep->fetchColumn();
		} catch (PDOException $e) {
			$user_count = 0;
		}

		if ($user_count > 0 && !$reset) {
			$already = true;
			$household_count = (int) $pdo->query("SELECT COUNT(*) FROM households")->fetchColumn();
			if ($household_count === 0 && isset($_POST['sample_households'])) {
				seed_households($pdo);
				$household_count = (int) $pdo->query("SELECT COUNT(*) FROM households")->fetchColumn();
				$households_loaded = true;
			}
		} else {
			if ($reset) {
				foreach (['households', 'activities', 'assignments', 'recycling_transactions', 'materials', 'announcements', 'complaints', 'collection_records', 'schedules', 'segregation_guides', 'barangays', 'users'] as $table) {
					$pdo->exec("DROP TABLE IF EXISTS `$table`");
				}
				run_sql_file($pdo, __DIR__ . '/database.sql');
			}
			seed_sample($pdo);
			$done = true;
		}
	} catch (PDOException $e) {
		$error = 'Setup could not finish. ' . $e->getMessage();
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Set up the system</title>
	<link rel="stylesheet" href="assets/style.css">
</head>
<body>
	<div class="setup-page">
		<main class="setup-card">
			<h1>Set up the system</h1>
			<?php if ($error !== '') { ?>
				<div class="alert alert-bad"><?php echo h($error) ?></div>
			<?php } elseif ($done) { ?>
				<div class="alert">The sample community is ready. You can sign in now.</div>
				<a class="btn" href="index.php">Go to sign in</a>
			<?php } elseif ($already) { ?>
				<p class="lead">The system is already set up. Signing in will not erase any records.</p>
				<a class="btn" href="index.php">Go to sign in</a>
				<?php if ($households_loaded) { ?>
					<div class="alert">The sample households were added to the census.</div>
				<?php } elseif ($household_count === 0) { ?>
					<h2>Census</h2>
					<p>The census table is ready and empty. You can add households yourself, or load a few sample households. No other records are touched.</p>
					<form method="post">
						<button name="sample_households" type="submit">Load sample households</button>
					</form>
				<?php } ?>
				<h2>Start over</h2>
				<p>Use this only if you want to erase every record and load the sample community again.</p>
				<form method="post">
					<label class="choice">
						<input type="checkbox" name="yes" value="1" required>
						<span>Yes, erase everything and load the sample again.</span>
					</label>
					<button class="btn-danger" name="reset" type="submit">Erase and load the sample</button>
				</form>
			<?php } ?>
		</main>
	</div>
</body>
</html>
