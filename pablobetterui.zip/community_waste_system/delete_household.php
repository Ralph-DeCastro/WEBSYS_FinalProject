<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';

	require_login();
	require_role(['Administrator', 'MENRO', 'Barangay Personnel']);
	$households = new Households($pdo);
	if (!$households->ready()) {
		deny('The census table is not set up yet. Open install.php once, then try again.', 'dashboard.php');
	}
	$id = (int) ($_POST['id'] ?? $_GET['id'] ?? 0);
	$row = $households->show_data_id($id);
	if (!$row) {
		deny('That household could not be found.', 'census.php');
	}
	if (!owns_record($row['barangay'])) {
		deny('You can only remove households in your own barangay.', 'census.php');
	}
	if (isset($_POST['confirm'])) {
		$households->delete_data($id);
		set_flash('The household was removed.');
		header('Location: census.php');
		exit();
	}

	$page_title = 'Remove a household';
	$nav_current = 'census.php';
	require 'includes/header.php';
?>
	<h1>Remove this household?</h1>
	<p class="lead">The <?php echo h($row['household_head']) ?> household at <?php echo h($row['address']) ?> will be taken out of the census. If the family only moved away, choose Edit and set the status to Inactive instead.</p>
	<form method="post">
		<input type="hidden" name="id" value="<?php echo (int) $id ?>">
		<div class="button-row">
			<button class="btn-danger" name="confirm" type="submit">Yes, remove this household</button>
			<a class="btn btn-secondary" href="edit_household.php?id=<?php echo (int) $id ?>">No, edit it instead</a>
			<a class="btn btn-secondary" href="census.php">No, keep this household</a>
		</div>
	</form>
<?php require 'includes/footer.php'; ?>
