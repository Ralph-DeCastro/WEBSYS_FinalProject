<?php

	class Users {

		function __construct(private PDO $pdo){}

		public function insert_data($full_name, $username, $password, $role, $barangay, $contact_number, $address, $status){
			$sql = "INSERT INTO users(full_name, username, password, role, barangay, contact_number, address, status)
					VALUES(:full_name, :username, :password, :role, :barangay, :contact_number, :address, :status)";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":full_name" => $full_name,
				":username" => $username,
				":password" => $password,
				":role" => $role,
				":barangay" => $barangay,
				":contact_number" => $contact_number,
				":address" => $address,
				":status" => $status,
			]);
		}

		public function show_data(){
			$sql = "SELECT id, full_name, username, role, barangay, contact_number, address, status, created_at
					FROM users
					ORDER BY full_name";
			$prep = $this->pdo->prepare($sql);
			$prep->execute();
			return $prep->fetchAll();
		}

		public function show_data_id($id){
			$sql = "SELECT id, full_name, username, role, barangay, contact_number, address, status, created_at
					FROM users
					WHERE id = :id";
			$prep = $this->pdo->prepare($sql);
			$prep->execute([
				":id" => $id,
			]);
			return $prep->fetch();
		}

		public function find_by_username($username){
			$sql = "SELECT * FROM users WHERE username = :username";
			$prep = $this->pdo->prepare($sql);
			$prep->execute([
				":username" => $username,
			]);
			return $prep->fetch();
		}

		public function show_by_role($role, $barangay = ''){
			$sql = "SELECT id, full_name, username, role, barangay, contact_number, address, status, created_at
					FROM users
					WHERE role = :role";
			$params = [
				":role" => $role,
			];
			if ($barangay !== '') {
				$sql .= " AND barangay = :barangay";
				$params[":barangay"] = $barangay;
			}
			$sql .= " ORDER BY full_name";
			$prep = $this->pdo->prepare($sql);
			$prep->execute($params);
			return $prep->fetchAll();
		}

		public function count_by_role($role){
			$sql = "SELECT COUNT(*) FROM users WHERE role = :role";
			$prep = $this->pdo->prepare($sql);
			$prep->execute([
				":role" => $role,
			]);
			return (int) $prep->fetchColumn();
		}

		public function update_data($id, $full_name, $username, $role, $barangay, $contact_number, $address, $status){
			$sql = "UPDATE users
					SET full_name = :full_name,
						username = :username,
						role = :role,
						barangay = :barangay,
						contact_number = :contact_number,
						address = :address,
						status = :status
					WHERE id = :id";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":full_name" => $full_name,
				":username" => $username,
				":role" => $role,
				":barangay" => $barangay,
				":contact_number" => $contact_number,
				":address" => $address,
				":status" => $status,
				":id" => $id,
			]);
		}

		public function update_password($id, $password){
			$sql = "UPDATE users SET password = :password WHERE id = :id";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":password" => $password,
				":id" => $id,
			]);
		}

		public function delete_data($id){
			$sql = "DELETE FROM users WHERE id = :id";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":id" => $id,
			]);
		}
	}

	class Barangays {

		function __construct(private PDO $pdo){}

		public function insert_data($barangay_name, $zone_name, $notes){
			$sql = "INSERT INTO barangays(barangay_name, zone_name, notes)
					VALUES(:barangay_name, :zone_name, :notes)";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":barangay_name" => $barangay_name,
				":zone_name" => $zone_name,
				":notes" => $notes,
			]);
		}

		public function show_data(){
			$sql = "SELECT * FROM barangays ORDER BY barangay_name, zone_name";
			$prep = $this->pdo->prepare($sql);
			$prep->execute();
			return $prep->fetchAll();
		}

		public function show_data_id($id){
			$sql = "SELECT * FROM barangays WHERE id = :id";
			$prep = $this->pdo->prepare($sql);
			$prep->execute([
				":id" => $id,
			]);
			return $prep->fetch();
		}

		public function show_names(){
			$sql = "SELECT DISTINCT barangay_name FROM barangays ORDER BY barangay_name";
			$prep = $this->pdo->prepare($sql);
			$prep->execute();
			return $prep->fetchAll();
		}

		public function update_data($id, $barangay_name, $zone_name, $notes){
			$sql = "UPDATE barangays
					SET barangay_name = :barangay_name,
						zone_name = :zone_name,
						notes = :notes
					WHERE id = :id";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":barangay_name" => $barangay_name,
				":zone_name" => $zone_name,
				":notes" => $notes,
				":id" => $id,
			]);
		}

		public function delete_data($id){
			$sql = "DELETE FROM barangays WHERE id = :id";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":id" => $id,
			]);
		}
	}

	class Schedules {

		function __construct(private PDO $pdo){}

		public function insert_data($barangay, $zone_name, $waste_category, $personnel_id, $frequency, $collection_day, $collection_time, $notes, $status){
			$sql = "INSERT INTO schedules(barangay, zone_name, waste_category, personnel_id, frequency, collection_day, collection_time, notes, status)
					VALUES(:barangay, :zone_name, :waste_category, :personnel_id, :frequency, :collection_day, :collection_time, :notes, :status)";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":barangay" => $barangay,
				":zone_name" => $zone_name,
				":waste_category" => $waste_category,
				":personnel_id" => $personnel_id,
				":frequency" => $frequency,
				":collection_day" => $collection_day,
				":collection_time" => $collection_time,
				":notes" => $notes,
				":status" => $status,
			]);
		}

		private function select_join(){
			return "SELECT s.*, u.full_name AS personnel_name
					FROM schedules s
					LEFT JOIN users u ON u.id = s.personnel_id";
		}

		public function show_data(){
			$sql = $this->select_join() . " ORDER BY s.barangay, s.zone_name, s.collection_time";
			$prep = $this->pdo->prepare($sql);
			$prep->execute();
			return $prep->fetchAll();
		}

		public function show_data_id($id){
			$sql = $this->select_join() . " WHERE s.id = :id";
			$prep = $this->pdo->prepare($sql);
			$prep->execute([
				":id" => $id,
			]);
			return $prep->fetch();
		}

		public function show_by_barangay($barangay){
			$sql = $this->select_join() . " WHERE s.barangay = :barangay ORDER BY s.zone_name, s.collection_time";
			$prep = $this->pdo->prepare($sql);
			$prep->execute([
				":barangay" => $barangay,
			]);
			return $prep->fetchAll();
		}

		public function show_by_personnel($personnel_id){
			$sql = $this->select_join() . " WHERE s.personnel_id = :personnel_id ORDER BY s.collection_time";
			$prep = $this->pdo->prepare($sql);
			$prep->execute([
				":personnel_id" => $personnel_id,
			]);
			return $prep->fetchAll();
		}

		public function show_today($barangay = '', $personnel_id = 0){
			$sql = $this->select_join() . " WHERE s.status = 'Active' AND s.collection_day LIKE :day";
			$params = [
				":day" => '%' . date('l') . '%',
			];
			if ($barangay !== '') {
				$sql .= " AND s.barangay = :barangay";
				$params[":barangay"] = $barangay;
			}
			if ($personnel_id) {
				$sql .= " AND s.personnel_id = :personnel_id";
				$params[":personnel_id"] = $personnel_id;
			}
			$sql .= " ORDER BY s.collection_time";
			$prep = $this->pdo->prepare($sql);
			$prep->execute($params);
			return $prep->fetchAll();
		}

		public function count_by_personnel($personnel_id){
			$sql = "SELECT COUNT(*) FROM schedules WHERE personnel_id = :personnel_id";
			$prep = $this->pdo->prepare($sql);
			$prep->execute([
				":personnel_id" => $personnel_id,
			]);
			return (int) $prep->fetchColumn();
		}

		public function update_data($id, $barangay, $zone_name, $waste_category, $personnel_id, $frequency, $collection_day, $collection_time, $notes, $status){
			$sql = "UPDATE schedules
					SET barangay = :barangay,
						zone_name = :zone_name,
						waste_category = :waste_category,
						personnel_id = :personnel_id,
						frequency = :frequency,
						collection_day = :collection_day,
						collection_time = :collection_time,
						notes = :notes,
						status = :status
					WHERE id = :id";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":barangay" => $barangay,
				":zone_name" => $zone_name,
				":waste_category" => $waste_category,
				":personnel_id" => $personnel_id,
				":frequency" => $frequency,
				":collection_day" => $collection_day,
				":collection_time" => $collection_time,
				":notes" => $notes,
				":status" => $status,
				":id" => $id,
			]);
		}

		public function delete_data($id){
			$sql = "DELETE FROM schedules WHERE id = :id";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":id" => $id,
			]);
		}
	}

	class Collections {

		function __construct(private PDO $pdo){}

		public function insert_data($schedule_id, $barangay, $zone_name, $waste_category, $collection_date, $status, $personnel_id, $remarks, $recorded_by){
			$sql = "INSERT INTO collection_records(schedule_id, barangay, zone_name, waste_category, collection_date, status, personnel_id, remarks, recorded_by)
					VALUES(:schedule_id, :barangay, :zone_name, :waste_category, :collection_date, :status, :personnel_id, :remarks, :recorded_by)";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":schedule_id" => $schedule_id,
				":barangay" => $barangay,
				":zone_name" => $zone_name,
				":waste_category" => $waste_category,
				":collection_date" => $collection_date,
				":status" => $status,
				":personnel_id" => $personnel_id,
				":remarks" => $remarks,
				":recorded_by" => $recorded_by,
			]);
		}

		private function select_join(){
			return "SELECT c.*, u.full_name AS personnel_name
					FROM collection_records c
					LEFT JOIN users u ON u.id = c.personnel_id";
		}

		public function show_filtered($barangay = '', $status = '', $personnel_id = 0){
			$sql = $this->select_join() . " WHERE 1 = 1";
			$params = [];
			if ($barangay !== '') {
				$sql .= " AND c.barangay = :barangay";
				$params[":barangay"] = $barangay;
			}
			if ($status !== '') {
				$sql .= " AND c.status = :status";
				$params[":status"] = $status;
			}
			if ($personnel_id) {
				$sql .= " AND c.personnel_id = :personnel_id";
				$params[":personnel_id"] = $personnel_id;
			}
			$sql .= " ORDER BY c.collection_date DESC, c.id DESC";
			$prep = $this->pdo->prepare($sql);
			$prep->execute($params);
			return $prep->fetchAll();
		}

		public function show_data(){
			return $this->show_filtered();
		}

		public function show_data_id($id){
			$sql = $this->select_join() . " WHERE c.id = :id";
			$prep = $this->pdo->prepare($sql);
			$prep->execute([
				":id" => $id,
			]);
			return $prep->fetch();
		}

		public function show_recent_missed($barangay = '', $limit = 5){
			$sql = $this->select_join() . " WHERE c.status = 'Missed'";
			$params = [];
			if ($barangay !== '') {
				$sql .= " AND c.barangay = :barangay";
				$params[":barangay"] = $barangay;
			}
			$sql .= " ORDER BY c.collection_date DESC, c.id DESC LIMIT :limit";
			$prep = $this->pdo->prepare($sql);
			foreach ($params as $key => $value) {
				$prep->bindValue($key, $value);
			}
			$prep->bindValue(':limit', (int) $limit, PDO::PARAM_INT);
			$prep->execute();
			return $prep->fetchAll();
		}

		public function update_data($id, $collection_date, $status, $personnel_id, $remarks){
			$sql = "UPDATE collection_records
					SET collection_date = :collection_date,
						status = :status,
						personnel_id = :personnel_id,
						remarks = :remarks
					WHERE id = :id";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":collection_date" => $collection_date,
				":status" => $status,
				":personnel_id" => $personnel_id,
				":remarks" => $remarks,
				":id" => $id,
			]);
		}

		public function delete_data($id){
			$sql = "DELETE FROM collection_records WHERE id = :id";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":id" => $id,
			]);
		}
	}

	class Complaints {

		function __construct(private PDO $pdo){}

		public function insert_data($resident_id, $resident_name, $complaint_type, $barangay, $location, $description, $photo){
			$sql = "INSERT INTO complaints(resident_id, resident_name, complaint_type, barangay, location, description, photo, status)
					VALUES(:resident_id, :resident_name, :complaint_type, :barangay, :location, :description, :photo, 'New')";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":resident_id" => $resident_id,
				":resident_name" => $resident_name,
				":complaint_type" => $complaint_type,
				":barangay" => $barangay,
				":location" => $location,
				":description" => $description,
				":photo" => $photo,
			]);
		}

		public function show_filtered($barangay = '', $status = '', $resident_id = 0){
			$sql = "SELECT * FROM complaints WHERE 1 = 1";
			$params = [];
			if ($barangay !== '') {
				$sql .= " AND barangay = :barangay";
				$params[":barangay"] = $barangay;
			}
			if ($status !== '') {
				$sql .= " AND status = :status";
				$params[":status"] = $status;
			}
			if ($resident_id) {
				$sql .= " AND resident_id = :resident_id";
				$params[":resident_id"] = $resident_id;
			}
			$sql .= " ORDER BY created_at DESC, id DESC";
			$prep = $this->pdo->prepare($sql);
			$prep->execute($params);
			return $prep->fetchAll();
		}

		public function show_data(){
			return $this->show_filtered();
		}

		public function show_data_id($id){
			$sql = "SELECT * FROM complaints WHERE id = :id";
			$prep = $this->pdo->prepare($sql);
			$prep->execute([
				":id" => $id,
			]);
			return $prep->fetch();
		}

		public function show_recent($barangay = '', $limit = 5){
			$sql = "SELECT * FROM complaints WHERE 1 = 1";
			$params = [];
			if ($barangay !== '') {
				$sql .= " AND barangay = :barangay";
				$params[":barangay"] = $barangay;
			}
			$sql .= " ORDER BY created_at DESC, id DESC LIMIT :limit";
			$prep = $this->pdo->prepare($sql);
			foreach ($params as $key => $value) {
				$prep->bindValue($key, $value);
			}
			$prep->bindValue(':limit', (int) $limit, PDO::PARAM_INT);
			$prep->execute();
			return $prep->fetchAll();
		}

		public function update_status($id, $status, $response_notes, $handled_by){
			$sql = "UPDATE complaints
					SET status = :status,
						response_notes = :response_notes,
						handled_by = :handled_by,
						updated_at = NOW()
					WHERE id = :id";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":status" => $status,
				":response_notes" => $response_notes,
				":handled_by" => $handled_by,
				":id" => $id,
			]);
		}

		public function delete_data($id){
			$sql = "DELETE FROM complaints WHERE id = :id";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":id" => $id,
			]);
		}
	}

	class Guides {

		function __construct(private PDO $pdo){}

		public function insert_data($waste_type, $description, $examples, $how_to_prepare, $color_label){
			$sql = "INSERT INTO segregation_guides(waste_type, description, examples, how_to_prepare, color_label)
					VALUES(:waste_type, :description, :examples, :how_to_prepare, :color_label)";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":waste_type" => $waste_type,
				":description" => $description,
				":examples" => $examples,
				":how_to_prepare" => $how_to_prepare,
				":color_label" => $color_label,
			]);
		}

		public function show_data(){
			$sql = "SELECT * FROM segregation_guides ORDER BY id";
			$prep = $this->pdo->prepare($sql);
			$prep->execute();
			return $prep->fetchAll();
		}

		public function show_data_id($id){
			$sql = "SELECT * FROM segregation_guides WHERE id = :id";
			$prep = $this->pdo->prepare($sql);
			$prep->execute([
				":id" => $id,
			]);
			return $prep->fetch();
		}

		public function update_data($id, $waste_type, $description, $examples, $how_to_prepare, $color_label){
			$sql = "UPDATE segregation_guides
					SET waste_type = :waste_type,
						description = :description,
						examples = :examples,
						how_to_prepare = :how_to_prepare,
						color_label = :color_label
					WHERE id = :id";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":waste_type" => $waste_type,
				":description" => $description,
				":examples" => $examples,
				":how_to_prepare" => $how_to_prepare,
				":color_label" => $color_label,
				":id" => $id,
			]);
		}

		public function delete_data($id){
			$sql = "DELETE FROM segregation_guides WHERE id = :id";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":id" => $id,
			]);
		}
	}

	class Materials {

		function __construct(private PDO $pdo){}

		public function insert_data($material_name, $category, $unit, $price_per_kg, $status){
			$sql = "INSERT INTO materials(material_name, category, unit, price_per_kg, status)
					VALUES(:material_name, :category, :unit, :price_per_kg, :status)";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":material_name" => $material_name,
				":category" => $category,
				":unit" => $unit,
				":price_per_kg" => $price_per_kg,
				":status" => $status,
			]);
		}

		public function show_data(){
			$sql = "SELECT * FROM materials ORDER BY material_name";
			$prep = $this->pdo->prepare($sql);
			$prep->execute();
			return $prep->fetchAll();
		}

		public function show_active(){
			$sql = "SELECT * FROM materials WHERE status = 'Active' ORDER BY material_name";
			$prep = $this->pdo->prepare($sql);
			$prep->execute();
			return $prep->fetchAll();
		}

		public function show_data_id($id){
			$sql = "SELECT * FROM materials WHERE id = :id";
			$prep = $this->pdo->prepare($sql);
			$prep->execute([
				":id" => $id,
			]);
			return $prep->fetch();
		}

		public function update_data($id, $material_name, $category, $unit, $price_per_kg, $status){
			$sql = "UPDATE materials
					SET material_name = :material_name,
						category = :category,
						unit = :unit,
						price_per_kg = :price_per_kg,
						status = :status
					WHERE id = :id";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":material_name" => $material_name,
				":category" => $category,
				":unit" => $unit,
				":price_per_kg" => $price_per_kg,
				":status" => $status,
				":id" => $id,
			]);
		}

		public function delete_data($id){
			$sql = "DELETE FROM materials WHERE id = :id";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":id" => $id,
			]);
		}
	}

	class Transactions {

		function __construct(private PDO $pdo){}

		public function insert_data($material_id, $transaction_type, $person_name, $person_user_id, $weight_kg, $amount, $record_date, $notes, $recorded_by){
			$sql = "INSERT INTO recycling_transactions(material_id, transaction_type, person_name, person_user_id, weight_kg, amount, record_date, notes, recorded_by)
					VALUES(:material_id, :transaction_type, :person_name, :person_user_id, :weight_kg, :amount, :record_date, :notes, :recorded_by)";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":material_id" => $material_id,
				":transaction_type" => $transaction_type,
				":person_name" => $person_name,
				":person_user_id" => $person_user_id,
				":weight_kg" => $weight_kg,
				":amount" => $amount,
				":record_date" => $record_date,
				":notes" => $notes,
				":recorded_by" => $recorded_by,
			]);
		}

		private function select_join(){
			return "SELECT t.*, m.material_name, m.unit, u.full_name AS recorded_name
					FROM recycling_transactions t
					LEFT JOIN materials m ON m.id = t.material_id
					LEFT JOIN users u ON u.id = t.recorded_by";
		}

		public function show_data(){
			$sql = $this->select_join() . " ORDER BY t.record_date DESC, t.id DESC";
			$prep = $this->pdo->prepare($sql);
			$prep->execute();
			return $prep->fetchAll();
		}

		public function show_by_user($person_user_id){
			$sql = $this->select_join() . " WHERE t.person_user_id = :person_user_id ORDER BY t.record_date DESC, t.id DESC";
			$prep = $this->pdo->prepare($sql);
			$prep->execute([
				":person_user_id" => $person_user_id,
			]);
			return $prep->fetchAll();
		}

		public function show_data_id($id){
			$sql = $this->select_join() . " WHERE t.id = :id";
			$prep = $this->pdo->prepare($sql);
			$prep->execute([
				":id" => $id,
			]);
			return $prep->fetch();
		}

		public function count_by_material($material_id){
			$sql = "SELECT COUNT(*) FROM recycling_transactions WHERE material_id = :material_id";
			$prep = $this->pdo->prepare($sql);
			$prep->execute([
				":material_id" => $material_id,
			]);
			return (int) $prep->fetchColumn();
		}

		public function update_data($id, $material_id, $transaction_type, $person_name, $person_user_id, $weight_kg, $amount, $record_date, $notes){
			$sql = "UPDATE recycling_transactions
					SET material_id = :material_id,
						transaction_type = :transaction_type,
						person_name = :person_name,
						person_user_id = :person_user_id,
						weight_kg = :weight_kg,
						amount = :amount,
						record_date = :record_date,
						notes = :notes
					WHERE id = :id";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":material_id" => $material_id,
				":transaction_type" => $transaction_type,
				":person_name" => $person_name,
				":person_user_id" => $person_user_id,
				":weight_kg" => $weight_kg,
				":amount" => $amount,
				":record_date" => $record_date,
				":notes" => $notes,
				":id" => $id,
			]);
		}

		public function delete_data($id){
			$sql = "DELETE FROM recycling_transactions WHERE id = :id";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":id" => $id,
			]);
		}
	}

	class Assignments {

		function __construct(private PDO $pdo){}

		public function insert_data($personnel_id, $schedule_id, $assignment_date, $shift_label, $status, $notes){
			$sql = "INSERT INTO assignments(personnel_id, schedule_id, assignment_date, shift_label, status, notes)
					VALUES(:personnel_id, :schedule_id, :assignment_date, :shift_label, :status, :notes)";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":personnel_id" => $personnel_id,
				":schedule_id" => $schedule_id,
				":assignment_date" => $assignment_date,
				":shift_label" => $shift_label,
				":status" => $status,
				":notes" => $notes,
			]);
		}

		private function select_join(){
			return "SELECT a.*, u.full_name AS personnel_name, u.barangay AS personnel_barangay,
						s.barangay, s.zone_name, s.waste_category, s.collection_day, s.collection_time
					FROM assignments a
					LEFT JOIN users u ON u.id = a.personnel_id
					LEFT JOIN schedules s ON s.id = a.schedule_id";
		}

		public function show_filtered($barangay = '', $personnel_id = 0){
			$sql = $this->select_join() . " WHERE 1 = 1";
			$params = [];
			if ($barangay !== '') {
				$sql .= " AND u.barangay = :barangay";
				$params[":barangay"] = $barangay;
			}
			if ($personnel_id) {
				$sql .= " AND a.personnel_id = :personnel_id";
				$params[":personnel_id"] = $personnel_id;
			}
			$sql .= " ORDER BY a.assignment_date DESC, a.id DESC";
			$prep = $this->pdo->prepare($sql);
			$prep->execute($params);
			return $prep->fetchAll();
		}

		public function show_data(){
			return $this->show_filtered();
		}

		public function show_data_id($id){
			$sql = $this->select_join() . " WHERE a.id = :id";
			$prep = $this->pdo->prepare($sql);
			$prep->execute([
				":id" => $id,
			]);
			return $prep->fetch();
		}

		public function show_for_day($personnel_id, $assignment_date){
			$sql = $this->select_join() . " WHERE a.personnel_id = :personnel_id AND a.assignment_date = :assignment_date ORDER BY s.collection_time";
			$prep = $this->pdo->prepare($sql);
			$prep->execute([
				":personnel_id" => $personnel_id,
				":assignment_date" => $assignment_date,
			]);
			return $prep->fetchAll();
		}

		public function update_data($id, $personnel_id, $schedule_id, $assignment_date, $shift_label, $status, $notes){
			$sql = "UPDATE assignments
					SET personnel_id = :personnel_id,
						schedule_id = :schedule_id,
						assignment_date = :assignment_date,
						shift_label = :shift_label,
						status = :status,
						notes = :notes
					WHERE id = :id";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":personnel_id" => $personnel_id,
				":schedule_id" => $schedule_id,
				":assignment_date" => $assignment_date,
				":shift_label" => $shift_label,
				":status" => $status,
				":notes" => $notes,
				":id" => $id,
			]);
		}

		public function delete_data($id){
			$sql = "DELETE FROM assignments WHERE id = :id";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":id" => $id,
			]);
		}
	}

	class Activities {

		function __construct(private PDO $pdo){}

		public function insert_data($personnel_id, $activity_date, $task_done, $status, $notes){
			$sql = "INSERT INTO activities(personnel_id, activity_date, task_done, status, notes)
					VALUES(:personnel_id, :activity_date, :task_done, :status, :notes)";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":personnel_id" => $personnel_id,
				":activity_date" => $activity_date,
				":task_done" => $task_done,
				":status" => $status,
				":notes" => $notes,
			]);
		}

		private function select_join(){
			return "SELECT a.*, u.full_name AS personnel_name, u.barangay AS personnel_barangay
					FROM activities a
					LEFT JOIN users u ON u.id = a.personnel_id";
		}

		public function show_filtered($barangay = '', $personnel_id = 0){
			$sql = $this->select_join() . " WHERE 1 = 1";
			$params = [];
			if ($barangay !== '') {
				$sql .= " AND u.barangay = :barangay";
				$params[":barangay"] = $barangay;
			}
			if ($personnel_id) {
				$sql .= " AND a.personnel_id = :personnel_id";
				$params[":personnel_id"] = $personnel_id;
			}
			$sql .= " ORDER BY a.activity_date DESC, a.id DESC";
			$prep = $this->pdo->prepare($sql);
			$prep->execute($params);
			return $prep->fetchAll();
		}

		public function show_data(){
			return $this->show_filtered();
		}

		public function show_data_id($id){
			$sql = $this->select_join() . " WHERE a.id = :id";
			$prep = $this->pdo->prepare($sql);
			$prep->execute([
				":id" => $id,
			]);
			return $prep->fetch();
		}

		public function update_data($id, $activity_date, $task_done, $status, $notes){
			$sql = "UPDATE activities
					SET activity_date = :activity_date,
						task_done = :task_done,
						status = :status,
						notes = :notes
					WHERE id = :id";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":activity_date" => $activity_date,
				":task_done" => $task_done,
				":status" => $status,
				":notes" => $notes,
				":id" => $id,
			]);
		}

		public function delete_data($id){
			$sql = "DELETE FROM activities WHERE id = :id";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":id" => $id,
			]);
		}
	}

	class Announcements {

		function __construct(private PDO $pdo){}

		public function insert_data($title, $category, $body, $audience, $posted_by, $publish_date, $status){
			$sql = "INSERT INTO announcements(title, category, body, audience, posted_by, publish_date, status)
					VALUES(:title, :category, :body, :audience, :posted_by, :publish_date, :status)";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":title" => $title,
				":category" => $category,
				":body" => $body,
				":audience" => $audience,
				":posted_by" => $posted_by,
				":publish_date" => $publish_date,
				":status" => $status,
			]);
		}

		private function select_join(){
			return "SELECT a.*, u.full_name AS author_name
					FROM announcements a
					LEFT JOIN users u ON u.id = a.posted_by";
		}

		public function show_data(){
			$sql = $this->select_join() . " ORDER BY a.publish_date DESC, a.id DESC";
			$prep = $this->pdo->prepare($sql);
			$prep->execute();
			return $prep->fetchAll();
		}

		public function show_for_role($role){
			$audiences = ['Everyone'];
			if ($role === 'Resident') {
				$audiences[] = 'Residents';
			} elseif ($role === 'Collection Personnel') {
				$audiences[] = 'Collection Personnel';
			} elseif ($role === 'Barangay Personnel') {
				$audiences[] = 'Barangay Staff';
			} else {
				$audiences[] = 'Residents';
				$audiences[] = 'Collection Personnel';
				$audiences[] = 'Barangay Staff';
			}
			$placeholders = [];
			$params = [];
			foreach ($audiences as $index => $audience) {
				$key = ':audience' . $index;
				$placeholders[] = $key;
				$params[$key] = $audience;
			}
			$sql = $this->select_join() . " WHERE a.status = 'Published' AND a.audience IN (" . implode(', ', $placeholders) . ") ORDER BY a.publish_date DESC, a.id DESC";
			$prep = $this->pdo->prepare($sql);
			$prep->execute($params);
			return $prep->fetchAll();
		}

		public function show_data_id($id){
			$sql = $this->select_join() . " WHERE a.id = :id";
			$prep = $this->pdo->prepare($sql);
			$prep->execute([
				":id" => $id,
			]);
			return $prep->fetch();
		}

		public function update_data($id, $title, $category, $body, $audience, $publish_date, $status){
			$sql = "UPDATE announcements
					SET title = :title,
						category = :category,
						body = :body,
						audience = :audience,
						publish_date = :publish_date,
						status = :status
					WHERE id = :id";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":title" => $title,
				":category" => $category,
				":body" => $body,
				":audience" => $audience,
				":publish_date" => $publish_date,
				":status" => $status,
				":id" => $id,
			]);
		}

		public function delete_data($id){
			$sql = "DELETE FROM announcements WHERE id = :id";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":id" => $id,
			]);
		}
	}

	class Households {

		function __construct(private PDO $pdo){}

		public function ready(){
			$prep = $this->pdo->query("SHOW TABLES LIKE 'households'");
			return (bool) $prep->fetchColumn();
		}

		public function insert_data($barangay, $zone_name, $household_head, $address, $contact_number, $member_count, $household_type, $pickup_point, $needs_biohazard, $resident_user_id, $census_date, $status, $recorded_by){
			$sql = "INSERT INTO households(barangay, zone_name, household_head, address, contact_number, member_count, household_type, pickup_point, needs_biohazard, resident_user_id, census_date, status, recorded_by)
					VALUES(:barangay, :zone_name, :household_head, :address, :contact_number, :member_count, :household_type, :pickup_point, :needs_biohazard, :resident_user_id, :census_date, :status, :recorded_by)";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":barangay" => $barangay,
				":zone_name" => $zone_name,
				":household_head" => $household_head,
				":address" => $address,
				":contact_number" => $contact_number,
				":member_count" => $member_count,
				":household_type" => $household_type,
				":pickup_point" => $pickup_point,
				":needs_biohazard" => $needs_biohazard,
				":resident_user_id" => $resident_user_id,
				":census_date" => $census_date,
				":status" => $status,
				":recorded_by" => $recorded_by,
			]);
		}

		private function select_join(){
			return "SELECT h.*, u.full_name AS account_name
					FROM households h
					LEFT JOIN users u ON u.id = h.resident_user_id";
		}

		public function show_filtered($barangay = '', $status = '', $biohazard = false, $search = ''){
			$where = [];
			$params = [];
			if ($barangay !== '') {
				$where[] = "h.barangay = :barangay";
				$params[":barangay"] = $barangay;
			}
			if ($status !== '') {
				$where[] = "h.status = :status";
				$params[":status"] = $status;
			}
			if ($biohazard) {
				$where[] = "h.needs_biohazard = 1";
			}
			if ($search !== '') {
				$where[] = "(h.household_head LIKE :search_name OR h.address LIKE :search_address)";
				$like = '%' . addcslashes($search, '%_\\') . '%';
				$params[":search_name"] = $like;
				$params[":search_address"] = $like;
			}
			$sql = $this->select_join();
			if ($where) {
				$sql .= " WHERE " . implode(" AND ", $where);
			}
			$sql .= " ORDER BY h.barangay, h.zone_name, h.address";
			$prep = $this->pdo->prepare($sql);
			$prep->execute($params);
			return $prep->fetchAll();
		}

		public function show_data_id($id){
			$sql = $this->select_join() . " WHERE h.id = :id";
			$prep = $this->pdo->prepare($sql);
			$prep->execute([
				":id" => $id,
			]);
			return $prep->fetch();
		}

		public function duplicate_exists($barangay, $zone_name, $address, $household_head, $exclude_id = 0){
			$sql = "SELECT COUNT(*) FROM households
					WHERE barangay = :barangay AND zone_name = :zone_name AND address = :address
						AND household_head = :household_head AND id <> :id";
			$prep = $this->pdo->prepare($sql);
			$prep->execute([
				":barangay" => $barangay,
				":zone_name" => $zone_name,
				":address" => $address,
				":household_head" => $household_head,
				":id" => $exclude_id,
			]);
			return (int) $prep->fetchColumn() > 0;
		}

		public function totals($barangay = ''){
			$sql = "SELECT SUM(status = 'Active') AS households,
						COALESCE(SUM(CASE WHEN status = 'Active' THEN member_count END), 0) AS people,
						COALESCE(SUM(CASE WHEN status = 'Active' THEN needs_biohazard END), 0) AS biohazard,
						SUM(status = 'Inactive') AS inactive
					FROM households";
			$params = [];
			if ($barangay !== '') {
				$sql .= " WHERE barangay = :barangay";
				$params[":barangay"] = $barangay;
			}
			$prep = $this->pdo->prepare($sql);
			$prep->execute($params);
			$row = $prep->fetch();
			return [
				'households' => (int) $row['households'],
				'people' => (int) $row['people'],
				'biohazard' => (int) $row['biohazard'],
				'inactive' => (int) $row['inactive'],
			];
		}

		public function by_area($barangay = ''){
			$sql = "SELECT h.barangay, h.zone_name,
						COUNT(*) AS households,
						SUM(h.member_count) AS people,
						SUM(h.needs_biohazard) AS biohazard,
						SUM(CASE WHEN EXISTS(
							SELECT 1 FROM schedules s
							WHERE s.barangay = h.barangay AND s.zone_name = h.zone_name AND s.status = 'Active'
						) THEN 0 ELSE 1 END) AS no_schedule
					FROM households h
					WHERE h.status = 'Active'";
			$params = [];
			if ($barangay !== '') {
				$sql .= " AND h.barangay = :barangay";
				$params[":barangay"] = $barangay;
			}
			$sql .= " GROUP BY h.barangay, h.zone_name ORDER BY h.barangay, h.zone_name";
			$prep = $this->pdo->prepare($sql);
			$prep->execute($params);
			return $prep->fetchAll();
		}

		public function update_data($id, $barangay, $zone_name, $household_head, $address, $contact_number, $member_count, $household_type, $pickup_point, $needs_biohazard, $resident_user_id, $census_date, $status){
			$sql = "UPDATE households
					SET barangay = :barangay,
						zone_name = :zone_name,
						household_head = :household_head,
						address = :address,
						contact_number = :contact_number,
						member_count = :member_count,
						household_type = :household_type,
						pickup_point = :pickup_point,
						needs_biohazard = :needs_biohazard,
						resident_user_id = :resident_user_id,
						census_date = :census_date,
						status = :status,
						updated_at = NOW()
					WHERE id = :id";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":barangay" => $barangay,
				":zone_name" => $zone_name,
				":household_head" => $household_head,
				":address" => $address,
				":contact_number" => $contact_number,
				":member_count" => $member_count,
				":household_type" => $household_type,
				":pickup_point" => $pickup_point,
				":needs_biohazard" => $needs_biohazard,
				":resident_user_id" => $resident_user_id,
				":census_date" => $census_date,
				":status" => $status,
				":id" => $id,
			]);
		}

		public function delete_data($id){
			$sql = "DELETE FROM households WHERE id = :id";
			$prep = $this->pdo->prepare($sql);
			return $prep->execute([
				":id" => $id,
			]);
		}
	}

	class Reports {

		function __construct(private PDO $pdo){}

		private function one($sql, $params = []){
			$prep = $this->pdo->prepare($sql);
			$prep->execute($params);
			return $prep->fetchColumn();
		}

		private function household_count($barangay = ''){
			try {
				if ($barangay === '') {
					return (int) $this->one("SELECT COUNT(*) FROM households WHERE status = 'Active'");
				}
				return (int) $this->one("SELECT COUNT(*) FROM households WHERE status = 'Active' AND barangay = :barangay", [":barangay" => $barangay]);
			} catch (PDOException $e) {
				return null;
			}
		}

		public function census_coverage(){
			$sql = "SELECT b.barangay_name AS barangay,
						COALESCE(h.households, 0) AS households,
						COALESCE(h.people, 0) AS people,
						COALESCE(h.biohazard, 0) AS biohazard,
						COALESCE(h.no_schedule, 0) AS no_schedule,
						COALESCE(c.open_complaints, 0) AS open_complaints
					FROM (SELECT DISTINCT barangay_name FROM barangays) b
					LEFT JOIN (
						SELECT x.barangay,
							COUNT(*) AS households,
							SUM(x.member_count) AS people,
							SUM(x.needs_biohazard) AS biohazard,
							SUM(CASE WHEN EXISTS(
								SELECT 1 FROM schedules s
								WHERE s.barangay = x.barangay AND s.zone_name = x.zone_name AND s.status = 'Active'
							) THEN 0 ELSE 1 END) AS no_schedule
						FROM households x
						WHERE x.status = 'Active'
						GROUP BY x.barangay
					) h ON h.barangay = b.barangay_name
					LEFT JOIN (
						SELECT barangay, COUNT(*) AS open_complaints
						FROM complaints
						WHERE status <> 'Resolved'
						GROUP BY barangay
					) c ON c.barangay = b.barangay_name
					ORDER BY b.barangay_name";
			$prep = $this->pdo->prepare($sql);
			$prep->execute();
			return $prep->fetchAll();
		}

		public function dashboard_counts($role, $user_id, $barangay){
			$month = date('Y-m-01');
			if ($role === 'Resident') {
				return [
					'schedules' => (int) $this->one("SELECT COUNT(*) FROM schedules WHERE barangay = :barangay AND status = 'Active'", [":barangay" => $barangay]),
					'open_reports' => (int) $this->one("SELECT COUNT(*) FROM complaints WHERE resident_id = :id AND status <> 'Resolved'", [":id" => $user_id]),
					'my_reports' => (int) $this->one("SELECT COUNT(*) FROM complaints WHERE resident_id = :id", [":id" => $user_id]),
					'news' => (int) $this->one("SELECT COUNT(*) FROM announcements WHERE status = 'Published'"),
				];
			}
			if ($role === 'Collection Personnel') {
				return [
					'routes' => (int) $this->one("SELECT COUNT(*) FROM schedules WHERE personnel_id = :id AND status = 'Active'", [":id" => $user_id]),
					'done_month' => (int) $this->one("SELECT COUNT(*) FROM collection_records WHERE personnel_id = :id AND status = 'Completed' AND collection_date >= :month", [":id" => $user_id, ":month" => $month]),
					'missed_month' => (int) $this->one("SELECT COUNT(*) FROM collection_records WHERE personnel_id = :id AND status = 'Missed' AND collection_date >= :month", [":id" => $user_id, ":month" => $month]),
				];
			}
			if ($role === 'Barangay Personnel') {
				return [
					'schedules' => (int) $this->one("SELECT COUNT(*) FROM schedules WHERE barangay = :barangay AND status = 'Active'", [":barangay" => $barangay]),
					'missed' => (int) $this->one("SELECT COUNT(*) FROM collection_records WHERE barangay = :barangay AND status = 'Missed'", [":barangay" => $barangay]),
					'open_complaints' => (int) $this->one("SELECT COUNT(*) FROM complaints WHERE barangay = :barangay AND status <> 'Resolved'", [":barangay" => $barangay]),
					'personnel' => (int) $this->one("SELECT COUNT(*) FROM users WHERE role = 'Collection Personnel' AND barangay = :barangay AND status = 'Active'", [":barangay" => $barangay]),
					'households' => $this->household_count($barangay),
				];
			}
			return [
				'schedules' => (int) $this->one("SELECT COUNT(*) FROM schedules WHERE status = 'Active'"),
				'missed' => (int) $this->one("SELECT COUNT(*) FROM collection_records WHERE status = 'Missed'"),
				'open_complaints' => (int) $this->one("SELECT COUNT(*) FROM complaints WHERE status <> 'Resolved'"),
				'weight' => (float) $this->one("SELECT COALESCE(SUM(weight_kg), 0) FROM recycling_transactions WHERE record_date >= :month", [":month" => $month]),
				'households' => $this->household_count(),
			];
		}

		public function completion_by_barangay(){
			$sql = "SELECT barangay,
						SUM(status = 'Completed') AS completed_count,
						SUM(status = 'Missed') AS missed_count,
						COUNT(*) AS total_count
					FROM collection_records
					GROUP BY barangay
					ORDER BY barangay";
			$prep = $this->pdo->prepare($sql);
			$prep->execute();
			return $prep->fetchAll();
		}

		public function missed_list(){
			$sql = "SELECT c.*, u.full_name AS personnel_name
					FROM collection_records c
					LEFT JOIN users u ON u.id = c.personnel_id
					WHERE c.status = 'Missed'
					ORDER BY c.collection_date DESC, c.id DESC";
			$prep = $this->pdo->prepare($sql);
			$prep->execute();
			return $prep->fetchAll();
		}

		public function complaints_by_type(){
			$sql = "SELECT complaint_type,
						COUNT(*) AS total_count,
						SUM(status = 'New') AS new_count,
						SUM(status = 'In Progress') AS progress_count,
						SUM(status = 'Resolved') AS resolved_count
					FROM complaints
					GROUP BY complaint_type
					ORDER BY complaint_type";
			$prep = $this->pdo->prepare($sql);
			$prep->execute();
			return $prep->fetchAll();
		}

		public function complaint_rows(){
			$sql = "SELECT * FROM complaints ORDER BY created_at DESC, id DESC";
			$prep = $this->pdo->prepare($sql);
			$prep->execute();
			return $prep->fetchAll();
		}

		public function material_summary(){
			$sql = "SELECT m.material_name,
						COALESCE(SUM(t.weight_kg), 0) AS total_weight,
						COALESCE(SUM(t.amount), 0) AS total_amount,
						COUNT(t.id) AS trip_count
					FROM materials m
					LEFT JOIN recycling_transactions t ON t.material_id = m.id
					GROUP BY m.id, m.material_name
					ORDER BY m.material_name";
			$prep = $this->pdo->prepare($sql);
			$prep->execute();
			return $prep->fetchAll();
		}

		/* ---------- Statistics for the home page ---------- */

		private function rows($sql, $params = []){
			$prep = $this->pdo->prepare($sql);
			$prep->execute($params);
			return $prep->fetchAll();
		}

		private function trip_scope($barangay, $personnel_id, &$params, $alias = ''){
			$p = $alias === '' ? '' : $alias . '.';
			$sql = '';
			if ($barangay !== '') {
				$sql .= " AND {$p}barangay = :scope_barangay";
				$params[':scope_barangay'] = $barangay;
			}
			if ((int) $personnel_id > 0) {
				$sql .= " AND {$p}personnel_id = :scope_personnel";
				$params[':scope_personnel'] = (int) $personnel_id;
			}
			return $sql;
		}

		private function complaint_scope($barangay, $resident_id, &$params){
			if ((int) $resident_id > 0) {
				$params[':scope_resident'] = (int) $resident_id;
				return ' AND resident_id = :scope_resident';
			}
			if ($barangay !== '') {
				$params[':scope_barangay'] = $barangay;
				return ' AND barangay = :scope_barangay';
			}
			return '';
		}

		public function daily_trend($days, $barangay = '', $personnel_id = 0){
			$days = max(1, min(60, (int) $days));
			$params = [':from' => date('Y-m-d', strtotime('-' . ($days - 1) . ' days'))];
			$sql = "SELECT collection_date,
						SUM(status = 'Completed') AS done,
						SUM(status = 'Missed') AS missed
					FROM collection_records
					WHERE collection_date >= :from" . $this->trip_scope($barangay, $personnel_id, $params) . "
					GROUP BY collection_date";
			$found = [];
			foreach ($this->rows($sql, $params) as $row) {
				$found[$row['collection_date']] = $row;
			}
			$out = [];
			for ($i = $days - 1; $i >= 0; $i--) {
				$day = date('Y-m-d', strtotime('-' . $i . ' days'));
				$out[] = [
					'date' => $day,
					'done' => isset($found[$day]) ? (int) $found[$day]['done'] : 0,
					'missed' => isset($found[$day]) ? (int) $found[$day]['missed'] : 0,
				];
			}
			return $out;
		}

		public function area_completion($barangay = '', $personnel_id = 0){
			$params = [
				':c1' => date('Y-m-d', strtotime('-29 days')),
				':c2' => date('Y-m-d', strtotime('-29 days')),
				':p1' => date('Y-m-d', strtotime('-59 days')),
				':p2' => date('Y-m-d', strtotime('-29 days')),
				':p3' => date('Y-m-d', strtotime('-59 days')),
				':p4' => date('Y-m-d', strtotime('-29 days')),
			];
			$sql = "SELECT barangay,
						COUNT(*) AS total_count,
						SUM(status = 'Completed') AS done_count,
						SUM(status = 'Missed') AS missed_count,
						SUM(CASE WHEN collection_date >= :c1 THEN 1 ELSE 0 END) AS recent_total,
						SUM(CASE WHEN collection_date >= :c2 AND status = 'Completed' THEN 1 ELSE 0 END) AS recent_done,
						SUM(CASE WHEN collection_date >= :p1 AND collection_date < :p2 THEN 1 ELSE 0 END) AS prev_total,
						SUM(CASE WHEN collection_date >= :p3 AND collection_date < :p4 AND status = 'Completed' THEN 1 ELSE 0 END) AS prev_done
					FROM collection_records
					WHERE 1 = 1" . $this->trip_scope($barangay, $personnel_id, $params) . "
					GROUP BY barangay
					ORDER BY total_count DESC, barangay";
			$out = [];
			foreach ($this->rows($sql, $params) as $row) {
				$total = (int) $row['total_count'];
				$rate = $total > 0 ? (int) $row['done_count'] / $total * 100 : 0;
				$change = null;
				if ((int) $row['recent_total'] > 0 && (int) $row['prev_total'] > 0) {
					$change = ((int) $row['recent_done'] / (int) $row['recent_total'] * 100) - ((int) $row['prev_done'] / (int) $row['prev_total'] * 100);
				}
				$out[] = [
					'barangay' => $row['barangay'],
					'trips' => $total,
					'missed' => (int) $row['missed_count'],
					'rate' => $rate,
					'change' => $change,
				];
			}
			return $out;
		}

		public function category_totals($barangay = '', $personnel_id = 0){
			$params = [];
			$sql = "SELECT waste_category,
						COUNT(*) AS total_count,
						SUM(status = 'Completed') AS done_count,
						SUM(status = 'Missed') AS missed_count
					FROM collection_records
					WHERE 1 = 1" . $this->trip_scope($barangay, $personnel_id, $params) . "
					GROUP BY waste_category
					ORDER BY total_count DESC, waste_category";
			return $this->rows($sql, $params);
		}

		public function complaint_status($barangay = '', $resident_id = 0){
			$params = [];
			$sql = "SELECT status, COUNT(*) AS n FROM complaints WHERE 1 = 1" . $this->complaint_scope($barangay, $resident_id, $params) . " GROUP BY status";
			$out = ['New' => 0, 'In Progress' => 0, 'Resolved' => 0];
			foreach ($this->rows($sql, $params) as $row) {
				if (isset($out[$row['status']])) {
					$out[$row['status']] = (int) $row['n'];
				}
			}
			return $out;
		}

		public function complaint_type_counts($barangay = '', $resident_id = 0){
			$params = [];
			$sql = "SELECT complaint_type, COUNT(*) AS n FROM complaints WHERE 1 = 1" . $this->complaint_scope($barangay, $resident_id, $params) . " GROUP BY complaint_type ORDER BY n DESC, complaint_type LIMIT 6";
			return $this->rows($sql, $params);
		}

		public function recent_complaint_rows($barangay = '', $resident_id = 0, $limit = 8){
			$params = [];
			$sql = "SELECT id, complaint_type, barangay, status, created_at FROM complaints WHERE 1 = 1" . $this->complaint_scope($barangay, $resident_id, $params) . " ORDER BY created_at DESC, id DESC LIMIT " . max(1, (int) $limit);
			return $this->rows($sql, $params);
		}

		public function recent_trips($barangay = '', $personnel_id = 0, $limit = 8, $status = ''){
			$params = [];
			$sql = "SELECT c.collection_date, c.barangay, c.zone_name, c.waste_category, c.status, c.remarks
					FROM collection_records c
					WHERE 1 = 1" . $this->trip_scope($barangay, $personnel_id, $params, 'c');
			if ($status !== '') {
				$sql .= " AND c.status = :scope_status";
				$params[':scope_status'] = $status;
			}
			$sql .= " ORDER BY c.collection_date DESC, c.id DESC LIMIT " . max(1, (int) $limit);
			return $this->rows($sql, $params);
		}

		public function recycled_this_month(){
			$sql = "SELECT m.material_name, COALESCE(SUM(t.weight_kg), 0) AS total_weight
					FROM materials m
					LEFT JOIN recycling_transactions t ON t.material_id = m.id AND t.record_date >= :month
					GROUP BY m.id, m.material_name
					HAVING total_weight > 0
					ORDER BY total_weight DESC
					LIMIT 7";
			return $this->rows($sql, [':month' => date('Y-m-01')]);
		}
	}

