<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';
	require_once 'includes/charts.php';
	require_once 'includes/report_data.php';

	require_login();
	require_role(['Administrator', 'MENRO']);
	$user = current_user();

	$sections = report_sections($pdo);
	$reports = new Reports($pdo);
	$trend = $reports->daily_trend(30);
	$done = 0; $missed = 0;
	foreach ($trend as $day) {
		$done += $day['done'];
		$missed += $day['missed'];
	}
	$complaints = $reports->complaint_status();
	$rate = ($done + $missed) > 0 ? number_format($done / ($done + $missed) * 100, 1) . '%' : '-';
	$file_name = 'waste-report-' . date('Y-m-d');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo h($file_name) ?></title>
	<link rel="stylesheet" href="assets/report.css">
</head>
<body>
	<div class="toolbar no-print">
		<button type="button" onclick="window.print()">Save as PDF or print</button>
		<a href="reports.php">Back to reports</a>
		<p>In the print window, choose <strong>Save as PDF</strong> as the destination to keep a paperless copy.</p>
	</div>

	<header class="doc-head">
		<p class="org">Community Waste Collection and Environmental Management System</p>
		<h1>Management report</h1>
		<p class="meta">Generated <?php echo h(date('F j, Y, g:i A')) ?> by <?php echo h($user['full_name']) ?>, <?php echo h(role_label($user['role'])) ?></p>
	</header>

	<section class="summary">
		<div><strong><?php echo (int) $done ?></strong><span>Trips completed, last 30 days</span></div>
		<div><strong><?php echo (int) $missed ?></strong><span>Trips missed, last 30 days</span></div>
		<div><strong><?php echo h($rate) ?></strong><span>Completion rate</span></div>
		<div><strong><?php echo (int) ($complaints['New'] + $complaints['In Progress']) ?></strong><span>Open complaints</span></div>
	</section>

	<figure class="chart">
		<figcaption>Collections per day, last 30 days</figcaption>
		<?php echo chart_trend_svg($trend) ?>
		<p class="legend"><span class="key key-done"></span> Completed <span class="key key-missed"></span> Missed</p>
	</figure>

	<?php foreach ($sections as $section) { ?>
		<section class="block">
			<h2><?php echo h($section['title']) ?></h2>
			<?php if (!$section['rows']) { ?>
				<p class="none">No records yet.</p>
			<?php } else { ?>
				<table>
					<thead>
						<tr><?php foreach ($section['heads'] as $head) { ?><th><?php echo h($head) ?></th><?php } ?></tr>
					</thead>
					<tbody>
						<?php foreach ($section['rows'] as $row) { ?>
							<tr><?php foreach ($row as $cell) { ?><td><?php echo h($cell) ?></td><?php } ?></tr>
						<?php } ?>
					</tbody>
				</table>
			<?php } ?>
		</section>
	<?php } ?>

	<section class="signatures">
		<div><span class="line"></span><p>Prepared by</p></div>
		<div><span class="line"></span><p>Noted by, MENRO</p></div>
	</section>

	<?php if (isset($_GET['autoprint'])) { ?>
		<script>window.addEventListener('load', function () { window.print(); });</script>
	<?php } ?>
</body>
</html>
