<?php
	require_once 'dbconn.php';
	require_once 'classes.php';
	require_once 'includes/auth.php';
	require_once 'includes/charts.php';

	require_login();
	$user = current_user();

	$reports = new Reports($pdo);
	$schedules = new Schedules($pdo);
	$assignments = new Assignments($pdo);
	$news = new Announcements($pdo);

	$counts = $reports->dashboard_counts($user['role'], $user['id'], $user['barangay']);
	$today_barangay = '';
	$today_personnel = 0;
	if ($user['role'] === 'Resident' || $user['role'] === 'Barangay Personnel') {
		$today_barangay = $user['barangay'];
	}
	if ($user['role'] === 'Collection Personnel') {
		$today_personnel = (int) $user['id'];
	}
	$today_routes = $schedules->show_today($today_barangay, $today_personnel);
	$my_assignments = [];
	if ($user['role'] === 'Collection Personnel') {
		$my_assignments = $assignments->show_for_day($user['id'], date('Y-m-d'));
	}
	$recent_news = $news->show_for_role($user['role']);
	$recent_news = array_slice($recent_news, 0, 2);

	// What each role is allowed to see in the statistics.
	$is_collector = $user['role'] === 'Collection Personnel';
	$scope_barangay = '';
	$scope_personnel = 0;
	$scope_resident = 0;
	if ($user['role'] === 'Resident' || $user['role'] === 'Barangay Personnel') {
		$scope_barangay = $user['barangay'] !== '' ? $user['barangay'] : '(no area)';
	}
	if ($is_collector) {
		$scope_personnel = (int) $user['id'];
	}
	if ($user['role'] === 'Resident') {
		$scope_resident = (int) $user['id'];
		$scope_barangay_complaints = '';
	} else {
		$scope_barangay_complaints = $scope_barangay;
	}

	$range = (int) ($_GET['range'] ?? 14);
	if (!in_array($range, [7, 14, 30], true)) {
		$range = 14;
	}

	$trend = $reports->daily_trend($range, $scope_barangay, $scope_personnel);
	$trend_done = 0;
	$trend_missed = 0;
	$busiest = null;
	foreach ($trend as $day) {
		$trend_done += $day['done'];
		$trend_missed += $day['missed'];
		if ($busiest === null || ($day['done'] + $day['missed']) > ($busiest['done'] + $busiest['missed'])) {
			$busiest = $day;
		}
	}
	$trend_total = $trend_done + $trend_missed;
	$trend_rate = $trend_total > 0 ? $trend_done / $trend_total * 100 : null;

	$areas = $reports->area_completion($scope_barangay, $scope_personnel);
	$categories = $reports->category_totals($scope_barangay, $scope_personnel);
	$latest_trips = $reports->recent_trips($scope_barangay, $scope_personnel, 10);
	$latest_missed = $reports->recent_trips($scope_barangay, $scope_personnel, 10, 'Missed');

	$complaint_status = null;
	$complaint_types = [];
	$latest_complaints = [];
	if (!$is_collector) {
		$complaint_status = $reports->complaint_status($scope_barangay_complaints, $scope_resident);
		$complaint_types = $reports->complaint_type_counts($scope_barangay_complaints, $scope_resident);
		$latest_complaints = $reports->recent_complaint_rows($scope_barangay_complaints, $scope_resident, 10);
	}
	$recycled = sees_all($user['role']) ? $reports->recycled_this_month() : [];

	$page_title = 'Home';
	$nav_current = 'dashboard.php';
	$body_class = 'dash';
	$extra_css = 'dashboard.css';
	require 'includes/header.php';
?>
	<h1>Home</h1>
	<p class="lead">Today is <?php echo h(format_date(date('Y-m-d'))) ?>, <?php echo h(date('l')) ?>.</p>

	<section class="today">
		<h2>Today’s collection</h2>
		<?php if (!$today_routes && $user['role'] === 'Resident') { ?>
			<p>No truck is scheduled for <?php echo h($user['barangay'] !== '' ? $user['barangay'] : 'your area') ?> today.</p>
		<?php } elseif (!$today_routes && $user['role'] === 'Collection Personnel') { ?>
			<p>You have no standing route on today’s weekday. Check your dated assignment below.</p>
		<?php } elseif (!$today_routes) { ?>
			<p>No active route matches today’s weekday<?php echo $today_barangay !== '' ? ' in ' . h($today_barangay) : '' ?>.</p>
		<?php } else { ?>
			<?php if ($user['role'] === 'Resident') { ?>
				<p>The truck is coming to <?php echo h($user['barangay']) ?> today.</p>
			<?php } ?>
			<div class="table-wrap">
				<table>
					<tr>
						<th>Area</th>
						<th>Waste</th>
						<th>Time</th>
						<th>Collector</th>
					</tr>
					<?php foreach ($today_routes as $route) { ?>
						<tr>
							<td><?php echo h($route['barangay'] . ', ' . $route['zone_name']) ?></td>
							<td><?php echo h($route['waste_category']) ?></td>
							<td><?php echo h(format_time($route['collection_time'])) ?></td>
							<td><?php echo h($route['personnel_name']) ?></td>
						</tr>
					<?php } ?>
				</table>
			</div>
		<?php } ?>
		<?php if ($user['role'] === 'Collection Personnel' && $today_routes) { ?>
			<div class="button-row">
				<a class="btn" href="add_collection.php">Record a trip</a>
			</div>
		<?php } ?>
	</section>

	<?php if ($user['role'] === 'Resident') { ?>
		<div class="tiles">
			<a class="tile" href="schedules.php">
				<span class="tile-number"><?php echo (int) $counts['schedules'] ?></span>
				<span class="tile-title">Collection days</span>
				<span class="tile-text">See when the truck comes to your area.</span>
			</a>
			<a class="tile" href="complaints.php">
				<span class="tile-number"><?php echo (int) $counts['open_reports'] ?></span>
				<span class="tile-title">Open reports</span>
				<span class="tile-text">Problems you sent that are not finished yet.</span>
			</a>
			<a class="tile" href="announcements.php">
				<span class="tile-number"><?php echo (int) $counts['news'] ?></span>
				<span class="tile-title">News items</span>
				<span class="tile-text">Announcements and reminders.</span>
			</a>
		</div>
		<div class="button-row">
			<a class="btn" href="add_complaint.php">Report a problem</a>
			<a class="btn btn-secondary" href="biohazard.php">Biohazard help</a>
			<a class="btn btn-secondary" href="segregation.php">How to sort waste</a>
		</div>
	<?php } elseif ($user['role'] === 'Collection Personnel') { ?>
		<div class="tiles">
			<a class="tile" href="schedules.php">
				<span class="tile-number"><?php echo (int) $counts['routes'] ?></span>
				<span class="tile-title">My routes</span>
				<span class="tile-text">The standing collection days assigned to you.</span>
			</a>
			<a class="tile" href="monitoring.php">
				<span class="tile-number"><?php echo (int) $counts['done_month'] ?></span>
				<span class="tile-title">Finished this month</span>
				<span class="tile-text">Trips you marked as completed.</span>
			</a>
			<a class="tile" href="monitoring.php">
				<span class="tile-number"><?php echo (int) $counts['missed_month'] ?></span>
				<span class="tile-title">Missed this month</span>
				<span class="tile-text">Trips you marked as missed.</span>
			</a>
		</div>
		<h2>Dated assignment for today</h2>
		<?php if (!$my_assignments) { ?>
			<div class="empty"><p>No extra assignment was saved for you today.</p></div>
		<?php } else { ?>
			<div class="table-wrap">
				<table>
					<tr><th>Area</th><th>Waste</th><th>Shift</th><th>Note</th><th>Status</th></tr>
					<?php foreach ($my_assignments as $item) { ?>
						<tr>
							<td><?php echo h(($item['barangay'] ?? '') . ', ' . ($item['zone_name'] ?? '')) ?></td>
							<td><?php echo h($item['waste_category'] ?? '') ?></td>
							<td><?php echo h($item['shift_label']) ?></td>
							<td><?php echo h($item['notes']) ?></td>
							<td><?php echo badge($item['status']) ?></td>
						</tr>
					<?php } ?>
				</table>
			</div>
		<?php } ?>
		<div class="button-row">
			<a class="btn" href="add_activity.php">Write what I did today</a>
		</div>
	<?php } elseif ($user['role'] === 'Barangay Personnel') { ?>
		<div class="tiles">
			<a class="tile" href="schedules.php"><span class="tile-number"><?php echo (int) $counts['schedules'] ?></span><span class="tile-title">Active schedules</span><span class="tile-text">Collection days in <?php echo h($user['barangay']) ?>.</span></a>
			<a class="tile" href="monitoring.php"><span class="tile-number"><?php echo (int) $counts['missed'] ?></span><span class="tile-title">Missed trips</span><span class="tile-text">Collections that did not happen.</span></a>
			<a class="tile" href="complaints.php"><span class="tile-number"><?php echo (int) $counts['open_complaints'] ?></span><span class="tile-title">Open complaints</span><span class="tile-text">Resident reports still waiting.</span></a>
			<a class="tile" href="personnel.php"><span class="tile-number"><?php echo (int) $counts['personnel'] ?></span><span class="tile-title">Collectors</span><span class="tile-text">Active collection personnel in your area.</span></a>
			<?php if ($counts['households'] !== null) { ?><a class="tile" href="census.php"><span class="tile-number"><?php echo (int) $counts['households'] ?></span><span class="tile-title">Households</span><span class="tile-text">Counted in the census for <?php echo h($user['barangay']) ?>.</span></a><?php } ?>
		</div>
	<?php } else { ?>
		<div class="tiles">
			<a class="tile" href="schedules.php"><span class="tile-number"><?php echo (int) $counts['schedules'] ?></span><span class="tile-title">Active schedules</span><span class="tile-text">Collection days for the whole municipality.</span></a>
			<a class="tile" href="monitoring.php"><span class="tile-number"><?php echo (int) $counts['missed'] ?></span><span class="tile-title">Missed trips</span><span class="tile-text">Collections marked as missed.</span></a>
			<a class="tile" href="complaints.php"><span class="tile-number"><?php echo (int) $counts['open_complaints'] ?></span><span class="tile-title">Open complaints</span><span class="tile-text">Reports that are not resolved.</span></a>
			<a class="tile" href="recycling.php"><span class="tile-number"><?php echo h(format_weight($counts['weight'])) ?></span><span class="tile-title">Recycled this month</span><span class="tile-text">Total weight recorded at the center.</span></a>
			<?php if ($counts['households'] !== null) { ?><a class="tile" href="census.php"><span class="tile-number"><?php echo (int) $counts['households'] ?></span><span class="tile-title">Households</span><span class="tile-text">Counted in the census for the whole municipality.</span></a><?php } ?>
		</div>
		<div class="button-row">
			<a class="btn" href="reports.php">Open the reports</a>
		</div>
	<?php } ?>

	<h2 class="sp-section">Statistics</h2>

	<div class="sp-row sp-row-top">
		<section class="sp-panel" aria-labelledby="t-areas">
			<h2 class="sp-title" id="t-areas">Areas</h2>
			<?php if (!$areas) { ?>
				<p class="sp-empty">No trips have been recorded yet.</p>
			<?php } else { ?>
				<div class="sp-scroll" tabindex="0" role="region" aria-label="Completion by area">
					<table class="sp-table">
						<thead>
							<tr><th>Area</th><th>Rate</th><th>Trips</th><th>Change</th></tr>
						</thead>
						<tbody>
							<?php foreach ($areas as $area) { ?>
								<tr>
									<td><?php echo h($area['barangay']) ?></td>
									<td><?php echo h(number_format($area['rate'], 0)) ?>%</td>
									<td><?php echo (int) $area['trips'] ?></td>
									<?php if ($area['change'] === null) { ?>
										<td>-</td>
									<?php } else { ?>
										<td class="<?php echo $area['change'] >= 0 ? 'up' : 'down' ?>"><?php echo h(sprintf('%+.1f%%', $area['change'])) ?></td>
									<?php } ?>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
				<p class="sp-note">Rate is completed trips out of all trips. Change compares the last 30 days with the 30 days before.</p>
			<?php } ?>
		</section>

		<section class="sp-panel sp-trend" aria-labelledby="t-trend">
			<div class="sp-head">
				<h2 class="sp-title" id="t-trend">Collections per day</h2>
				<dl class="sp-stats">
					<div><dt>Completed</dt><dd class="up"><?php echo (int) $trend_done ?></dd></div>
					<div><dt>Missed</dt><dd class="down"><?php echo (int) $trend_missed ?></dd></div>
					<div><dt>Rate</dt><dd><?php echo $trend_rate === null ? '-' : h(number_format($trend_rate, 0)) . '%' ?></dd></div>
					<div><dt>Busiest day</dt><dd><?php echo ($busiest !== null && ($busiest['done'] + $busiest['missed']) > 0) ? h(date('M j', strtotime($busiest['date']))) : '-' ?></dd></div>
				</dl>
				<form method="get" class="sp-range">
					<label for="range">Time</label>
					<select id="range" name="range" onchange="this.form.submit()">
						<?php foreach ([7 => '7 days', 14 => '14 days', 30 => '30 days'] as $value => $text) { ?>
							<option value="<?php echo (int) $value ?>"<?php echo $range === $value ? ' selected' : '' ?>><?php echo h($text) ?></option>
						<?php } ?>
					</select>
					<noscript><button type="submit">Show</button></noscript>
				</form>
			</div>
			<?php if ($trend_total === 0) { ?>
				<p class="sp-empty">No trips were recorded in the last <?php echo (int) $range ?> days.</p>
			<?php } else { ?>
				<?php echo chart_trend_svg($trend) ?>
				<p class="sp-legend"><span class="key key-done"></span>Completed <span class="key key-missed"></span>Missed</p>
			<?php } ?>
		</section>
	</div>

	<div class="sp-row sp-row-mid">
		<section class="sp-panel" aria-labelledby="t-waste">
			<h2 class="sp-title" id="t-waste">Waste collected</h2>
			<?php if (!$categories) { ?>
				<p class="sp-empty">No trips have been recorded yet.</p>
			<?php } else { ?>
				<?php $cat_max = max(1, (int) $categories[0]['total_count']); ?>
				<?php foreach ($categories as $cat) { ?>
					<?php echo hbar_row($cat['waste_category'], (int) $cat['total_count'] . ' trips', (int) $cat['total_count'] / $cat_max * 100) ?>
				<?php } ?>
			<?php } ?>
		</section>

		<?php if ($is_collector) { ?>
			<section class="sp-panel" aria-labelledby="t-mine">
				<h2 class="sp-title" id="t-mine">My trips, last <?php echo (int) $range ?> days</h2>
				<div class="sp-donut">
					<?php echo chart_donut_svg([['Completed', $trend_done, 'seg-done'], ['Missed', $trend_missed, 'seg-missed']], $trend_done . ' completed and ' . $trend_missed . ' missed trips') ?>
					<ul class="sp-key">
						<li><span class="key key-seg-done"></span>Completed <strong><?php echo (int) $trend_done ?></strong></li>
						<li><span class="key key-seg-missed"></span>Missed <strong><?php echo (int) $trend_missed ?></strong></li>
					</ul>
				</div>
			</section>
		<?php } else { ?>
			<section class="sp-panel" aria-labelledby="t-status">
				<h2 class="sp-title" id="t-status"><?php echo $user['role'] === 'Resident' ? 'My reports' : 'Complaints' ?></h2>
				<div class="sp-donut">
					<?php echo chart_donut_svg([['New', $complaint_status['New'], 'seg-new'], ['In progress', $complaint_status['In Progress'], 'seg-progress'], ['Resolved', $complaint_status['Resolved'], 'seg-done']], $complaint_status['New'] . ' new, ' . $complaint_status['In Progress'] . ' in progress, ' . $complaint_status['Resolved'] . ' resolved complaints') ?>
					<ul class="sp-key">
						<li><span class="key key-seg-new"></span>New <strong><?php echo (int) $complaint_status['New'] ?></strong></li>
						<li><span class="key key-seg-progress"></span>In progress <strong><?php echo (int) $complaint_status['In Progress'] ?></strong></li>
						<li><span class="key key-seg-done"></span>Resolved <strong><?php echo (int) $complaint_status['Resolved'] ?></strong></li>
					</ul>
				</div>
			</section>

			<?php if (sees_all($user['role'])) { ?>
				<section class="sp-panel" aria-labelledby="t-recycled">
					<h2 class="sp-title" id="t-recycled">Recycled this month</h2>
					<?php if (!$recycled) { ?>
						<p class="sp-empty">Nothing has been recorded at the center this month.</p>
					<?php } else { ?>
						<?php $rec_max = max(0.01, (float) $recycled[0]['total_weight']); ?>
						<?php foreach ($recycled as $mat) { ?>
							<?php echo hbar_row($mat['material_name'], format_weight($mat['total_weight']), (float) $mat['total_weight'] / $rec_max * 100) ?>
						<?php } ?>
					<?php } ?>
				</section>
			<?php } else { ?>
				<section class="sp-panel" aria-labelledby="t-types">
					<h2 class="sp-title" id="t-types">Problem types</h2>
					<?php if (!$complaint_types) { ?>
						<p class="sp-empty">No reports have been sent yet.</p>
					<?php } else { ?>
						<?php $type_max = max(1, (int) $complaint_types[0]['n']); ?>
						<?php foreach ($complaint_types as $type) { ?>
							<?php echo hbar_row($type['complaint_type'], (string) (int) $type['n'], (int) $type['n'] / $type_max * 100) ?>
						<?php } ?>
					<?php } ?>
				</section>
			<?php } ?>
		<?php } ?>
	</div>

	<div class="sp-row sp-row-low">
		<section class="sp-panel" aria-labelledby="t-trips">
			<h2 class="sp-title" id="t-trips">Latest trips</h2>
			<?php if (!$latest_trips) { ?>
				<p class="sp-empty">No trips have been recorded yet.</p>
			<?php } else { ?>
				<div class="sp-scroll" tabindex="0" role="region" aria-label="Latest trips">
					<table class="sp-table">
						<thead><tr><th>Date</th><th>Area</th><th>Status</th></tr></thead>
						<tbody>
							<?php foreach ($latest_trips as $row) { ?>
								<tr>
									<td><?php echo h(format_date($row['collection_date'])) ?></td>
									<td><?php echo h($row['barangay'] . ', ' . $row['zone_name']) ?></td>
									<td><?php echo badge($row['status']) ?></td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			<?php } ?>
		</section>

		<?php if (!$is_collector) { ?>
			<section class="sp-panel" aria-labelledby="t-latest-c">
				<h2 class="sp-title" id="t-latest-c"><?php echo $user['role'] === 'Resident' ? 'My latest reports' : 'Latest complaints' ?></h2>
				<?php if (!$latest_complaints) { ?>
					<p class="sp-empty">No reports have been sent yet.</p>
				<?php } else { ?>
					<div class="sp-scroll" tabindex="0" role="region" aria-label="Latest complaints">
						<table class="sp-table">
							<thead><tr><th>Type</th><th>Area</th><th>Status</th><th></th></tr></thead>
							<tbody>
								<?php foreach ($latest_complaints as $row) { ?>
									<tr>
										<td><?php echo h($row['complaint_type']) ?></td>
										<td><?php echo h($row['barangay']) ?></td>
										<td><?php echo badge($row['status']) ?></td>
										<td><a href="view_complaint.php?id=<?php echo (int) $row['id'] ?>">Open</a></td>
									</tr>
								<?php } ?>
							</tbody>
						</table>
					</div>
				<?php } ?>
			</section>
		<?php } ?>

		<section class="sp-panel" aria-labelledby="t-missed">
			<h2 class="sp-title" id="t-missed">Missed collections</h2>
			<?php if (!$latest_missed) { ?>
				<p class="sp-empty">No missed collections. Good work.</p>
			<?php } else { ?>
				<div class="sp-scroll" tabindex="0" role="region" aria-label="Missed collections">
					<table class="sp-table">
						<thead><tr><th>Date</th><th>Area</th><th>Why</th></tr></thead>
						<tbody>
							<?php foreach ($latest_missed as $row) { ?>
								<tr>
									<td><?php echo h(format_date($row['collection_date'])) ?></td>
									<td><?php echo h($row['barangay'] . ', ' . $row['zone_name']) ?></td>
									<td><?php echo h($row['remarks']) ?></td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			<?php } ?>
		</section>
	</div>

	<?php if ($recent_news) { ?>
		<h2 class="sp-section">Latest news</h2>
		<div class="sp-row sp-row-news">
			<?php foreach ($recent_news as $item) { ?>
				<article class="sp-panel">
					<p class="sp-note"><?php echo h($item['category']) ?>, <?php echo h(format_date($item['publish_date'])) ?></p>
					<h3 class="sp-news-title"><?php echo h($item['title']) ?></h3>
					<p><?php echo nl2br(h($item['body'])) ?></p>
				</article>
			<?php } ?>
		</div>
	<?php } ?>
<?php require 'includes/footer.php'; ?>
