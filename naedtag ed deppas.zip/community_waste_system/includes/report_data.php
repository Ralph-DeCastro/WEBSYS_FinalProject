<?php
	/* One place that builds every report table, so the CSV download and the printable PDF page always match. */

	function report_sections(PDO $pdo){
		$reports = new Reports($pdo);
		$sections = [];

		$rows = [];
		foreach ($reports->completion_by_barangay() as $row) {
			$total = (int) $row['total_count'];
			$rows[] = [
				$row['barangay'],
				(int) $row['completed_count'],
				(int) $row['missed_count'],
				$total,
				$total > 0 ? number_format($row['completed_count'] / $total * 100, 1) . '%' : '-',
			];
		}
		$sections[] = ['title' => 'Collection completion', 'heads' => ['Barangay', 'Completed', 'Missed', 'Total', 'Completion rate'], 'rows' => $rows];

		try {
			$rows = [];
			foreach ($reports->census_coverage() as $row) {
				$hh = (int) $row['households'];
				$rows[] = [
					$row['barangay'],
					$hh,
					(int) $row['people'],
					$hh > 0 ? number_format($row['people'] / $hh, 1) : '-',
					(int) $row['biohazard'],
					(int) $row['no_schedule'],
					(int) $row['open_complaints'],
				];
			}
			$sections[] = ['title' => 'Households and coverage', 'heads' => ['Barangay', 'Households', 'People', 'Average size', 'Biohazard pickup', 'Without a collection day', 'Open complaints'], 'rows' => $rows];
		} catch (PDOException $e) {
			// The census table has not been created yet, so this section is left out.
		}

		$rows = [];
		foreach ($reports->missed_list() as $row) {
			$rows[] = [format_date($row['collection_date']), $row['barangay'] . ', ' . $row['zone_name'], $row['waste_category'], (string) $row['personnel_name'], (string) $row['remarks']];
		}
		$sections[] = ['title' => 'Missed collections', 'heads' => ['Date', 'Area', 'Waste', 'Collector', 'Why'], 'rows' => $rows];

		$rows = [];
		foreach ($reports->complaints_by_type() as $row) {
			$rows[] = [$row['complaint_type'], (int) $row['new_count'], (int) $row['progress_count'], (int) $row['resolved_count'], (int) $row['total_count']];
		}
		$sections[] = ['title' => 'Environmental complaints', 'heads' => ['Problem', 'New', 'In progress', 'Resolved', 'Total'], 'rows' => $rows];

		$rows = [];
		foreach ($reports->complaint_rows() as $row) {
			$rows[] = [format_date($row['created_at']), $row['complaint_type'], $row['resident_name'], $row['barangay'] . ', ' . $row['location'], $row['status']];
		}
		$sections[] = ['title' => 'Complaint list', 'heads' => ['Date', 'Problem', 'Resident', 'Area', 'Status'], 'rows' => $rows];

		$rows = [];
		foreach ($reports->material_summary() as $row) {
			$rows[] = [$row['material_name'], format_weight($row['total_weight']), format_money($row['total_amount']), (int) $row['trip_count']];
		}
		$sections[] = ['title' => 'Recyclable materials', 'heads' => ['Material', 'Total weight', 'Total amount', 'Records'], 'rows' => $rows];

		return $sections;
	}
