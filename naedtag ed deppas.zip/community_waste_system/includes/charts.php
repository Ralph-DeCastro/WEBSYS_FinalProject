<?php
	/* Small server-side chart helpers. Plain SVG and HTML, no libraries, so they work offline. */

	function chart_num($value){
		return number_format((float) $value, 1, '.', '');
	}

	function chart_trend_svg($rows){
		$n = count($rows);
		if ($n === 0) {
			return '';
		}
		$w = 760; $h = 270; $left = 40; $right = 10; $top = 12; $bottom = 30;
		$plot_w = $w - $left - $right;
		$plot_h = $h - $top - $bottom;
		$max = 0; $sum_done = 0; $sum_missed = 0;
		foreach ($rows as $row) {
			$max = max($max, $row['done'] + $row['missed']);
			$sum_done += $row['done'];
			$sum_missed += $row['missed'];
		}
		$step = max(1, (int) ceil($max / 4));
		$slot = $plot_w / $n;
		$bar = max(4, min(26, $slot * 0.58));
		$every = $n > 20 ? 4 : ($n > 10 ? 2 : 1);
		$label = 'Bar chart of ' . $sum_done . ' completed and ' . $sum_missed . ' missed collection trips over the last ' . $n . ' days.';

		$svg = '<svg class="trend" viewBox="0 0 ' . $w . ' ' . $h . '" role="img" aria-label="' . h($label) . '">';
		$svg .= '<defs><linearGradient id="gDone" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3f9f78"/><stop offset="1" stop-color="#124a33"/></linearGradient></defs>';

		for ($i = 0; $i <= 4; $i++) {
			$y = $top + $plot_h - ($plot_h * $i / 4);
			$svg .= '<line class="grid" x1="' . $left . '" x2="' . ($w - $right) . '" y1="' . chart_num($y) . '" y2="' . chart_num($y) . '"/>';
			$svg .= '<text class="axis" x="' . ($left - 8) . '" y="' . chart_num($y + 4) . '" text-anchor="end">' . ($step * $i) . '</text>';
		}

		$scale = $plot_h / ($step * 4);
		foreach ($rows as $i => $row) {
			$x = $left + $slot * $i + ($slot - $bar) / 2;
			$done_h = $row['done'] * $scale;
			$miss_h = $row['missed'] * $scale;
			$base = $top + $plot_h;
			$tip = h(date('M j', strtotime($row['date'])) . ': ' . $row['done'] . ' completed, ' . $row['missed'] . ' missed');
			$svg .= '<g><title>' . $tip . '</title>';
			if ($row['done'] > 0) {
				$svg .= '<rect x="' . chart_num($x) . '" y="' . chart_num($base - $done_h) . '" width="' . chart_num($bar) . '" height="' . chart_num($done_h) . '" rx="3" fill="url(#gDone)"/>';
			}
			if ($row['missed'] > 0) {
				$svg .= '<rect x="' . chart_num($x) . '" y="' . chart_num($base - $done_h - $miss_h) . '" width="' . chart_num($bar) . '" height="' . chart_num($miss_h) . '" rx="3" fill="#c9473f"/>';
			}
			$svg .= '</g>';
			if ($i % $every === 0) {
				$svg .= '<text class="axis" x="' . chart_num($x + $bar / 2) . '" y="' . ($h - 8) . '" text-anchor="middle">' . h(date('M j', strtotime($row['date']))) . '</text>';
			}
		}
		return $svg . '</svg>';
	}

	/* $parts: list of [label, value, css class]. */
	function chart_donut_svg($parts, $aria){
		$total = 0;
		foreach ($parts as $part) {
			$total += (int) $part[1];
		}
		$svg = '<svg class="donut" viewBox="0 0 42 42" role="img" aria-label="' . h($aria) . '">';
		$svg .= '<circle class="track" cx="21" cy="21" r="15.9155" fill="none" stroke-width="5"/>';
		if ($total > 0) {
			$offset = 0;
			foreach ($parts as $part) {
				$pct = (int) $part[1] / $total * 100;
				if ($pct <= 0) {
					continue;
				}
				$svg .= '<circle class="' . h($part[2]) . '" cx="21" cy="21" r="15.9155" fill="none" stroke-width="5" pathLength="100" stroke-dasharray="' . chart_num($pct) . ' ' . chart_num(100 - $pct) . '" stroke-dashoffset="-' . chart_num($offset) . '" transform="rotate(-90 21 21)"/>';
				$offset += $pct;
			}
		}
		$svg .= '<text x="21" y="23.5" text-anchor="middle" class="donut-total">' . (int) $total . '</text>';
		return $svg . '</svg>';
	}

	function hbar_row($label, $value_text, $pct){
		$pct = max(0, min(100, (float) $pct));
		return '<div class="hrow"><div class="hrow-top"><span>' . h($label) . '</span><span>' . h($value_text) . '</span></div><div class="hbar"><span style="width:' . chart_num($pct) . '%"></span></div></div>';
	}
